exports.response = function response(req, res) {
  return {
    "code": 0,
    "msg": '',
    "data": {
      total: 10,
      list: [
         {
            "Id": "1",
            "Address": "杏林湾营运中心 3#",
            "maxFloor" : "28",
            "locx" : 121.34590,
            "locy" : 34.53490,
            "name" : "杏林湾营运中心 3#"
         },
         {
            "Id": "2",
            "Address": "杏林湾营运中心 3#",
            "maxFloor" : "28",
            "locx" : 121.34590,
            "locy" : 34.53490,
            "name" : "杏林湾营运中心 3#"
         },
          {
            "Id": "2",
            "Address": "杏林湾营运中心 3#",
            "maxFloor" : "28",
            "locx" : 121.34590,
            "locy" : 34.53490,
            "name" : "杏林湾营运中心 3#"
         }
      ]
      
    }
  }
}