exports.response = function response(req, res) {
  return {
    "code": 0,
    "msg": '',
    "data": {
      total: 23,
      list: [
         {
          "buildingid": "1",
          "createTime": 0,
          "floor": 0,
          "id": "1",
          "locx": 112.30,
          "locy": 34.80,
          "lochash": 0,
          "locz": 0,
          "mac": "string",
          "name": "string",
          "ssid": "string",
          "status": 0,
          "updateTime": 0
         }
      ]
      
    }
  }
}