exports.response = function response(req, res) {
  return {
    "code": 0,
    "msg": '',
    "data": {
      total: 23,
      list: [
         {
            "buildingid": "1",
            "createTime": 0,
            "floor": 0,
            "height": 0,
            "id": "1",
            "lochash": 0,
            "mapPath": "string",
            "name": "韦嗣衡科技有限公司",
            "updateTime": 0
         },
         {
            "buildingid": "2",
            "createTime": 0,
            "floor": 0,
            "height": 0,
            "id": "1",
            "lochash": 0,
            "mapPath": "string",
            "name": "韦嗣衡科技有限公司",
            "updateTime": 0
         }
      ]
      
    }
  }
}