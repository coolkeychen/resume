// see http://vuejs-templates.github.io/webpack for documentation.
var path = require('path')
// 后端服务器地址前缀，在`config.dev.mock`为`false`的情况下，
// 以此前缀开头的请求全部转发至指定服务器`targetUrl`
var config = {
  build: {
    env: require('./prod.env'),
    index: path.resolve(__dirname, '../dist/index.html'),
    assetsRoot: path.resolve(__dirname, '../dist'),
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    productionSourceMap: false,
    // Gzip off by default as many popular static hosts such as
    // Surge or Netlify already gzip all static assets for you.
    // Before setting to `true`, make sure to:
    // npm install --save-dev compression-webpack-plugin
    productionGzip: false,
    productionGzipExtensions: ['js', 'css'],
    // Run the build command with an extra argument to
    // View the bundle analyzer report after build finishes:
    // `npm run build --report`
    // Set to `true` or `false` to always turn it on or off
    bundleAnalyzerReport: process.env.npm_config_report
  },
  dev: {
    env: require('./dev.env'),
    port: 8083,
    autoOpenBrowser: false,
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    // mock转发配置项
    proxyTable: {
       //代理服务器访问地址  
    },
    // CSS Sourcemaps off by default because relative paths are "buggy"
    // with this option, according to the CSS-Loader README
    // (https://github.com/webpack/css-loader#sourcemaps)
    // In our experience, they generally work as expected,
    // just be aware of this issue when enabling this option.
    cssSourceMap: false,
    // mock开关
    mock: false,
  },
  // api前缀
  apiPrefix: '/ ',
  // css模块化
  cssModules: false,
  appSrc: path.resolve(__dirname, '../src'),
  appNodeModules: path.resolve(__dirname, '../node_modules')
};
const javaTarget = {
  //target: 'http://127.0.0.1:8082',
  //target: 'http://10.17.11.220:8080',
  // target: 'http://10.17.8.79:8080',
  target: 'http://10.17.5.124:8080',
  // target: 'http://10.17.5.133:8080',
  secure: false,
  changeOrigin: true,
}

const localCatTarget = {
  target: 'http://10.17.10.3:8082',
  //target: 'http://10.17.11.220:8080',
  //target: 'http://10.17.8.79:8080',
  // target: 'http://10.17.5.124:8080',
  secure: false,
  changeOrigin: true,
}



const jsonTarget = {
  target: 'http://map-dev.oss-cn-hangzhou.aliyuncs.com',
  //target: 'http://10.17.8.113:8080',
  //target: 'http://10.17.8.79:8080',
  secure: false,
  changeOrigin: true,
}

config.dev.proxyTable = {
  '/localapi': localCatTarget,
  '/api': javaTarget,
  '/map-dev': javaTarget,
  '/maps': jsonTarget,
  // '/web/account': javaTarget,
  // '/web/bill': javaTarget,
  // '/web/con': javaTarget,
  // '/web/role': javaTarget,
  // '/web/summary': javaTarget,
  // '/web/tenant': javaTarget,
  // '/web/transaction': javaTarget,
  // '/web/housing': phpTarget,
  // '/web/communities': phpTarget,
  // '/web/dict': phpTarget,
  // '/web/regionlist': phpTarget,
  // '/web/centralized': phpTarget,
  // '/web/federal': phpTarget,
  // '/web/housing/account': 'http://localhost:8082'
};
module.exports = config;
