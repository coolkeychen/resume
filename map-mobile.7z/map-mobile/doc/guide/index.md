Title: 安心管开发指导手册
Author: lixiang(lixiang664@pingan.com.cn)
Tag: 指导手册,新人

# 安心管及开发指导手册

- [系统介绍 & 术语](terminology.md)
- [环境配置](environment.md)
- [技术架构](tech.md)
- [源码结构](source.md)
- [开发规范](rule.md)
