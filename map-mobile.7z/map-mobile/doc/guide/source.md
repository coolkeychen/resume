Title: 安心管源码结构
Author: lixiang(lixiang664@pingan.com.cn)
Tag: 指导手册,新人,结构,源码

# 系统源码结构

系统的源码结构如下：

    /src
        /common
            /css
                通用less文件
            /img
                通用图片、Flash等资源文件
            /global
                全局数据维护模块
            /utils
                通用工具类方法
            其他通用脚本
        /components
            /css
                控件less文件
            /img
                控件使用的资源文件
            控件模块
        /biz
            /views
                视图文件（也就是routes）
            /models
                模型文件
            /services
                服务请求
    /build
        构建工具文件
    /doc
        /guide
            新手入门文档
        /business-interface
            业务接口文档
    /mockup
        测试数据，按业务模块分
    /[dist]
        编译输出，不提交
    package.json 第三方依赖包配置
    *.html 各静态页
