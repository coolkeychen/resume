Title: 系统整体架构
Author: lixiang(lixiang664@pingan.com.cn)
Tag: 指导手册,新人,架构,结构

# 系统整体架构

系统整体架构如下：

![整体架构](img/tech.png)


## 底层库

系统主要使用[React](https://github.com/facebook/react)作为底层框架，这也将是我们未来系统开发的框架首选。

- [React-router](https://github.com/ReactTraining/react-router/tree/v2.8.1) 负责路径管理
- [Redux](https://github.com/reactjs/redux) 负责状态管理
- [Redux-saga](https://github.com/redux-saga/redux-saga) 用于管理 Redux 应用异步操作的中间件

## 第三方框架库

React虽然流行，但是太多的崭新概念和幽深的技术栈让新手短时间很难上手。因此引入一些成熟的封装良好的开源框架，可以大大提升开发效率。

- [DVA](https://github.com/dvajs/dva) 基于 redux、redux-saga 和 react-router@2.x 的轻量级前端框架
- [AND](https://ant.design/index-cn) 基于react的UI组件库

## 构建工具

[webpack](http://webpack.github.io/docs/)

## 语言标准

JS：使用新一代JavaScript标准ES6开发，充分发挥新标准的优势和特性。
CSS：LESS



