Title: 安心管开发规范
Author: lixiang(lixiang664@pingan.com.cn)
Tag: 指导手册,新人,开发规范

# 系统开发规范

eslint中报错的都要改

## 项目规范

在项目中，基于编码规范，额外定义一些规则：

### 属性值

- 样式中className属性必须以**dash-case**的形式命名

### 文件命名

- HTML文件名必须以**dash-case**的形式命名，后缀名必须是**.html**。
- LESS文件名必须以**dash-case**，后缀名必须是**.less**。
- Javascript文件名以其定义的内容为名，可使用**PascalCase**或**camelCase**。
- 图片、Flash等，必须以**dash-case**命名。

### LESS文件

在LESS文件中，*不得*直接写子代选择器，必须以LESS的层级嵌套结构进行书写。

### 图片

- 所有图片*必须*为PNG格式，可根据情况选择PNG8或PNG24。
- 所有图片*必须*进行压缩，可使用[tinypng](http://tinypng.org)进行压缩。
- 如可行，图片尽量提供2x分辨率的材料，以支持高分辨率屏幕。

## 编码规则

### URL规则

- 列表：`xxx/list`
- 新建：`xxx/create`
- 更新：`xxx/update~id={id}`
- 详情：`xxx/detail~id={id}`
- 只读：`xxx/read~id={id}`

### 代码注释

文件注释以`/**`开始，以`*/`结束，在文件头部。

代码注释均以`//`开始，后面**紧跟一个空格**，再放置注释内容。

代码注释必须符合markdown规范。

注释有助于未来对整个系统的维护，需要规范执行。

### 引号

除html的属性值，js中的字符串一律使用单引号

### 编码实践

待总结

#### 定义类中的私有方法可以使用Symbol

```
    const INIT_PERMISSION = Symbol('initPermission');

    export default class GlobalData extends RequestManager {

        [INIT_PERMISSION](user) {
            user.authorities.forEach(permissionName => permission.add({[permissionName]: true}));
        }
    }
```

## 代码提交

### 分支创建

不得直接在develop分支上提交，每个人必须基于develop创建独立分支（创建前一定要同步），提交后git上发merge request，可以assign全员，code review通过后，由指定人员合并到develop分支。

### 分支名

- 功能类以**feature_**开头
- bug修复类以**fix_**开头

### 提交原则

尽可能细地进行提交，不要完成多个功能后进行一次提交。避免跨需求、跨BUG地提交代码。每一次提交专注于一件事。
