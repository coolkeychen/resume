Title: 系统预设角色权限列表
Author: lixiang(lixiang664@pingan.com.cn)
Date: $DATE$
Tag: 角色，权限

# 角色权限列表

## 超级管理员

### 权限描述

拥有所有权限，权限不可编辑

## 管家

### 权限描述

拥有管家权限，并且可对管家权限编辑

### 权限列表

- 添加租客合同 : `AXG_CONTRACT_RENTER_ADD`
- 查看租客合同 : `AXG_CONTRACT_RENTER_VIEW`
- 编辑租客信息 : `AXG_CONTRACT_RENTER_BASIC_MODIFY`
- 添加租客账单 : `AXG_CONTRACT_RENTER_BILL_ADD`
- 编辑租客账单 : `AXG_CONTRACT_RENTER_BILL_MODIFY`
- 收款 : `AXG_CONTRACT_RENTER_BILL_RECEIPT`
- 催租 : `AXG_CONTRACT_RENTER_BILL_REMIND`

- 添加房源 : `AXG_RESOURCE_ADD`
- 编辑房源 : `AXG_RESOURCE_MODIFY`
- 查看房源 : `AXG_RESOURCE_VIEW`

- 查看租客 : `AXG_RENTER_VIEW`
- 添加租客 : `AXG_RENTER_ADD`
- 编辑租客 : `AXG_RENTER_MODIFY`
- 分配租客 : `AXG_ACCOUNT_STAFF_RESOURE_DISTRIBUTE`
- 添加跟进 : `AXG_RENTER_TRACK`


## 财务

### 权限描述

拥有财务权限，并且可对财务权限编辑

### 权限列表

- 查看业主合同 : `AXG_CONTRACT_OWNER_VIEW`
- 添加业主账单 : `AXG_CONTRACT_OWNER_BILL_ADD`
- 编辑业主账单 : `AXG_CONTRACT_OWNER_BILL_MODIFY`
- 付款 : `AXG_CONTRACT_OWNER_BILL_PAY`
- 查看租客合同 : `AXG_CONTRACT_RENTER_VIEW`
- 添加租客账单 : `AXG_CONTRACT_RENTER_BILL_ADD`
- 编辑租客账单 : `AXG_CONTRACT_RENTER_BILL_MODIFY`
- 收款 : `AXG_CONTRACT_RENTER_BILL_RECEIPT`
- 催租 : `AXG_CONTRACT_RENTER_BILL_REMIND`

- 查看房源 : `AXG_RESOURCE_VIEW`

- 添加流水 : `AXG_FINANCE_FLOW_ADD`
- 查看流水 : `AXG_FINANCE_FLOW_VIEW`

