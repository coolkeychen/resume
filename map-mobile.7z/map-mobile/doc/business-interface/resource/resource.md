Title: 房源接口
Author: lixiang(lixiang664@pingan.com.cn)
Tag: 房源管理, 接口

# 房源接口
<br>
## 集中式管理
<br>
### 楼栋列表
#### Method & URL

`GET` /api/js/buildings

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**

        [
            {
              "id": 353232,   // 楼栋id
      		    "name": "欣馨人才公寓",   // 楼栋名称
              "count": 30,    // 楼栋房间数
            },
            ...
        ]


#### 缓存

<br>
### 新建楼栋

#### Method & URL

`POST` /api/js/buildings

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| name| 楼栋名称| string| 不能为空；文本，1-30字符（不同于账号的公寓品牌，此仅代表该集中式楼栋的名称）| UTF8| 必须| 无|
| province| 省份id| number| 不能为空| UTF8| 必须| 无|
| city| 城市id| number| 不能为空| UTF8| 必须| 无|
| district| 区id| number| 不能为空| UTF8| 必须| 无|
| town| 镇id| number| 不能为空| UTF8| 必须| 无|
| addressDetail| 其它地址详情，1-200字符| string| 不能为空| UTF8| 必须| 无|
| coordinate | 地图坐标| string| 不能为空| UTF8| 必须| 无|
| level| 楼层数| number| 无| UTF8| 必须| 0|
| tags| 楼栋标签| array| 无| UTF8| 可选| 0|
| facilities| 楼栋设施| array| 无| UTF8| 可选| 0|
| description| 楼栋描述| string| 文本，1-200字符，楼栋本身、周边、配套的介绍| UTF8| 可选| 无|
| images| 楼栋照片| array| 1-10张，需要选择封面图| UTF8| 可选| 无|
| telephone| 400电话信息| string| 1-20个数字| UTF8| 可选| 无|
| contact| 楼栋联系人| number| 默认当前账号自己，可选其他员工| UTF8| 必须| 账号自己|


#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Created|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**

    {
      "id": 353232,   // 楼栋id
      "name": "魔方公寓"   // 楼栋名称
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "addressDetail": "字数不能超过200"
      },
      "message": "参数不符合要求"
    }

<br>
### 读取楼栋信息

#### Method & URL

`GET` /api/js/buildings/{buildingId}

#### Content-Type

`JSON`

#### Cache

#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|404|Not Found|
|401|Unauthorized|


#### 返回

    {
      "id": 353232,   // 楼栋id
      "name": "欣馨人才公寓",   // 楼栋名称
      "level": 30,    // 楼栋层数
      ...
    }



<br>
### 编辑楼栋

#### Method & URL

`PUT` /api/js/buildings/{buildingId}

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| name| 楼栋名称| string| 不能为空；文本，1-30字符（不同于账号的公寓品牌，此仅代表该集中式楼栋的名称）| UTF8| 必须| 无|
| level| 楼层数| number| 无| UTF8| 必须| 0|
| tags| 楼栋标签| array| 无| UTF8| 可选| 0|
| facilities| 楼栋设施| array| 无| UTF8| 可选| 0|
| description| 楼栋描述| string| 文本，1-200字符，楼栋本身、周边、配套的介绍| UTF8| 可选| 无|
| images| 楼栋照片| array| 1-10张，需要选择封面图| UTF8| 可选| 无|
| telephone| 400电话信息| string| 1-20个数字| UTF8| 可选| 无|
| contact| 楼栋联系人| number| 默认当前账号自己，可选其他员工| UTF8| 必须| 账号自己|


#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Updated|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**

    {
      "id": 353232,   // 楼栋id
      "name": "魔方公寓"   // 楼栋名称
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "addressDetail": "字数不能超过200"
      },
      "message": "参数不符合要求"
    }

<br>
### 删除楼栋

#### Method & URL

`DELETE` /api/js/buildings/{buildingId}

#### Content-Type

`JSON`

#### Cache


#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Deleted|
|401|Unauthorized|
|409|Conflict|

#### 返回


<br>
### 房型列表

#### Method & URL

`GET` /api/js/buildings/{buildingId}/roomStyles

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**

        [
          {
            "id": 353232,    // 房型id
            "name": "标准间",    // 房型名称
            "bedRoom": 3,    // 室
            "livingRoom": 1,    // 厅
            "sittingRoom": 1,    // 卫
            "area": 50,    // 面积
            ...
          },
          ...
        ]

#### 缓存


<br>
### 添加房型

#### Method & URL

`POST` /api/js/buildings/{buildingId}/roomStyles

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| name| 房型名称| string| 不能为空；文本、1-20字符| UTF8| 必须| 无|
| bedRoom| 室| number| 不能为空 1-20| UTF8| 必须| 1|
| livingRoom| 厅| number| 不能为空 1-20| UTF8| 必须| 1|
| sittingRoom| 卫| number| 不能为空 1-20| UTF8| 必须| 1|
| area| 面积| number| 不能为空，精确到小数点后两位，1-500| UTF8| 必须| 无|
| decorateStyle| 装修风格| number| 选项来源于HDMP| UTF8| 必须| 无|
| facilities| 配套设施| array| 选项来源于HDMP| UTF8| 可选| 无|
| ownerRequest| 房东要求| array| 选项来源于HDMP| UTF8| 可选| 无|
| payMethod| 付款方式| array| 选项来源于HDMP（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| rent| 租金| number| 1-100000（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| description| 房型描述| string| 文本，1-200字符| UTF8| 可选| 无|
| images| 房间照片| array| 1-10张，需要选择封面图| UTF8| 可选| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Created|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**

    {
      "id": 353232,   // 房型id
      "name": "标准间"   // 房型名称
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "rent": "租金不能超过20w"
      },
      "message": "参数不符合要求"
    }


<br>
### 编辑房型

#### Method & URL

`PUT` /api/js/buildings/{buildingId}/roomStyles/{roomStyleId}

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| name| 房型名称| string| 不能为空；文本、1-20字符| UTF8| 必须| 无|
| bedRoom| 室| number| 不能为空 1-20| UTF8| 必须| 1|
| livingRoom| 厅| number| 不能为空 1-20| UTF8| 必须| 1|
| sittingRoom| 卫| number| 不能为空 1-20| UTF8| 必须| 1|
| area| 面积| number| 不能为空，精确到小数点后两位，1-500| UTF8| 必须| 无|
| decorateStyle| 装修风格| number| 选项来源于HDMP| UTF8| 必须| 无|
| facilities| 配套设施| array| 选项来源于HDMP| UTF8| 可选| 无|
| ownerRequest| 房东要求| array| 选项来源于HDMP| UTF8| 可选| 无|
| payMethod| 付款方式| array| 选项来源于HDMP（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| rent| 租金| number| 1-100000（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| description| 房型描述| string| 文本，1-200字符| UTF8| 可选| 无|
| images| 房间照片| array| 1-10张，需要选择封面图| UTF8| 可选| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Created|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**

    {
      "id": 353232,   // 房型id
      "name": "标准间"   // 房型名称
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "rent": "租金不能超过20w"
      },
      "message": "参数不符合要求"
    }



<br>
### 读取房型信息

#### Method & URL

`GET` /api/js/buildings/{buildingId}/roomStyles/{roomStyleId}

#### Content-Type

`JSON`

#### Cache

#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|404|Not Found|
|401|Unauthorized|


#### 返回

    {
      "id": 353232,   // 房型id
      "name": "标准间",   // 房型名称
      ...
    }


<br>
### 删除房型

#### Method & URL

`DELETE` /api/js/buildings/{buildingId}/roomStyles/{roomStyleId}

#### Content-Type

`JSON`

#### Cache


#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Deleted|
|401|Unauthorized|
|409|Conflict|

#### 返回


### 房间列表

#### Method & URL

`GET` /api/js/buildings/{buildingId}/roomStyles/{roomStyleId}/rooms

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**

      [
        {
          "id": 353232,    // 房间id
          "number": "501",    // 房间号
          "level": 5,    // 所在层数
          "orientation": 1,    // 朝向：南北，南南，北北
          "rent": 1000,    // 租金（选项来源HDMP，默认【朝东】）
          "sittingRoom": 1,    // 卫
          "area": 50,    // 面积
          ...
        },
        ...
      ]

#### 缓存

<br>
### 批量添加房间

#### Method & URL

`POST` /api/js/buildings/{buildingId}/roomStyles/{roomStyleId}/rooms/batch

#### Content-Type

`JSON`

#### Cache


#### 参数

    [
      {
        "level": 5,    // 楼层
        "number": 10,    // 房间数
      },
      ...
    ]

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Created|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**

    [
        {
          "id": 353232,    // 房间id
          "number": "501",    // 房间号
          "level": 5,    // 所在层数
          "orientation": 1,    // 朝向：南北，南南，北北
          "rent": 1000,    // 租金（选项来源HDMP，默认【朝东】）
          "sittingRoom": 1,    // 卫
          "area": 50,    // 面积
          ...
        },
    ]

-**失败**

    {
      "errorCode": "null",
      "message": "无法创建房间"
    }


<br>
### 批量修改房间

#### Method & URL

`PUT` /api/js/buildings/{buildingId}/roomStyles/{roomStyleId}/rooms/batch

#### Content-Type

`JSON`

#### Cache


#### 参数

    [
        {
          "id": 353232,    // 房间id
          "number": "501",    // 房间号
          "level": 5,    // 所在层数
          "orientation": 1,    // 朝向：南北，南南，北北
          "rent": 1000,    // 租金（选项来源HDMP，默认【朝东】）
          "sittingRoom": 1,    // 卫
          "area": 50,    // 面积
          "contact": 12,    // 房间联系人id
          "memo": "xxxxx"    // 备注
        },
        ...
    ]

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Updated|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**

    {
      "id": 353232,   // 房型id
      "name": "标准间"   // 房型名称
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "rent": "租金不能超过20w"
      },
      "message": "参数不符合要求"
    }



<br>
### 编辑房间基本信息

#### Method & URL

`PUT` /api/js/buildings/{buildingId}/roomStyles/{roomStyleId}/rooms/{roomId}

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| bedRoom| 室| number| 不能为空 1-20| UTF8| 必须| 1|
| livingRoom| 厅| number| 不能为空 1-20| UTF8| 必须| 1|
| sittingRoom| 卫| number| 不能为空 1-20| UTF8| 必须| 1|
| area| 面积| number| 不能为空，精确到小数点后两位，1-500| UTF8| 必须| 无|
| decorateStyle| 装修风格| number| 选项来源于HDMP| UTF8| 必须| 无|
| facilities| 配套设施| array| 选项来源于HDMP| UTF8| 可选| 无|
| ownerRequest| 房东要求| array| 选项来源于HDMP| UTF8| 可选| 无|
| paymentCircle| 付款周期| array| 选项来源于HDMP| UTF8| 必须| 无|
| payMethod| 付款方式| array| 选项来源于HDMP（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| rent| 租金| number| 1-100000（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| level| 楼层| number| 1-999，选择范围楼栋的总楼层数，初始创建时继承房型| UTF8| 必须| 无|
| orientation| 朝向| number| 选项来源HDMP，默认【朝东】| UTF8| 必须| 无|
| memo| 备注| string| 文本，1-300字符| UTF8| 可选| 无|
| contact| 房间联系人| number| 默认当前账号自己，可选其他员工，初始创建时继承楼栋resource| UTF8| 必须| 账号自己|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Created|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**

    {
      "id": 353232,   // 房型id
      "name": "标准间"   // 房型名称
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "rent": "租金不能超过20w"
      },
      "message": "参数不符合要求"
    }


### 读取房间基本信息

#### Method & URL

`GET` /api/js/buildings/{buildingId}/roomStyles/{roomStyleId}/rooms/{roomId}

#### Content-Type

`JSON`

#### Cache

#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|404|Not Found|
|401|Unauthorized|


#### 返回

    {
      "id": 353232,   // 房间id
      ...
    }


<br>
### 删除房间

#### Method & URL

`DELETE` /api/js/buildings/{buildingId}/roomStyles/{roomStyleId}/rooms/{roomId}

#### Content-Type

`JSON`

#### Cache


#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Deleted|
|401|Unauthorized|
|409|Conflict|

#### 返回


<br>
### 房间搜索

#### Method & URL

`GET` /api/js/buildings/{buildingId}/rooms

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| keyword| 搜索关键字（请输入房间号、租客名、租客手机号）| string| | UTF8| 可选| 无|
| roomStatus| 出租状态（空为全部，1：已租，0：空置）| number| 无| UTF8| 可选| 无|
| minPrice| 最低价格| number| 无| UTF8| 可选| 无|
| maxPrice| 最高价格| number| 无| UTF8| 可选| 无|
| roomStyle| 房型（房型列表有单独接口提供）| number| 无| UTF8| 可选| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**

      [
          {
              "id": 353232,    // 房间id
              "roomStyleId": 2,  // 房型id
              "roomStyleName": "A房型",  // 房型名称（为省去前端通过id匹配房型名称的多余操作，建议后端直接把名称传过来）
              "number": "0101",    // 房间号
              "level": 10,    // 所在楼层
              "rent": 1000,   // 月租金
              "roomStatus": 1,   // 1：已租，0：空置
              "renter": "张倩倩",    // 租客
              "collectionate": "2017.05.08",    // 应收款日，格式：YYYY.MM.DD
              "rentStatus": 1   // 房租状态，待定
              ...
          },
          {},
          ...
      ]

#### 缓存


<br>
## 分散式管理

### 房源列表

#### Method & URL

`GET` /api/js/blocks

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**

        [
            {
              "id": 353232,   // 小区id
              "name": "玉兰香苑",   // 小区名称
              "count": 30,    // 小区房间数
            },
            ...
        ]

#### 缓存


<br>
### 新建（小区）房源

#### Method & URL

`POST` /api/js/blocks

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| rentMode| 出租方式| number| 1：合租 2：整租| UTF8| 必须| 无|
| -----| -----| -----| 以下是公共字段| -----| -----| -----|
| province| 省份id| number| 不能为空| UTF8| 必须| 无|
| city| 城市id| number| 不能为空| UTF8| 必须| 无|
| name| 小区名称| string| 文本，1-30个字符（输入小区名开始自动联想相关小区，选择联想出来的小区则小区地址信息不可修改，地址坐标可修改）| UTF8| 必须| 无|
| district| 区id| number| 不能为空| UTF8| 必须| 无|
| town| 镇id| number| 不能为空| UTF8| 必须| 无|
| addressDetail| 其它地址详情，1-200字符| string| 不能为空| UTF8| 必须| 无|
| coordinate | 地图坐标| string| 不能为空| UTF8| 必须| 无|
| building| 栋/幢：数字or英文字母，1-4个字符| string| 不能为空| UTF8| 必须| 无|
| unit| 单元：数字or英文字母，1-4个字符| string| 可为空| UTF8| 可选| 无|
| room| 室：数字or英文字母，1-4个字符| string| 不能为空| UTF8| 必须| 无|
| totalLevel| 总楼层数| number| 1-999| UTF8| 必须| 0|
| level| 所在楼层数| number| 必须比totalLevel小，1-999| UTF8| 必须| 0|
| bedRoom| 室| number| 不能为空 1-20| UTF8| 必须| 1|
| livingRoom| 厅| number| 不能为空 1-20| UTF8| 必须| 1|
| sittingRoom| 卫| number| 不能为空 1-20| UTF8| 必须| 1|
| area| 面积| number| 不能为空，精确到小数点后两位，1-500| UTF8| 必须| 无|
| decorateStyle| 装修风格| number| 选项来源于HDMP| UTF8| 必须| 无|
| facilities| 配套设施| array| 选项来源于HDMP| UTF8| 可选| 无|
| ownerRequest| 房东要求| array| 选项来源于HDMP| UTF8| 可选| 无|
| tags| 房源标签| array| 选项来源HDMP| UTF8| 可选| 0|
| images| 房间照片| array| 1-10张，需要选择封面图| UTF8| 可选| 无|
| description| 房源描述| string| 文本，1-300字符| UTF8| 可选| 无|
| contact| 房源联系人| number| 默认当前账号自己，可选其他员工，初始创建时继承楼栋resource| UTF8| 必须| 账号自己|
| -----| -----| -----| 以下是整租模式字段| -----| -----| -----|
| payMethod| 付款方式| array| 选项来源于HDMP（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| rent| 租金| number| 1-100000（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| orientation| 朝向| number| 选项来源HDMP，默认【朝东】| UTF8| 必须| 无|
| -----| -----| -----| 以下是合租模式字段| -----| -----| -----|
| rooms| 房间列表| array| 具体元素见下| UTF8| 可选| 无|
| number| 房间号| string| 文本，1-10个字符，可修改| UTF8| 必须| 无|
| payMethod| 付款方式| array| 选项来源于HDMP（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| rent| 租金| number| 1-100000（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| orientation| 朝向| number| 选项来源HDMP，默认【朝东】| UTF8| 必须| 无|
| area| 面积| number| 不能为空，精确到小数点后两位，1-500| UTF8| 必须| 无|
| facilities| 配套设施| array| 选项来源于HDMP| UTF8| 可选| 无|
| images| 房间照片| array| 1-10张，需要选择封面图| UTF8| 可选| 无|
| memo| 房间备注| string| 文本，1-300字符| UTF8| 可选| 无|

#### HTTP响应值

| 值 | 含义 |
|201|Created|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**

    {
      "id": 353232,   // 房源id
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {},
      "message": "参数不符合要求"
    }


<br>
### 读取房源信息

#### Method & URL

`GET` /api/js/blocks/{blockId}

#### Content-Type

`JSON`

#### Cache

#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|404|Not Found|
|401|Unauthorized|


#### 返回

    {
      "id": 353232,   // id
      "name": "玉兰香苑",   // 名称
      "rooms": []    // 房间列表
      ...
    }



<br>
### 编辑房源

#### Method & URL

`PUT` /api/js/blocks/{blockId}

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| -----| -----| -----| 以下是公共字段| -----| -----| -----|
| name| 小区名称| string| 文本，1-30个字符（输入小区名开始自动联想相关小区，选择联想出来的小区则小区地址信息不可修改，地址坐标可修改）| UTF8| 必须| 无|
| totalLevel| 总楼层数| number| 1-999| UTF8| 必须| 0|
| level| 所在楼层数| number| 必须比totalLevel小，1-999| UTF8| 必须| 0|
| bedRoom| 室| number| 不能为空 1-20| UTF8| 必须| 1|
| livingRoom| 厅| number| 不能为空 1-20| UTF8| 必须| 1|
| sittingRoom| 卫| number| 不能为空 1-20| UTF8| 必须| 1|
| area| 面积| number| 不能为空，精确到小数点后两位，1-500| UTF8| 必须| 无|
| decorateStyle| 装修风格| number| 选项来源于HDMP| UTF8| 必须| 无|
| facilities| 配套设施| array| 选项来源于HDMP| UTF8| 可选| 无|
| ownerRequest| 房东要求| array| 选项来源于HDMP| UTF8| 可选| 无|
| tags| 房源标签| array| 选项来源HDMP| UTF8| 可选| 0|
| images| 房间照片| array| 1-10张，需要选择封面图| UTF8| 可选| 无|
| description| 房源描述| string| 文本，1-300字符| UTF8| 可选| 无|
| contact| 房源联系人| number| 默认当前账号自己，可选其他员工，初始创建时继承楼栋resource| UTF8| 必须| 账号自己|
| -----| -----| -----| 以下是整租模式字段| -----| -----| -----|
| payMethod| 付款方式| array| 选项来源于HDMP（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| rent| 租金| number| 1-100000（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| orientation| 朝向| number| 选项来源HDMP，默认【朝东】| UTF8| 必须| 无|
| -----| -----| -----| 以下是合租模式字段| -----| -----| -----|
| rooms| 房间列表| array| 具体元素见下| UTF8| 可选| 无|
| number| 房间号| string| 文本，1-10个字符，可修改| UTF8| 必须| 无|
| payMethod| 付款方式| array| 选项来源于HDMP（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| rent| 租金| number| 1-100000（不与合同财务联动，仅用户展示）| UTF8| 必须| 无|
| orientation| 朝向| number| 选项来源HDMP，默认【朝东】| UTF8| 必须| 无|
| area| 面积| number| 不能为空，精确到小数点后两位，1-500| UTF8| 必须| 无|
| facilities| 配套设施| array| 选项来源于HDMP| UTF8| 可选| 无|
| images| 房间照片| array| 1-10张，需要选择封面图| UTF8| 可选| 无|
| memo| 房间备注| string| 文本，1-300字符| UTF8| 可选| 无|


#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Updated|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**

    {
      "id": 353232,   // id
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {},
      "message": "参数不符合要求"
    }


<br>
### 删除房源

#### Method & URL

`DELETE` /api/js/blocks/{blockId}

#### Content-Type

`JSON`

#### Cache


#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Deleted|
|401|Unauthorized|
|409|Conflict|

#### 返回


<br>
### 房间搜索

#### Method & URL

`GET` /api/js/blocks/{}/rooms

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| keyword| 搜索关键字（请输入房间号、租客名、租客手机号）| string| | UTF8| 可选| 无|
| roomStatus| 出租状态（空为全部，1：已租，0：空置）| number| 无| UTF8| 可选| 无|
| minPrice| 最低价格| number| 无| UTF8| 可选| 无|
| maxPrice| 最高价格| number| 无| UTF8| 可选| 无|
| name| 小区| string| 无| UTF8| 可选| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**

      [
          {
              "id": 353232,    // 房间id
              "number": "0101",    // 房间号
              "rent": 1000,   // 月租金
              "roomStatus": 1,   // 1：已租，0：空置
              "renter": "张倩倩",    // 租客
              "collectionate": "2017.05.08",    // 应收款日，格式：YYYY.MM.DD
              "rentStatus": 1   // 房租状态，待定
              ...
          },
          {},
          ...
      ]

#### 缓存


