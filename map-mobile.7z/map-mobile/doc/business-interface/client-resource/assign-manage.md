Title: 分配管理员
Author: yangpeifen
Date: 2017/06/03
Tag: 

### Method & URL

`POST` /api/js/client

### Content-Type

`JSON`

### 参数

    {
        "manage" : "王晓", //
    }

### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|

### 返回

-**成功**

[
    
    ...
]

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "addressDetail": "字数不能超过200"
      },
      "message": "参数不符合要求"
    }

