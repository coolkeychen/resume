Title: 添加房源/编辑房源
Author: yangpeifen
Date: 2017/06/03
Tag: 添加房源，编辑房源
QA： 
1. 紧急程度的分类几种？
2. 预约看房日期，需要时间么？
3. 入住日期，需要时间么?


# 添加房源
<br>
##添加房源接口
### Method & URL

`POST` /api/js/client

### Content-Type

`JSON`

### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| from | 来源| string| 不能为空；选择框，选择项有：来电、58同城、赶集网、安居客、<br />官网预约、微信公众号、百度租房、支付宝租房、嗨住、微博中介、方天下、<br />豆瓣、百姓网、闲鱼、转介绍（朋友）、转介绍（客户）、小广告、其他| UTF8| 必须| 来电|
| name | 客户名称| number| 不能为空，1-30| UTF8| 必须| 无|
| sex | 性别 | number| 1 男 2 女,默认1 | UTF8| 必须| 1|
| mobile | 联系电话 | number| 无 | UTF8| 必须| 无 |
| urgent | 紧急程度 | string| 1 紧急 2 正常 3 延后，默认1 | UTF8| 必须| 1 紧急|
| liveDate | 入住时间 | string| 无| UTF8| 非必须 | 0|
| appointHouse| 预约房源| string| 文本，若为好房预约房源信息自动带过来 | UTF8| 非必须| 0|
| appointDate| 预约看房日期| string| 无| UTF8| 非必须| 0|
| rentMin| 租金范围最小值| number| 1~10万| UTF8| 非必须| 0|
| rentMax| 租金范围最大值| number| 1~10万 | UTF8| 非必须| 0|
| rentDate| 租期| number| 1-120，单位：个月 | UTF8| 非必须| 0|
| peoNum| 人数| number| 数字，1-500 | UTF8| 非必须| 0|
| layout| 户型需求| string | 合租主卧、合租单间独卫、合租单间、整租１室户、整租２室户、整租３室户 | UTF8| 非必须| 0|
| assigner| 分配人| string | 无| UTF8| 非必须| 0|
| other| 备注| string | 无| UTF8| 非必须| 0|



### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|

### 返回

-**成功**


    {
        "id": 353232,                     // 客户id 
    },
    ...


-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "addressDetail": "字数不能超过200"
      },
      "message": "参数不符合要求"
    }



# 编辑房源
<br>
##编辑房源接口
### Method & URL

`PUT` /api/js/client/{clientId}

### Content-Type

`JSON`

### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| id | 客户id| number| 不能为空，1-30| UTF8| 必须| 无|
| from | 来源| string| 不能为空；选择框，选择项有：来电、58同城、赶集网、安居客、<br />官网预约、微信公众号、百度租房、支付宝租房、嗨住、微博中介、方天下、<br />豆瓣、百姓网、闲鱼、转介绍（朋友）、转介绍（客户）、小广告、其他| UTF8| 必须| 来电|
| name | 客户名称| number| 不能为空，1-30| UTF8| 必须| 无|
| sex | 性别 | number| 1 男 2 女,默认1 | UTF8| 必须| 1|
| mobile | 联系电话 | number| 无 | UTF8| 必须| 无 |
| urgent | 紧急程度 | string| 1 紧急 2 正常 3 延后，默认1 | UTF8| 必须| 1 紧急|
| liveDate | 入住时间 | string| 无| UTF8| 非必须 | 0|
| appointHouse| 预约房源| string| 文本，若为好房预约房源信息自动带过来 | UTF8| 非必须| 0|
| appointDate| 预约看房日期| string| 无| UTF8| 非必须| 0|
| rentMin| 租金范围最小值| number| 1~10万| UTF8| 非必须| 0|
| rentMax| 租金范围最大值| number| 1~10万 | UTF8| 非必须| 0|
| rentDate| 租期| number| 1-120，单位：个月 | UTF8| 非必须| 0|
| peoNum| 人数| number| 数字，1-500 | UTF8| 非必须| 0|
| layout| 户型需求| string | 合租主卧、合租单间独卫、合租单间、整租１室户、整租２室户、整租３室户 | UTF8| 非必须| 0|
| assigner| 分配人| string | 无| UTF8| 非必须| 0|
| other| 备注| string | 无| UTF8| 非必须| 0|



### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|

### 返回

-**成功**

[
    {
        "id": 353232,                     // 客户id
    },
    ...
]

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "addressDetail": "字数不能超过200"
      },
      "message": "参数不符合要求"
    }




