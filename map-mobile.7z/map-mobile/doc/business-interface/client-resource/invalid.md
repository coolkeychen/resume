Title: 设置无效
Author: yangpeifen
Date: 2017/06/04
Tag: 

### Method & URL

`PUT` /api/js/client/{clientId}

### Content-Type

`JSON`

### 参数

    {
        "id" : 333, //客户ID
    }

### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|

### 返回

-**成功**

[
    
    ...
]

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "addressDetail": "字数不能超过200"
      },
      "message": "参数不符合要求"
    }

