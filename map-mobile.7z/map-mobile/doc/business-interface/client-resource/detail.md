Title: 客户详情
Author: yangpeifen
Date: 2017/06/03
Tag: 


# 客户详情
<br>
##客户详情接口
### Method & URL

`GET` /api/js/client/{clientId}

### Content-Type

`JSON`

### 参数

无

### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|

### 返回

-**成功**

[
    {
        "id": 353232,                     // 客户id
        "from": "平安好房",                // 来源
        "name": "王小明",                  // 客户名称，可以为空
        "sex": 1,                         // 1 男 2 女
        "mobile": "18016666678",          // 客户电话        
        "urgent": 1,                      // 紧急程度，1 紧急 2 正常 3 延后，默认1
        "liveDate": "2017.06.08",         // 入住时间
        "appointHouse": "欣馨人才公寓",    // 预约房源        
        "appointDate": "2017.06.01",      // 预约看房日期
        "rentMin": "100",                 // 租金范围最小值
        "rentMax":　"10000",              // 租金范围最大值
        "rentDate": "20",                 // 租期，月为大内
        "peoNum" : "2",                   // 人数
        "layout" : "合住主卧",            // 户型需求
        "assigner": "王晓",               // 分配人
        "other": "备注信息备注信息",
        "follow" : [
            {
                "title"：　"2017.05.11 09:00  王晓", 
                "content":　"已预约周末看房"
            },
            {
                "title"：　"2017.05.10 19:00 王晓", 
                "content":　"已去电，客户正忙"
            },
            {
                "title"：　"2017.05.10 10:00 王晓", 
                "content":　"分配给王晓"
            }
        ]
        
    },
    ...
]

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "addressDetail": "字数不能超过200"
      },
      "message": "参数不符合要求"
    }







