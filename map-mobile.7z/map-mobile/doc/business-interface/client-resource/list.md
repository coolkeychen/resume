Title: 客源列表
Author: yangpeifen
Date: 2017/06/03
Tag: 客源列表，待分配客源，跟进中客源，已完成客源，接口
QA：

# 客源接口
<br>
##待分配客源,客源默认展示“待分配”
<br>
###客源列表
#### Method & URL

`GET` /api/js/tenant?type=1

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|

#### 返回

-**成功**

    {
        "success": true,
        "errorCode": 0,
        "fieldErrors": [],
        "msg": "",
        "data": {
            "list" : [
                {
                    "id": 353232,   // 客户id
                    "name": "王小明",   // 客户名称
                    "clientDetailUrl": "detail+id",   // 客户详情页地址
                    "mobile": "18016666678",    // 客户电话
                    "from": "平安好房",    // 来源
                    "urgent": 1,    // 紧急程度，1 全部 2 紧急 3 正常
                    "liveDate": "2017.06.08",    // 入住时间
                    "appointDate": "2017.06.01",    // 预约看房日期
                    "appointHouse": "欣馨人才公寓",    // 预约房源
                    "assignUrl": "assign+id",    // 分配url
                    "editUrl": "edit+id",   // 编辑url
                    "addUrl": "added+id"    // 添加客源
                },
                ...
            ]
        }
    }

    


#### 缓存


##跟进中客源
<br>
###跟进中客源列表
#### Method & URL

`GET` /api/js/client?type=2

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|

#### 返回

-**成功**
    
    {
        "success": true,
        "errorCode": 0,
        "fieldErrors": [],
        "msg": "",
        "data": {
            "list" : [
                {
                    "id": 353232,   // 客户id
                    "name": "王小明",   // 客户名称
                    "clientDetailUrl": "detail+id",   // 客户详情页地址
                    "mobile": "18016666678",    // 客户电话
                    "from": "平安好房",    // 来源
                    "urgent": 1,    // 紧急程度，1 全部 2 紧急 3 正常
                    "liveDate": "2017.06.08",    // 入住时间
                    "appointDate": "2017.06.01",    // 预约看房日期
                    "appointHouse": "欣馨人才公寓",    // 预约房源
                    "assigner": "王晓",    // 分配人
                    "followState": "2017.05.11 09：00已去电",    // 跟进状态
                    "tenant": "/tenant",   // 租客签约Url
                    "addUrl": "added+id"    // 添加客源
                },
                ...
            ]
        }
    }


#### 缓存

##已完成客源
<br>
###已完成客源列表
#### Method & URL

`GET` /api/js/client?type=3

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|

#### 返回

-**成功**

    {
        "success": true,
        "errorCode": 0,
        "fieldErrors": [],
        "msg": "",
        "data": {
            "list" : [
                {
                    "id": 353232,   // 客户id
                    "name": "王小明",   // 客户名称
                    "clientDetailUrl": "detail+id",   // 客户详情页地址
                    "mobile": "18016666678",    // 客户电话
                    "from": "平安好房",    // 来源
                    "urgent": 1,    // 紧急程度，1 全部 2 紧急 3 正常
                    "liveDate": "2017.06.08",    // 入住时间
                    "appointDate": "2017.06.01",    // 预约看房日期
                    "appointHouse": "欣馨人才公寓",    // 预约房源
                    "assigner": "王晓",    // 分配人
                    "state": 1,    // 状态 1 无效 2 已签约
                    "addUrl": "added+id"    // 添加客源
                },
                ...
            ]
        }
    }

#### 缓存

<br>
###搜索
#### Method & URL

`GET` /api/js/client/{type}/{urgent}

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| user | 客户名或手机号| number|  | UTF8| 非必填| 无|
| urgent | 紧急程度| number| 1 全部 2 紧急 3 正常，可以为空 | UTF8| 非必填| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Created|
|401|Unauthorized|

#### 返回
-**成功**

    {
      "id": 353232,   // 客户id
      "name": "王小明"   // 客户名称
      ...
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "description": "字数不能超过200",
        "addressDetail": "字数不能超过200"
      },
      "message": "参数不符合要求"
    }

