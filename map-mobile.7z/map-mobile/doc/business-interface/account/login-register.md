Title: 房源接口
Author: shengchenling(shengchenling711@pingan.com.cn)
Tag: 注册，登陆，忘记密码，接口



# 注册登陆

<br>

### 图形验证码

#### Method & URL

‘GET’ /api/js/captcha.jpg

???只需要一个图片链接



<br>

### 短信验证码接口

<br>

#### Method &URL

'GET'  /api/js/smsCaptcha

#### Content-Type

'JSON'

#### 参数

| 名称       | 解释    | 类型     | 限制       | 编码    | 可选（必须） |
| -------- | ----- | ------ | -------- | ----- | ------ |
| sMobile  | 手机号   | string | 不能为空；11位 | UTF-8 | 必须     |
| sCaptcha | 图形验证码 | string | 不能为空；    | UTF-8 | 必须     |

#### 响应值

| 值    | 含义   |
| ---- | ---- |
| 200  | ok   |

#### 返回

**成功**

```
{
"success": true,
"errorCode": 0,
"msg": "",
}
```

**失败**

````
{"success":false,
"errCode":XXX,
"fieldErrors": [
  "sMobile":"手机号码格式不正确",
  "sCaptcha":"图形验证码不正确"
],
"msg":"参数报错"
}
````



### 注册

#### Method &URL

'POST'  /api/js/user

#### Content-Type

'JSON'

#### 参数

| 名称        | 解释    | 类型     | 限制                 | 编码    | 可选(必须) |
| --------- | ----- | ------ | ------------------ | ----- | ------ |
| sMobile   | 手机号   | string | 不能为空；11位           | UTF-8 | 必须     |
| sCode     | 短信验证码 | string | 不能为空；              | UTF-8 | 必须     |
| sPassword | 密码    | string | 6位，至少包含数字，字母或字符2种· | UTF-8 | 必须     |

#### 响应值

| 值    | 含义   |
| ---- | ---- |
| 200  | ok   |

#### 返回

**成功**

````
{
"success": true,
"errorCode": 0,
"fieldErrors": [],
"msg": "",
}
````

**失败**

````
{"success":false,
"errCode":XXX,
"fieldErrors": [
  "sMobile":"手机号码格式不正确",
  "sCode":"短信验证码不正确"，
  "sPassword":"密码格式不正确"
],
"msg":"该手机号已注册"
}
````



### 登录 ？？？













