Title: 员工接口
Author: libenzhi(libenzhi957@pingan.com.cn)
Tag: 员工管理, 接口

# 员工接口
<br>

### 员工列表
#### Method & URL

`GET` /web/accounts

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| keyword| 搜索关键字（请输入员工姓名或手机号）| string| 可根据实际情况限制关键字长度| UTF8| 可选| 无|
| roleId| 角色Id| int| | UTF8| 可选| 全部|

- 列表数据可根据筛选条件显示

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "count": 2,
      "list": [
        {
          "id":10001,//员工id
          "mobile":"13321998564",//员工手机号
          "name":"张晓",
          "roleName":"管家",
          "houseNum":13,//分配房源数目
          "appiontStartTime":"08:00",//预约开始时间
          "appiontEndTime":"18:00",//预约结束时间
          "createDate":"2017.03.03",//添加日期
          "remark":"备注"//备注
        },
        {
          "id":10002,//员工id
          "mobile":"13321998564",//员工手机号
          "name":"张晓",
          "roleName":"管家",
          "houseNum":13,//分配房源数目
          "appiontStartTime":"08:00",//预约开始时间
          "appiontEndTime":"18:00",//预约结束时间
          "createDate":"2017.03.03",//添加日期
          "remark":"备注"//备注
        }
      ]
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 新建员工
#### Method & URL

`POST` /web/account

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| name| 员工名称| string|不能为空；文本，1-30字符| UTF8| 必须| 无|
| mobile| 手机号| string|不能为空；校验手机号码合法性| UTF8| 必须| 无|
| password| 登录密码| string|不能为空；至少包含数字、字母或字符中两种，至少六位| UTF8| 必须| 无|
| RoleId| 员工角色id| int|不能为空；根据角色管理中角色进行选取| UTF8| 必须| 管家|
| isReceiveAppoint| 是否接受预约| int|不能为空；1：接受，0：不接受| UTF8| 必须| 0|
| appointStartTime| 预约开始时间| string|选择接受预约后，不能为空 格式如：08:00| UTF8| 可选(必须)| 无|
| appointEndTime| 预约结束时间| string|选择接受预约后，不能为空| UTF8| 可选(必须)| 无|
| remark| 备注| string|文本，0-50字符| UTF8| 可选| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Created|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "id":2100223    //员工id
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 读取员工信息
#### Method & URL

`GET` /web/account/detail/{accountId}

#### Content-Type

`JSON`

#### 参数


#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|404|Not Found|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "accountInfo":{//员工基本信息
        "id":10001,//员工id
        "name":"张晓",
        "sNickName":"133 2199 8654",
        "mobile":"13321998564",//员工手机号
        "password":"123456",
        "roleName":"管家",//角色名称
        "isReceiveAppoint":1,//是否接受预约，1:接受,0:不接受
        "appiontStartTime":"08:00",//预约开始时间
        "appiontEndTime":"18:00",//预约结束时间
        "remark":"备注"
      },
      "houseList":[
        {
          "houseId":"10001",
          "buildingName":"欣馨人才公寓",
          "houseResourcetype":2,//房源类型 1集中式 2分散式
          "houseNameArr":["0101"，"0102"，"0201"],
        },
        {
          "houseId":"10002",
          "buildingName":"爱南湖苑",
          "houseResourcetype":1,//房源类型 1集中式 2分散式
          "houseNameArr":["0101"，"0102"，"0201"],
        }
      ]  
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 编辑员工
#### Method & URL

`PUT` /web/account/{id}

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| name| 员工名称| string|不能为空；文本，1-30字符| UTF8| 必须| 无|
| mobile| 手机号| string|不能为空；校验手机号码合法性| UTF8| 必须| 无|
| password| 登录密码| string|不能为空；至少包含数字、字母或字符中两种，至少六位| UTF8| 必须| 无|
| RoleId| 员工角色id| int|不能为空；根据角色管理中角色进行选取| UTF8| 必须| 管家|
| isReceiveAppoint| 是否接受预约| int|不能为空；1：接受，0：不接受| UTF8| 必须| 0|
| appointStartTime| 预约开始时间| string|选择接受预约后，不能为空 格式如：08:00| UTF8| 可选(必须)| 无|
| appointEndTime| 预约结束时间| string|选择接受预约后，不能为空| UTF8| 可选(必须)| 无|
| remark| 备注| string|文本，0-50字符| UTF8| 可选| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Updated|
|401|Unauthorized|
|409|Conflict|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {}
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 删除员工
#### Method & URL

`DELETE` /web/account/{id}

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Deleted|
|401|Unauthorized|
|409|Conflict|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {}
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```

<br>
### 获取员工分配房源列表
#### Method & URL

`GET` /web/account/house/{accountId}

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| accountId| 员工id| string| | UTF8| 必须| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "list": [
        {
          "houseId":"10001",
          "buildingName":"欣馨人才公寓",
          "houseResourcetype":2,//房源类型 1集中式 2分散式
          "houseNameArr":["0101"，"0102"，"0201"],
        },
        {
          "houseId":"10002",
          "buildingName":"爱南湖苑",
          "houseResourcetype":1,//房源类型 1集中式 2分散式
          "houseNameArr":["0101"，"0102"，"0201"],
        }
      ]
    }
  }
```
- 待规划


-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```


<br>

### 分配房源
#### Method & URL

`GET` /web/account/house

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| accountId| 员工id| int|| UTF8| 必须| 无|
| houseResourceType| 房源类型| int|房源类型 1集中式 2分散式| UTF8| 必须| 无|
| houseIdArr| 房源id数组| array|json数组，存放为该员工分配的房源id| UTF8| 必须| 无|

- 需要和后端一起定下房源列表参数形式

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {}
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```