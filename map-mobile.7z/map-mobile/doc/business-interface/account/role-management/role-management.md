Title: 角色接口
Author: libenzhi(libenzhi957@pingan.com.cn)
Tag: 角色管理, 接口

# 角色接口
<br>

### 角色列表
#### Method & URL

`GET` /web/role/list/{storeId}

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| storeId| 所属房行(门店)id| int|| UTF8| 必须| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "count": 4,
      "list": [
        {
          "id":10001,//角色id
          "name":"超级管理员（系统预设）",
          "createDate":"2017.01.01",//添加日期 
          "accountNum":3,//分配员工数目
          "isRoot":1,//是否超级管理员
          "isPreset":1,//是否系统预设，1:是,0:不是
        },
        {
          "id":10002,//角色id
          "name":"管家（系统预设）",
          "createDate":"2017.01.01",//添加日期 
          "accountNum":3,//分配员工数目
          "isRoot":0,//是否超级管理员
          "isPreset":1,//是否系统预设，1:是,0:不是
        },
        {
          "id":10003,//角色id
          "name":"财务（系统预设）",
          "createDate":"2017.01.01",//添加日期 
          "accountNum":3,//分配员工数目
          "isRoot":0,//是否超级管理员
          "isPreset":1,//是否系统预设，1:是,0:不是
        },
        {
          "id":10004,//角色id
          "name":"公寓管家",
          "createDate":"2017.01.01",//添加日期 
          "accountNum":3,//分配员工数目
          "isRoot":0,//是否超级管理员
          "isPreset":0,//是否系统预设，1:是,0:不是
        }
      ]
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 读取角色信息
#### Method & URL

`GET` /web/role/{id}

#### Content-Type

`JSON`

#### 参数


#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|404|Not Found|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "roleInfo":{//角色基本信息
        "id":10001,//角色id
        "name":"超级管理员",//角色名称
        "isPreset":10001,//是否系统预设 1是
      },
      "functionList":[
        {
          "id":100011,//功能id
          "enName":"AXG_ACCOUNT_ROLE_ADD",//功能(模块)英文名称
          "chName":"添加角色",//功能(模块)中文名称
        },
        {
          "id":100012,//功能id
          "enName":"AXG_ACCOUNT_ROLE_MODIFY",//功能(模块)英文名称
          "chName":"编辑角色",//功能(模块)中文名称
        },
      ]
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 添加角色
#### Method & URL

`POST` /web/role

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| storeId| 所属房行(门店)id| int|不能为空；文本，1-30字符| UTF8| 必须| 无|
| roleName| 角色名称| string|不能为空；文本，1-30字符| UTF8| 必须| 无|
| functionIdList| 权限列表| array|"functionIdList": ["100011", "10012", "10013", "10014"] 权限id列表| UTF8| 必须| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Created|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "id":10001//角色id
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 编辑角色
#### Method & URL

`PUT` /web/role/{id}

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| roleName| 角色名称| string|不能为空；文本，1-30字符| UTF8| 必须| 无|
| functionIdList| 权限列表| array|"functionIdList": ["100011", "10012", "10013", "10014"] 权限id列表| UTF8| 必须| 无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Created|
|401|Unauthorized|
|409|Conflict|

#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {}
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 删除角色
#### Method & URL

`DELETE` /web/role/{id}

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

#### 参数

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Deleted|
|401|Unauthorized|
|409|Conflict|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {}
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
