Title: 账户设置接口
Author: shengchenling(shengchenling711@pingan.com.cn)
Tag: 账户，账户设置，接口

# 账户接口
<br>
## 账户设置
<br>
### 账户信息
#### Method & URL

`GET` /api/js/account/{userId}

#### Content-Type

`JSON`

#### 参数

无

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|ok|
|401|Unauthorized|

####返回

-**成功**

{
    "isAuthenticate":"1", //认证状态，0未认证，1已认证，2认证未通过，
    "reason":""//未通过，需要有内容
    "name":"张三", //用户姓名
    "mobile":"13456787654", //手机号
    "IDNumber":"310123567765123432", //用户身份证号
    "businessEntity":"李四", //企业法人
    "company":"上海李四有限公司", //公司名称
    "businessLicense":"营业执照", //营业执照
    "city":"上海", //城市
    "rogin":"徐汇", //区域
    "houseCount":"3000", //房源数量
    "pattern":"混合经营", //公寓运营模式
    "IDPics":[                 //身份证照片，前后两张
        "XXXX.jpg","XXXX.jpg"
    ],
    "businessLicensePics":[
        "XXX.jpg"
    ],
    housePics:[
        "XXX.jpg","XXX.jpg"
    ]

}

#### 缓存

<br>
### 账户名字设置

#### Method & URL

`PATCH` /api/js/account/{userId}

#### Content-Type

`JSON`

#### Cache

#### 参数

|名称|解释|类型|限制|编码|可选(必须)|默认|
|---|---|---|---|---|---|---|
|name|用户名|string|不能为空；|UTF-8|必须|无|

#### HTTP响应值

|值|含义|
|201|ok|
|401|Unauthorized|

#### 返回

-**成功**

    {
        "name":"张三"  //用户名
    }

-**失败**

    {
      "errorCode": "null",
      "fieldErrors": {
        "name": "不能位数字",
      },
      "message": "参数不符合要求"
    }

<br>
### 验证登陆

#### Method & URL

`GET` /api/js/account/{userId}

#### Content-Type

`JSON`

#### 参数

|名称|解释|类型|限制|编码|可选(必须)|默认|
|---|---|---|---|---|---|---|
|password|登陆密码|strig|不能为空|UTF-8|必须|无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|201|Updated|
|401|Unauthorized|

#### 返回

-**成功**



-**失败**

{
      "errorCode": "null",
      "fieldErrors": {
      },
      "message": "密码错误"
    }

<br>

### 修改手机号

#### Method & URL

`PATCH` /api/js/account/{userId}

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
|mobile|手机号|string|不能为空;11位|UTF-8|必须|无|
|smsCode|短信验证码|string|不能为空；|UTF-8|必须|无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
| 201 | ok |
| 401 | Unauthorized |

#### 返回

-**成功**

-**失败**

{
      "errorCode": "null",
      "fieldErrors": {
        "smsCode": "短信验证码错误"
      },
      "message": "短信验证码错误"
}

<br>
### 修改密码

#### Method & URL

#### Method & URL

`PATCH` /api/js/account/{userId}

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
|password|密码|string|不能为空;|UTF-8|必须|无|
|newPassword|新密码|string|不能为空；|UTF-8|必须|无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
| 201 | ok |
| 401 | Unauthorized |

#### 返回

-**成功**

-**失败**

{
      "errorCode": "null",
      "fieldErrors": {
        "password": "原始密码错误"，
        "newPassword": "不能与原来密码相同"，
      },
      "message": "不能与原来密码相同"
}

<br>
### 更改公寓名称

#### Method & URL

`PATCH` /api/js/account/{userId}

#### Content-Type

`JSON`

#### Cache


#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
|brandName|密码|string|不能为空;|UTF-8|必须|无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
| 201 | ok |
| 401 | Unauthorized |

#### 返回

-**成功**

-**失败**

{
      "errorCode": "null",
      "fieldErrors": {
      },
      "message": ""
}