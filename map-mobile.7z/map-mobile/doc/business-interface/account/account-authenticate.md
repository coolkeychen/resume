Title: 账户认证
Author: lixiang(lixiang664@pingan.com.cn)
Tag: 账户认证, 接口

# 账户认证接口
<br>
### 账户认证
#### Method & URL

`POST` /api/js/account/{userId}

#### Content-Type

`JSON`

#### 参数

|名称|解释|类型|限制|编码|可选(必须)|默认|
|---|---|---|---|---|---|---|
|name|用户名|string|不能为空；|UTF-8|必须|无|
|isCompany|是否公司|boolean|不能为空；|UTF-8|必须|无|
|mobile|手机号码|string|不能为空；|UTF-8|必须|无|
|IDNumber|身份证号|string|不能为空；|UTF-8|必须|无|
|businessEntity|企业法人|string|不能为空；|UTF-8|必须|无|
|company|公司|string|不能为空；|UTF-8|必须|无|
|businessLicense|营业执照|string|不能为空；|UTF-8|必须|无|
|city|城市|string|不能为空；|UTF-8|必须|无|
|rogin|区域|string|不能为空；|UTF-8|必须|无|
|houseCount|房源数量|string|不能为空；|UTF-8|必须|无|
|pattern|经营模式|string|不能为空；|UTF-8|必须|无|
|IDPics|身份证照片|array|不能为空；|UTF-8|必须|无|
|cibusinessLicensePicsty|营业执照照片|array|不能为空；|UTF-8|必须|无|
|housePics|房源照片|array|不能为空；|UTF-8|必须|无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|ok|
|401|Unauthorized|

####返回

-**成功**

{
    "isAuthenticate":"1", //认证状态，0未认证，1已认证，2认证未通过，
    "reason":""//未通过，需要有内容
    "name":"张三", //用户姓名
    "mobile":"13456787654", //手机号
    "IDNumber":"310123567765123432", //用户身份证号
    "businessEntity":"李四", //企业法人
    "company":"上海李四有限公司", //公司名称
    "businessLicense":"营业执照", //营业执照
    "city":"上海", //城市
    "rogin":"徐汇", //区域
    "houseCount":"3000", //房源数量
    "pattern":"混合经营", //公寓运营模式
    "IDPics":[                 //身份证照片，前后两张
        "XXXX.jpg","XXXX.jpg"
    ],
    "businessLicensePics":[
        "XXX.jpg"
    ],
    housePics:[
        "XXX.jpg","XXX.jpg"
    ]

}

-**失败**

{
      "errorCode": "null",
      "fieldErrors": {
        "mobile": "手机号码也是不正确",
      },
      "message": "参数不符合要求"
    }

#### 缓存

<br>
### 编辑认证
#### Method & URL

`PUT` /api/js/account/{userId}

#### Content-Type

`JSON`

#### 参数

|名称|解释|类型|限制|编码|可选(必须)|默认|
|---|---|---|---|---|---|---|
|name|用户名|string|不能为空；|UTF-8|必须|无|
|isCompany|是否公司|boolean|不能为空；|UTF-8|必须|无|
|mobile|手机号码|string|不能为空；|UTF-8|必须|无|
|IDNumber|身份证号|string|不能为空；|UTF-8|必须|无|
|businessEntity|企业法人|string|不能为空；|UTF-8|必须|无|
|company|公司|string|不能为空；|UTF-8|必须|无|
|businessLicense|营业执照|string|不能为空；|UTF-8|必须|无|
|city|城市|string|不能为空；|UTF-8|必须|无|
|rogin|区域|string|不能为空；|UTF-8|必须|无|
|houseCount|房源数量|string|不能为空；|UTF-8|必须|无|
|pattern|经营模式|string|不能为空；|UTF-8|必须|无|
|IDPics|身份证照片|array|不能为空；|UTF-8|必须|无|
|cibusinessLicensePicsty|营业执照照片|array|不能为空；|UTF-8|必须|无|
|housePics|房源照片|array|不能为空；|UTF-8|必须|无|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|ok|
|401|Unauthorized|

####返回

-**成功**

{
    "isAuthenticate":"1", //认证状态，0未认证，1已认证，2认证未通过，
    "reason":""//未通过，需要有内容
    "name":"张三", //用户姓名
    "mobile":"13456787654", //手机号
    "IDNumber":"310123567765123432", //用户身份证号
    "businessEntity":"李四", //企业法人
    "company":"上海李四有限公司", //公司名称
    "businessLicense":"营业执照", //营业执照
    "city":"上海", //城市
    "rogin":"徐汇", //区域
    "houseCount":"3000", //房源数量
    "pattern":"混合经营", //公寓运营模式
    "IDPics":[                 //身份证照片，前后两张
        "XXXX.jpg","XXXX.jpg"
    ],
    "businessLicensePics":[
        "XXX.jpg"
    ],
    housePics:[
        "XXX.jpg","XXX.jpg"
    ]

}

-**失败**

{
      "errorCode": "null",
      "fieldErrors": {
        "mobile": "手机号码也是不正确",
      },
      "message": "参数不符合要求"
    }

#### 缓存

<br>