Title: 服务接口
Author: libenzhi(libenzhi957@pingan.com.cn)
Tag: 服务, 接口

# 服务接口
<br>

### 推广房源列表
#### Method & URL

`GET` /web/phouses

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| keyword| 搜索关键字（请输入公寓名，房间名，租客名，房东名或手机号）| string| 可根据实际情况限制关键字长度| UTF8| 可选| 无|
| audit_status| 审核状态| string| | UTF8| 可选| 不限|
| shelf_status| 货架状态| string| | UTF8| 可选| 不限|
| page| 页码| int| | UTF8| 可选| 0|
| page_size| 页数| int| | UTF8| 可选| 10-20|

- 列表数据可根据筛选条件显示

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "count": 4,
      "list": [
        {
          "id":1,//主键ID
          "first_name":"欣馨人才公寓",//楼栋或小区名
          "second_name":"标准间",//户型
          "audit_text":"审核通过",//审核状态
          "shelf_text":"上架",//货架状态
          "review_remarks":"给予通过",//审核备注
          "channel_text":"平安好房，58",//渠道
        },
        {
          "id":2,//主键ID
          "first_name":"欣馨人才公寓",//楼栋或小区名
          "second_name":"标准间",//户型
          "audit_text":"审核通过",//审核状态
          "shelf_text":"上架",//货架状态
          "review_remarks":"给予通过",//审核备注
          "channel_text":"平安好房，58",//渠道
        }
      ]
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 推广房源统计
#### Method & URL

`GET` /web/statistics

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| option| 选项| string| 统计选项[1 //空置房间2 //已租房间3 //应收未收款4 //今日收款5 //发房数量6 //审核通过7 //审核驳回8 //上架房源数]| UTF8| 必须| option="5,6,7,8"|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "count_publish_room": 100,//发房数量
      "count_audit_pass_room": 90,//审核通过
      "count_audit_reject_room": 10,//审核驳回
      "count_putaway_room": 80,//上架房源数
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 发房
#### Method & URL

`POST` /web/houses/{housing_id}/[layout/layout_id]/publish

#### Content-Type

`JSON`

#### 参数

| 名称 | 解释 | 类型 | 限制 | 编码 | 可选(必须) | 默认 |
|---|---|---|---|---|---|---|
| type| 发布类型| int| 发布类型 1.集中式，layout_id必传；2.分散式，layout_id可不传| UTF8| 必须| 无|
| channel| 渠道| int| | UTF8| 必须| 10-20|

#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "id": 1,//发房ID
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 上架
#### Method & URL

`PATCH` /web/phouses/{id}/up

#### Content-Type

`JSON`

#### 参数


#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|404|Not Found|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "id": 1,//上架所属发房ID
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```
<br>

### 下架
#### Method & URL

`PATCH` /web/phouses/{id}/down

#### Content-Type

`JSON`

#### 参数


#### HTTP响应值

| 值 | 含义 |
|---|---|
|200|OK|
|404|Not Found|
|401|Unauthorized|


#### 返回

-**成功**
```
  {
    "success": true,
    "errorCode": 0,
    "fieldErrors": [],
    "msg": "",
    "data": {
      "id": 1,//下架所属发房ID
    }
  }
```

-**失败**
```
  {
    "success": false,
    "errorCode": 1000,
    "fieldErrors": [
      {
        "fieldName": "name",
        "msg": "具体报错"
      }
    ],
    "msg": "接口获取失败",
    "data": {}
  }
```