import { getBuildList, getWifiBuilding } from 'biz/services/map/outdoor.js';
import { message } from 'antd';

let defaultState = {
  buildListGeojson: {},
  wifibuildimg: {},
}

export default {
  namespace: 'outdoor',
  state: {
    name:'室外地图',
    ...defaultState
  },
  effects: {
    * getBuildList({ payload },{ call,put }) {
      const { globalError, data } = yield call(getBuildList, payload);
      if (data) {
        yield put({
          type: 'putBuildList',
          payload: {
            data: data
          }
        })
      } 
    },
    * getWifiBuilding({ payload },{ call, put }) {
      const { globalError, data } = yield call(getWifiBuilding, payload);
      if (data) {
        yield put({
          type: 'putWifiBilding',
          payload: {
            data: data
          }
        })
      }
    }
  },
  reducers: {
    putBuildList(state, action) {
      return {
        ...state,
        buildListGeojson: action.payload.data
      }
    },
    putWifiBilding(state, action) {
      return {
        ...state,
        wifibuildimg: action.payload.data
      }
    },
  }
}