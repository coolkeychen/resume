import { getBuiildingDetail, getGeojson, getPluginList} from 'biz/services/map/indoor.js';
import { message } from 'antd';
import _ from 'underscore';

const defaultState = {
    detail: {},
	geojson: {},
	apjson :{
		"type": "FeatureCollection",
		"features": [
			{
				"type": "Feature",
				"properties": {},
				"geometry": {
					"type": "Point",
					"coordinates": [
						118.05870652198792,
						24.595690003010663
					]
				}
			}
		]
	},
	componentList : [],
	pluginGrounp: {},
	pluginList: [],
}

export default {
    namespace: 'indoor',
    state: {
        ...defaultState
    },
    effects: {
		* getBuildingDetail({ payload }, { call, put }) {
			const { globalError, data } = yield call(getBuiildingDetail, payload);
			let pointers = [];
			if(data) {
                yield put({
                    type: 'putDeteal',
                    payload: {
                        data
                    }
                })

				yield put({
					type: 'getGeojson',
					payload: {
						url: data.mapPath
					}
				})

				/* const { apsList, componentList } = data;
				const pluginBlendList = apsList.concat(componentList);
				delete data.apsList;
				delete data.componentList;

				pluginBlendList.forEach((item, index) => {
					const plugin = _.find(pluginList, (l) => {
						return l.id === item.deviceId;
					})
					pointers.push({ coordinate: [item.locx, item.locy], name: `${item.deviceId}_${moment.now() + index}`, url: plugin.iconPath, type: plugin.type })
				})

				yield put({
					type: 'putPointers',
					payload: {
						pointers
					}
				}) */
				
				if (!_.isEmpty(data.wifiComponentMapDTO)) {
					yield put({
						type: 'putComponentJson',
						payload: {
							data: data.wifiComponentMapDTO
						}
						
					})
				}
				/* if (!_.isEmpty(data.componentList)) {
					yield put({
						type: 'putComponentJson',
						payload : {
							data: data.componentList
						}
					})
				} */
			}

		},
        * getGeojson({payload}, { call, put }) {
			const { data } = yield call(getGeojson, payload.url);
			const tmpData = typeof data === 'string' ? JSON.parse(decodeURIComponent(data.replace(/\\/g, "%"))): data;

			if(data) {
				yield put({
					type: 'putGeojson',
					payload: tmpData
				})
			}
		},
/* 		* getPluginList({ payload }, { call, put }) {
			const { data } = yield call(getPluginList, payload);

			if (data) {
				yield put({
					type: 'putPluginGrounp',
					payload: {
						pluginList: data
					}
				})
			}
		}, */
    },
    reducers: {
        putDeteal(state, action) {
            return {
				...state,
				detail: action.payload.data
			}
        },
        putGeojson(state, action) {
			return {
				...state,
				geojson: action.payload
			}
		},
		putComponentJson(state,action) {
			console.log(action.payload.data);
			return {
				...state,
				componentList: action.payload.data
			}
		},
		/* putPluginGrounp(state, action) {
			const pluginList = action.payload.pluginList;
			const pluginGrounp = _.groupBy(pluginList, 'type');

			return {
				...state,
				pluginGrounp,
				pluginList
			}
		} */
    }
}


