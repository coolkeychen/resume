








export default {
	namespace: 'reset',
	state: {
		loginLoading: false
	}

}