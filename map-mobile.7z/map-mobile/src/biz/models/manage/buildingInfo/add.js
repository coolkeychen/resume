
import { getBuiildingDetail, postBuiilding, getGeojson} from 'biz/services/manage/buildingInfo.js';
import { message } from 'antd';

const defaultState = {
	detail: {
		
	},
	geojson: {},
	pointers: [{"coordinate":[118.0586075224521,24.595693012115127],"name":"dianshi"},{"coordinate":[118.05859329332507,24.595682260909705],"name":"kongtiao0"},{"coordinate":[118.05862089510543,24.59567887760532],"name":"kongtiao1"},{"coordinate":[118.05860700422458,24.5956690072164],"name":"kongtiao2"}]
}

export default {
	namespace: 'addBuildingInfo',
	state: {
		...defaultState
	},
	effects: {
		* putBuildingData({ payload }, { call, put }) {
			const { globalError, data } = yield call(postBuiilding, payload);

			if(globalError) {
				message.error(globalError)
			} else {
				history.back();
			}
		},

		* getBuildingDetail({payload}, { call, put }) {
			const { globalError, data } = yield call(getBuiildingDetail, payload);
			if(data) {
				yield put({
					type: 'putBuildingDetail',
					payload: {
						detail: data
					}
				})
			} 
			if(data && /editfloormap/.test(location.pathname)) {
				const  geoJson = yield put({
					type: 'getGeojson',
					payload: {
						url: data.mapPath
					}
				})
			}
		},

		* getGeojson({payload}, { call, put }) {
			const { data } = yield call(getGeojson, payload.url);
			console.log(data)
			if(data) {
				yield put({
					type: 'putGeojson',
					payload: data
				})
			}
		}
	},
	reducers: {
		resetState(state, action) {
			return {
				...defaultState
			}
		},
		putBuildingDetail(state, action) {
			return {
				...state,
				detail: {
					...action.payload.detail
				}
			}
		},
		putGeojson(state, action) {
			return {
				...state,
				geojson: action.payload
			}
		},
		putPointers(state, action) {
			console.log(action.payload.pointers)
			return {
				...state,
				pointers: action.payload.pointers
			}
		}
	}
}