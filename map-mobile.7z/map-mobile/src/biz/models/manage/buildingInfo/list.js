
import { PAGE_SIZE } from 'common/global/const';
import { effectsCreate, reducers } from 'biz/models/modelCreator';
import { getBuiildingList, deleteBuilding } from 'biz/services/manage/buildingInfo.js';
import { message } from 'antd';

let defaultState = {
  list: null,
  total: 0,
  searchParams: {
    pageSize: PAGE_SIZE
  },
  isSearch: false
};

export default {
	namespace: 'buildingInfoList',
	state : {
		'name': '楼宇信息',
		...defaultState
	},
	effects: {
		...effectsCreate(),
		* list({ payload }, { call, put, select }) {
			const params = yield select(state => state['buildingInfoList']['searchParams']);
			const { data, globalError } = yield call(getBuiildingList, params)

	        if(globalError) {
	          message.error(globalError)
	        } else {
	          yield put({
	            type: 'putList',
	            payload: {
	              data: data
	            }
	          })
	        }
		},

		* deleteFloor({ payload }, { call, put }) {
	        const { globalError } = yield call(deleteBuilding, payload)
	        if(globalError) {
	          message.error(globalError)
	        } else {
	          yield put({
	            type: 'list'
	          })
	        }
        }

	},

	reducers: {
		...reducers,
		putList(state, action) {
	        const list = action.payload.data.list;
	        const total = action.payload.data.total;
	        return {
		        ...state,
		        list,
		        total
	        }
        }
	}

}