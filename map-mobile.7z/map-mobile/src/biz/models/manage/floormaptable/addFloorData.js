
import { postLouyu, getLouyuDetail } from 'biz/services/manage/floormaptable';
import { message } from 'antd';

const defaultState = {
	detail: {

	}
}


export default {
	namespace: 'addFloorData',
	state: {
		...defaultState
	},
	effects: {
		* putLouyuData({ payload }, { call, put }) {
			const { globalError } = yield call(postLouyu, payload)
			if(globalError) {
				message.error(globalError)
			} else {
				location.href = '/manage/mapdata/floormaptable';
			}
		},

		* getLouyuDetail({payload}, { call, put }) {
			const { globalError, data } = yield call(getLouyuDetail, payload);
			if(data) {
				yield put({
					type: 'putLouyuDetail',
					payload: {
						detail: data
					}
				})
			} 
		}
	},
	reducers: {
		resetState(state, action) {
			return {
				...defaultState
			}
		},
		putLouyuDetail(state, action) {
			return {
				...state,
				detail: {
					...state.detail,
					...action.payload.detail
				}
			}
		},
		updateCoordinate(state, action) {
			return {
				...state,
				detail: {
					...state.detail,
					locx: action.payload.data[0],
					locy: action.payload.data[1],	
				}
			}
		}
	}
}