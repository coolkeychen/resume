
import { PAGE_SIZE } from 'common/global/const';
import { effectsCreate, reducers } from 'biz/models/modelCreator';
import { getLouyuList, deleteLouyu } from 'biz/services/manage/floormaptable.js';
import { message } from 'antd';

let defaultState = {
  list: null,
  total: 0,
  searchParams: {
    pageSize: PAGE_SIZE
  },
  isSearch: false,
};

export default {
  namespace: 'floormaptable',
  state: {
    ...defaultState
  },
  subscriptions: {
    setup({ dispatch, history, userInfo }) {
      history.listen(({ pathname, query }) => {
          
      });
    },
  },
  effects: {
      ...effectsCreate(),

      * list({ payload }, { call, put, select }) {
        let params = yield select(state => state['floormaptable']['searchParams']);
        if(params.locIn) params.locIn = JSON.stringify(JSON.parse(params.locIn)[0]);

        const { data } = yield call(getLouyuList, params)
        if(data) {
          yield put({
            type: 'putList',
            payload: {
              data: data
            }
          })
        }
      },

      * deleteFloor({ payload }, { call, put }) {
        const { globalError } = yield call(deleteLouyu, payload)
        if(globalError) {
          yield put({
            type: 'list'
          })
        }
      }

  },
  reducers: {
    ...reducers,
    resetState(state, action) {
      return {
        ...defaultState
      }
    },
    putList(state, action) {
      const list = action.payload.data.list;
      const total = action.payload.data.total;
       return {
        ...state,
        list,
        total
       }
     }
  }
}