import { PAGE_SIZE } from 'common/global/const';
import { notification, message } from 'antd';
import { routerRedux } from 'dva/router'
import _ from 'underscore';

const constants = {
  effectsCreate() {
    return {
      * handleResponse({ payload, }, { call, put }) {
        let { callback, response, extra, errorHandle } = payload;
        let { data, globalError, fieldErrors } = response;

        let isSuccess = true;
        if (globalError) {
          message.error(globalError, 4);
          isSuccess = false;
        }
        if (fieldErrors) {
          yield put({
            type: 'clearError',
          });

          yield put({
            type: 'putFieldError',
            payload: { fieldErrors, }
          });

          if (errorHandle) {
            yield put({
              type: errorHandle,
              payload: { fieldErrors, }
            });
          }

          isSuccess = false;
        }
        if (isSuccess) {

          yield put({
            type: callback,
            payload: { data, extra }
          });
        }
      },
    };
  },

  reducers: {
    paramsChange(state, action) {
      return {
        ...state,
        searchParams: {
          ...state.searchParams,
          ...action.payload,
        },
      };
    },

    putFieldError(state, action) {
      const { formId, fieldErrors } = action.payload;
      const errorText = formId ? formId + 'fieldErrors' : 'fieldErrors';

      let realErrors = fieldErrors.reduce(
        (realErrors, { fieldName, msg }) => {
          realErrors[fieldName] = msg;
          return realErrors;
        },
        {}
      );

      return {
        ...state,
        [errorText]: { ...realErrors },
      };
    },

    clearError(state) {
      return {
        ...state,
        fieldErrors: {}
      }
    },

    clearEntity(state, action) {
      return {
        ...state,
        entity: {},
        fieldErrors: {},
      }
    },

    reset(state, action) {
      return {
        ...state,
        ...action.payload
      };
    },

    resetAndParseUrl(state, action) {
      const { defaultState, query } = action.payload;
      return {
        ...state,
        ...defaultState,
        ...query
      };
    },

    setToSearch(state, action) {
      return {
        ...state,
        isSearch: true
      };
    },

    clearSearch(state, action) {
      return {
        ...state,
        isSearch: false
      };
    },
  },
};

export default constants;
