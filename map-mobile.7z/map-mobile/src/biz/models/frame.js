import { parse } from 'qs';
import { notification, Modal } from 'antd';
import _ from 'underscore';
import { routerRedux } from 'dva/router';

import { menulist } from 'common/global/menudata';

import { CRUMB, MENUS } from 'common/global/const';
import userInfoStore from 'common/global/userInfo';


//扁平化左边的菜单栏
const dataNameSpace = function(data) {
    let pathMap = [];

    function* splitList(jsonData) {
      for( let i = 0; i < jsonData.length; i++ ) {
        if(jsonData[i].url) {
          yield { url: jsonData[i].url };
        }
        if(jsonData[i].children) {
          yield* splitList(jsonData[i].children);
        }
      }

    }

    for( let item of splitList(data) ) {
      pathMap.push(item);
    }
    return pathMap;
}

export default {
  namespace: 'frame',
  state: {
    userId: 111,
    userName: '林炎祥',
    sider: {
      menus: menulist,
      current: '',
      openKey: ''
    },

  },
  subscriptions: {
    setup({ dispatch, history }) {
      history.listen(({ pathname, query }) => {
          //自动配置菜单栏
          const openKey = pathname.split('/')[2];
          const pathMap = dataNameSpace(menulist);
          let current = null;

          pathMap.forEach(item => {
            const reg = new RegExp(item.url);
          
            if(reg.test(pathname)) {
              current = item.url;
            }
          })

          dispatch({
            type: 'putCurrentSubmenu',
            payload: {
                  openKey: openKey,
                  current: current
                }
          })

      });
    },
  },
  effects: {
    
  },
  reducers: {

     putCrumbData(state, action) {
        const crumbsData = action.payload.crumbsData;
        // console.log(crumbsData)
        return {
          ...state,
          crumbsData
        }
     },
     putCurrentPath(state, action) {
        const current = action.payload.current;
        return {
          ...state,
          sider: {
            ...state.sider,
            current
          }
        }
     },
     putCurrentSubmenu(state, action) {
        const openKey = action.payload.openKey;
        const current = action.payload.current;
    
        return {
          ...state,
          sider: {
            ...state.sider,
            openKey: openKey,
            current: current
          }
        }
     }
  },
};
