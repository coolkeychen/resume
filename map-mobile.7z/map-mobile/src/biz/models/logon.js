








export default {
	namespace: 'logon',
	state: {
		loginLoading: false
	}

}