import { connect } from 'dva';
import React, { PropTypes } from 'react';
import { Link } from 'react-router';
import { Button } from 'antd';

function Page({id}) {

  return (
    <div className="warn-wrapper-content" id={ id || "content" }>
      <div className="warn-wrapper">
        <div className="warn-image unauth" />
        <div className="warn-label">哎呀，您没有访问该页面的权限~</div>
        <Link className="ant-btn-primary ant-btn" to={`/index`}>返回首页</Link>
      </div>
    </div>
  );
}

Page.propTypes = {
};

export default connect(({}) => ({}))(Page);
