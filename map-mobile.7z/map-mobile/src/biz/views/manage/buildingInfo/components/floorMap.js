import React, { PropTypes } from 'react';
import ReactDOM from 'react-dom';

import Map from 'ol/map';
import View from 'ol/view';
import VectorLayer from 'ol/layer/vector';
import TileLayer from 'ol/layer/tile';
import OSM from 'ol/source/osm';
import Vector from 'ol/source/vector';
import Interaction from 'ol/interaction';
import Stroke from 'ol/style/stroke';
import Circle from 'ol/style/circle';
import Draw from 'ol/interaction/draw';
import Proj from 'ol/proj';
import Overlay from 'ol/overlay';
import Select from 'ol/interaction/select';
import DragBox from 'ol/interaction/dragbox';
import Feature from 'ol/feature';
import Geojson from 'ol/format/geojson';

import Control from 'ol/control';
import Style from 'ol/style/style';
import Fill from 'ol/style/fill';
import Text from 'ol/style/text';
import Polygon from 'ol/geom/polygon';
import Point from 'ol/geom/point';
import olIcon from 'ol/style/icon';

import condition from 'ol/events/condition';
import { Icon } from 'antd'

import 'biz/../../node_modules/ol/ol.css';

const ol = { Map, View, VectorLayer, TileLayer, OSM, Vector, Interaction, Stroke, Circle,
            Draw, Proj, Overlay, Select, DragBox, Feature, Geojson, Control, Style, Fill, 
            Text, Polygon, Point, olIcon, condition };

class EditFloor extends React.Component {
    
	constructor() {
		super();
		Object.keys(ol).forEach(item => {this[item] = ol[item];})
	}
	componentDidMount = () => {
    	const layerTile = new TileLayer({
    		source: new OSM({
    			wrapX: false
    		})
		})
		

		let { layers, defaultControls, extendControls, view, target, drawAreaParam, overlayCoordinates, overlays, vectorSource, paintCountry } = this.props;

    	layers = layers || [];
    	defaultControls = defaultControls || {};
    	extendControls = extendControls || [];
		view = view || {};
		overlays = overlays || [];
		vectorSource = vectorSource || null;

    	this.map = new Map({
    	   target: target,
		   layers: [layerTile, ...layers ],
    	   controls: new Control.defaults({ ...defaultControls}).extend(extendControls || []),
    	   view: new View({
    	   		...view
    	   })
		})
		// overlays && overlays.length && this.popupFloor(overlays);
	}

	render() {
		return (
			<div id={this.target}></div>
		)
	}

}

export default EditFloor;


