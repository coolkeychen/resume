import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router';

import { Table, Col, Row, Form, Input, Button, Icon, Modal, message } from 'antd';


import BaseFilteredList from 'components/biz/BaseFilteredList';
import ListResultStatus from 'components/biz/listResultStatus';
import SelectMapLanlat from 'components/biz/selectMapLanlat';

import { createPageConfig } from 'common/utils/transform';
import { rowClassName } from 'common/utils/tools';
import { getCrumbsData, queryURL } from 'common/utils/tools';

const FormItem = Form.Item;

//import './index.less';


class BuildingInfo extends  BaseFilteredList {

  columns = [
    {title: '楼层id', key: 'id', dataIndex: 'id'},
    {title: '楼层', key: 'floor', dataIndex: 'floor'},
    {title: '高度', key: 'height', dataIndex: 'height'}, 
    {title: 'geojson文件地址', key: 'mapPath', dataIndex: 'mapPath', render: (text, row) => (
        <a href={text}>{row.fileOriginalName}</a>
    )},
    {title: '楼层名', key: 'name', dataIndex: 'name'},
    {'title': '操作', key: 'openration', dataIndex: 'id', render: (text, row) => {
      return <div>
        <Link to={`/manage/mapdata/buildinginfo/edit?id=${text}&buildingid=${this.buildingid}&louyuX=${this.louyuX}&louyuY=${this.louyuY}`}>修改楼层信息</Link>&nbsp;&nbsp;&nbsp;&nbsp;
        <Link to={`/manage/mapdata/apmanage?floorid=${text}&buildingid=${this.buildingid}&louyuX=${this.louyuX}&louyuY=${this.louyuY}`}>查看楼层AP信息</Link>
        &nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:;" onClick={this.deleteFloor(text)}>删除</a>&nbsp;&nbsp;&nbsp;&nbsp;
        { row.mapPath && <Link to={`/manage/mapdata/buildinginfo/editfloormap?floorid=${text}&buildingid=${this.buildingid}&louyuX=${this.louyuX}&louyuY=${this.louyuY}`}>编辑楼层地图信息</Link>}
      </div>
    }}  
  ]

  static propTypes = {
    location: PropTypes.object.isRequired,
    dispatch: PropTypes.func.isRequired,
    floormaptable: PropTypes.object.isRequired,
  }

  constructor() {
    super();
    this.module = 'buildingInfoList';
  }
  initCrumbsData = () => {
    this.buildingid = queryURL('buildingid');
    this.louyuX = queryURL('louyuX');
    this.louyuY = queryURL('louyuY');
    const { dispatch, routes } = this.props;

    getCrumbsData(routes, dispatch, );

    if(this.buildingid) {
      this.props.dispatch({
        type: 'buildingInfoList/paramsChange',
        payload: {
          id: this.buildingid
        }
      })
    }
    this.props.dispatch({
      type: 'frame/putCurrentPath',
      payload: {
        current: '/manage/mapdata/floormaptable'
      }
    })
  }
  deleteFloor = (id) => {
    const { dispatch } = this.props;
    return () => {
      dispatch({
        type: `${this.module}/deleteFloor`,
        payload: {
          id: id
        }
      })
    }
  }

  render = () => {
    console.log(this.props);
    const { buildingInfoList } = this.props;
    const { searchParams, list, isSearch } = buildingInfoList;
    let pageConfig = createPageConfig(buildingInfoList, this.list);

    return (
      <div className="floor-manage-wrapper">
        <Row  style={{paddingBottom: '10px'}}>
            <Button style={{float: 'right'}}>
             <Link to={`/manage/mapdata/buildinginfo/add?buildingid=${this.buildingid}&louyuX=${this.louyuX}&louyuY=${this.louyuY}`}>
             添加楼层信息
             </Link>
            </Button>
        </Row>
        {
          !!list && !!list.length &&
          <div className="list-result">
            <Table bordered columns={ this.columns } dataSource={ list } pagination={ pageConfig } rowClassName={rowClassName}/>
          </div>
        }
        {
          !!!(list && list.length) &&
          <ListResultStatus list={list} isSearch={isSearch} listEmptyTitle='还没有楼层信息哦~' />
        }
      </div>
    );

  }
}

export default connect(({ buildingInfoList }) => ({ buildingInfoList }))(BuildingInfo);
