import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { Form, Input, Icon, Button } from 'antd';
import Label from 'components/common/label';
import SelectMapLanlat from 'components/biz/selectMapLanlat';
import ExcelUploader from 'components/common/excelUploader';
import { getCrumbsData, queryURL } from 'common/utils/tools';

import breadcrumbdata from 'common/global/breadcrumbdata';

const FormItem = Form.Item;

//import './index.less';

class AddBuildingInfo extends React.Component {

  module = 'addBuildingInfo';
  static propTypes = {
    location: PropTypes.object.isRequired,
    dispatch: PropTypes.func.isRequired,
    addBuildingInfo: PropTypes.object.isRequired,
  }
  initCrumbsData = () => {
    const { dispatch, routes } = this.props;
    const path = routes.map(route => route.path).join('/').replace(/\/\//, '/');
    let crumbsData = breadcrumbdata[path];

    crumbsData[2]['path'] = `/manage/mapdata/buildinginfo?buildingid=${this.buildingid}&louyuX=${this.louyuX}&louyuY=${this.louyuY}`;
    getCrumbsData(routes, dispatch, crumbsData);
  }

  componentWillMount = () => {
    const { dispatch, frame } = this.props;
    this.id = queryURL('id')
    this.buildingid = queryURL('buildingid')
    this.louyuX = queryURL('louyuX')
    this.louyuY = queryURL('louyuY')
    this.initCrumbsData();
    
    dispatch({
      type: `${this.module}/resetState`,
    })
    
    dispatch({
      type: 'frame/putCurrentPath',
      payload: {
        current: '/manage/mapdata/floormaptable'
      } 
    })
    if(this.id) { 
      dispatch({
        type: `${this.module}/getBuildingDetail`,
        payload: {
          id: this.id
        }
      })
    }
  }

  
  handldSumbit = () => {
     const { form, dispatch } = this.props;
     const { validateFields } = form;

     validateFields((err, val) => {
      if(err) return;
      val.floor = typeof val.floor === 'string' ? parseInt(val.floor) : val.floor;
      val.height = typeof val.height === 'string' ? parseInt(val.height) : val.height;
      val.buildingid = this.buildingid;
      if(this.id) val.id = this.id;
      val.mapPath = val.fileList[0].response.data.relativePath;
      val.fileOriginalName = val.fileList[0].response.data.fileName;
      delete val.fileList;
      dispatch({
        type: `${this.module}/putBuildingData`,
        payload: val
      })
     })
  }

  render = () => {
    const { getFieldDecorator } = this.props.form;
    const { detail } = this.props.addBuildingInfo;
    let fileList = [];
    if(detail && detail.mapPath) {
      fileList.push({
        name: detail.fileOriginalName,
        uid: 1,
        status: 'done'
      })
    }
    return (
      <div className="add-floor-info">
        <Form>
          <FormItem label='楼层'>
            {getFieldDecorator('floor', {
              initialValue: detail.floor || '',
              validateTrigger: 'onBlur',
              rules: [{
                required: true,
                message: '楼层必填'
              }]
            })(
              <Input type='text' placeholder="请输入楼层" style={{width: '220px'}}/>
            )}
          </FormItem>
          <FormItem label='楼层高度'>
            {getFieldDecorator('height', {
              initialValue:  detail.height || '',
              validateTrigger: 'onBlur',
              rules: [{
                required: true,
                message: '楼层高度必填'
              }, {
                pattern: new RegExp('^\\d\{1,3\}\(\\.\\d+\)\?$'),
                message: '楼层高度输入的格式错误'
              }]
            })(
              <Input type='text' placeholder="请输入楼宇经度" style={{width: '220px'}}/>
            )}
          </FormItem>
          <FormItem label='楼层名称'>
            {getFieldDecorator('name', {
              initialValue: detail.name || '',
              validateTrigger: 'onBlur',
              rules: [{
                required: true,
                message: '楼宇名称必填'
              }]
            })(
              <Input type='text' placeholder="请输入楼宇名称" style={{width: '220px'}}/>
            )}
          </FormItem>
          <FormItem label='上传geojson文件'>
              {getFieldDecorator('fileList', {
                  initialValue: fileList,
                  rules: [{
                    required: true,
                    message: '文件必须上传'
                  }]
                })(
                  <ExcelUploader  />
                )
              }
                
          </FormItem>
          <FormItem>
             <Button type="primary" size={'default'} onClick={this.handldSumbit} className="create-submit">提交</Button>
          </FormItem>
        </Form>
      </div>
    );
  }}

export default connect(({ addBuildingInfo, frame }) => ({ addBuildingInfo, frame }))(Form.create()(AddBuildingInfo));
