import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router';

import { queryURL } from 'common/utils/tools';

import { Icon } from 'antd';
import FloorMap  from 'components/biz/selectMapLanlat';
import { app } from 'components/common/dragIcon';
import _ from 'underscore';

import './index.less';

class EditFloorMap extends React.Component {
    selectCoordinateObj = null;
    module = 'addBuildingInfo';
    source = [];
    feature = [];
    index = 0;
    singClickEvent = null;
    constructor() {
    	super();
    }

    componentWillMount = () => {
        this.louyuX = queryURL('louyuX');
        this.louyuY = queryURL('louyuY');
        this.floorid = queryURL('floorid');

        this.props.dispatch({
            type: `${this.module}/resetState`
        })

        this.props.dispatch({
            type: `${this.module}/getBuildingDetail`,
            payload: {
                id: this.floorid
            }
        });
    }
       
    selectInteraction = () => {
        const { Interaction, map, Select } = this.selectCoordinateObj;
        const self = this;
        this.select = new Select();
        map.un('singleclick');
        //map.addInteraction(select);
        this.select.on('select', function(e) {
            e.target.getFeatures().getArray().every(function(feature) {
                const coodinates = feature.getGeometry().getCoordinates();
                self.features.forEach((item, index) => {
                    const Gcoordinate = item.geometry.coordinates;
                    if(_.isEqual(coodinates, Gcoordinate)) {
                        //console.log(feature.getProperties())
                    }
                })
            })
        });
        return this.select;
    }
    doubleClickIcon = () => {
        const { map } = this.selectCoordinateObj;
        map.un('singleclick');
        map.on('dbclick', (evt) => {
            console.log(1212)
            const Feature = map.forEachFeatureAtPixel(evt.pixel, (feature) => {
                // if(feature.getGeometry().getType() === 'Point') {
                //     const view = map.getView();
                //     console.log(111)
                //     console.log(view);
                //     console.log(view.getZoom())
                //     view.setZoom(view.getZoom() - 1)
                // }
                console.log(feature)
            })
            console.log(Feature, 222)

        })
    } 
    dragElectricIcon = (name, newCoordinate) => {
        const { pointers } = this.props.addBuildingInfo;
        for(let i = 0; i < pointers.length; i++) {
            if(pointers[i]['name'] === name) {
                pointers[i]['coordinate'] = newCoordinate;
            }
        }
        this.props.dispatch({
            type: `${this.module}/putPointers`,
            payload: {
                pointers: pointers
            }
        });
        this.addPointerLayers(pointers);
    }

    addElectricIcon = () => {
        const { map } = this.selectCoordinateObj;
        let { pointers } = this.props.addBuildingInfo;
        //let self = this;
        if(this.singClickEvent) {
            map.un('singleclick', this.singClickEvent);  
        }
        this.singClickEvent = (evt) => {
            pointers.push({coordinate: evt.coordinate, name: `kongtiao_${this.index++}${Math.random()}`});
            this.props.dispatch({
                type: `${this.module}/putPointers`,
                payload: {
                    pointers: pointers
                }
            });
            this.addPointerLayers(pointers);
        };

        map.on('singleclick', this.singClickEvent)

    }

    listenViewChange = () => {
        const { map } = this.selectCoordinateObj;
        const self = this;

        // 监听地图层级变化
        map.getView().on('change:resolution', function(){
            let that = this;
            self.feature.forEach( (anchor) => {

                var style = anchor.getStyle();

                // 重新设置图标的缩放率，基于层级20来做缩放
                style.getImage().setScale(that.getZoom() / 20);
                anchor.setStyle(style);   
            })
        })
    }

    addPointerLayers = (pointers) => {
        const { map, Vector, VectorLayer, Circle, Fill, Stroke,
                Interaction, Point, Feature, Style, olIcon} = this.selectCoordinateObj;
        map.removeInteraction(new app('Point', this.dragElectricIcon));
        this.source.forEach( (item, index) => {
            item.clear();
        })

        pointers.forEach( (item, index )=> {
            this.source[index] = new Vector();
            this.feature[index] = new Feature({
                geometry: new Point(item.coordinate),
                name: item.name
            });
            const vectorLayer = new VectorLayer({
                source: this.source[index]
            });
            this.feature[index].setStyle(new Style({
                    image: new Circle({
                    fill: new Fill({
                        color: 'rgba(255,0,0,0.8)'
                    }),
                    stroke: new Stroke({
                        color: 'rgb(255,0,0)',
                        width: 2
                    }),
                    radius: 5

                }) 
            }));
            map.addLayer(vectorLayer);
            this.source[index].addFeature(this.feature[index])
        })
        map.addInteraction(new app('Point', this.dragElectricIcon));
    }

	render() {
        let layers = [];
        const { geojson, detail, pointers } = this.props.addBuildingInfo;

        if(this.selectCoordinateObj &&  !_.isEmpty(geojson) && !this.select) {
            const { map, Vector, VectorLayer, Geojson, Circle, Fill, Stroke,
                Interaction, Point, Feature, Style, PluggableMap, olIcon} = this.selectCoordinateObj;
            //var pointFeature = new Feature(new Point([118.05881258587897, 24.595455700331335]));
            this.vectorlayer = new VectorLayer({
                source: new Vector({
                    features: (new Geojson()).readFeatures(geojson)
                })
            });
            this.features = geojson.features;
            //this.addOverlays([[118.05881258587897, 24.595455700331335]]);
            map.addLayer(this.vectorlayer);
            //添加点的渲染
            this.addPointerLayers(pointers)
            map.addInteraction(new app('Point', this.dragElectricIcon));
             // 监听singleclick事件
            this.addElectricIcon();
            this.listenViewChange();
            map.addInteraction(this.selectInteraction());
            this.doubleClickIcon();
            console.log(2323)
        };



		return (
			<div className='floor-manage-edit-map'>
				<FloorMap view={{center: [parseFloat(this.louyuX), parseFloat(this.louyuY) + 0.0002], projection: 'EPSG:4326', zoom: 21, minZoom: 21}}
                ref={el => this.selectCoordinateObj = el}
                cssStyle={{height: '100%'}}
                //drawAreaParam={{shape: 'Point', isSource: false, selectCoordinate: (data) => { this.selectCoordinate(data) }}}
                target={"mapModal"}/>
                <div className='floor-manage-edit-left'>
                </div>
			</div>
		)
	}
}


export default connect(({ addBuildingInfo }) => ({ addBuildingInfo }))(EditFloorMap);