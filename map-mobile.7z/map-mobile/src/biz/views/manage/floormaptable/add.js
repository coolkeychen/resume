import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { Form, Input, Icon, Button } from 'antd';
import Label from 'components/common/label';
import SelectMapLanlat from 'components/biz/selectMapLanlat';
import { getCrumbsData, queryURL } from 'common/utils/tools';

const FormItem = Form.Item;

import './index.less';

class AddFloorData extends React.Component {
  selectmapObj = null;
  module = 'addFloorData';
  index = 0;
  static propTypes = {
    location: PropTypes.object.isRequired,
    dispatch: PropTypes.func.isRequired,
    addFloorData: PropTypes.object.isRequired,
  }
  initCrumbsData = () => {
    const { dispatch, routes } = this.props;
    getCrumbsData(routes, dispatch)
  }
  componentWillMount = () => {
    const { dispatch } = this.props;
    const id = queryURL('id');
    this.initCrumbsData();
    dispatch({
      type: `${this.module}/resetState`
    })
    if(id) {
      dispatch({
        type: `${this.module}/getLouyuDetail`,
        payload: {
          id: id
        }
      })
    }
  }

  addOverlay = (coordinate) => {
    if(!coordinate.length) return;
    let overlayArray = [];
    const { addFloorData } = this.props;

    overlayArray = coordinate.map( (item, index )=> {
      return {
              element: <Icon type="environment-o" className={`over-lay`}/>,
              coordinate: item,
              className: `overlay-wrapper over-lay-${index}`
          }
    })
    this.selectmapObj.addOverlays(overlayArray)
  }
  
  handldSumbit = () => {
     const { form, dispatch } = this.props;
     const { validateFields } = form;

     validateFields((err, val) => {
      if(err) return;
      val.locx = typeof val.locx === 'string' ? parseFloat(val.locx) : val.locx;
      val.locy = typeof val.locy === 'string' ? parseFloat(val.locy) : val.locy;
      val.maxFloor = typeof val.maxFloor === 'string' ? parseInt(val.maxFloor) : val.maxFloor;
      if(queryURL('id')) val.id = queryURL('id');
      dispatch({
        type: `${this.module}/putLouyuData`,
        payload: val
      })
     })
  }

  selectCoordinate = (data) => {
    let overLays = document.querySelector('.overlay-wrapper');
    console.log(overLays)
    const { setFieldsValue } = this.props.form
    overLays && overLays.remove() || ++this.index;
    this.addOverlay([data]);
    setFieldsValue({locx: data[0], locy: data[1]})
    
    this.props.dispatch({
      type: `${this.module}/updateCoordinate`,
      payload: {
        data
      }
    })
  }

  componentWillUnmount = () => {
    this.index = 0;
  }

  render = () => {
    const { getFieldDecorator } = this.props.form;
    const { detail } = this.props.addFloorData;
    if(this.selectmapObj && detail.locx && detail.locy && !this.index) {
      this.addOverlay([[detail.locx, detail.locy]]);
      this.index++;
    }
    return (
      <div className="add-floor-info">
        <Form>
          <FormItem label='楼宇地址'>
            {getFieldDecorator('address', {
              initialValue: detail.address || '',
              validateTrigger: 'onBlur',
              rules: [{
                required: true,
                message: '楼宇地址必填'
              }]
            })(
              <Input type='text' placeholder="请输入楼宇地址" style={{width: '220px'}}/>
            )}
          </FormItem>
          <FormItem label='经度'>
            {getFieldDecorator('locx', {
              initialValue:  detail.locx || '',
              validateTrigger: 'onBlur',
              rules: [{
                required: true,
                message: '经度必填'
              }, {
                pattern: new RegExp('^\\d\{1,3\}\(\\.\\d+\)\?$'),
                message: '经度输入的格式错误'
              }]
            })(
              <Input type='text' placeholder="请输入楼宇经度" style={{width: '220px'}}/>
            )}
          </FormItem>
          <FormItem label='纬度'>
            {getFieldDecorator('locy', {
              initialValue: detail.locy || '',
              validateTrigger: 'onBlur',
              rules: [{
                required: true,
                message: '纬度'
              },{
                pattern: new RegExp('^\\d\{1,3\}\(\\.\\d+\)\?$'),
                message: '经度输入的格式错误'
              }]
            })(
              <Input type='text' placeholder="请输入楼宇纬度" style={{width: '220px'}}/>
            )}
          </FormItem>
          <FormItem label='地图上选择经纬度'>
            <SelectMapLanlat view={{center: [116.23,39.54], projection: 'EPSG:4326', extend: [3.86, 73.66, 53.55, 135.05], zoom: 4}} 
            ref={ el => this.selectmapObj = el }
            drawAreaParam={{shape: 'Point', isSource: false, selectCoordinate: (data) => { this.selectCoordinate(data) }}}
            target="mapPoint"/>
          </FormItem>
          <FormItem label='楼宇名称'>
            {getFieldDecorator('name', {
              initialValue: detail.name || '',
              validateTrigger: 'onBlur',
              rules: [{
                required: true,
                message: '楼宇名称必填'
              }]
            })(
              <Input type='text' placeholder="请输入楼宇名称" style={{width: '220px'}}/>
            )}
          </FormItem>
          <FormItem label='最大楼层'>
            {getFieldDecorator('maxFloor', {
              initialValue: detail.maxFloor || '',
              validateTrigger: 'onBlur',
              rules: [{
                required: true,
                message: '最大楼层必填'
              }, {
                pattern: new RegExp('^[1-9]\\d*$'),
                message: '请输入最大楼层正整数'
              }]
            })(
              <Input type='text' placeholder="请输入最大楼层" style={{width: '220px'}}/>
            )}
          </FormItem>
          <FormItem>
             <Button type="primary" size={'default'} onClick={this.handldSumbit} className="create-submit">提交</Button>
          </FormItem>
        </Form>
      </div>
    );
  }
}

export default connect(({ addFloorData }) => ({ addFloorData }))(Form.create()(AddFloorData));
