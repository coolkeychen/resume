import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router';

import { Table, Col, Row, Form, Input, Button, Icon, Modal, message } from 'antd';

import BaseFilteredList from 'components/biz/BaseFilteredList';
import ListFilterForm from 'components/biz/listFilterForm';
import ListResultStatus from 'components/biz/listResultStatus';
import SelectMapLanlat from 'components/biz/selectMapLanlat';
import breadcrumbdata from 'common/global/breadcrumbdata';

import FormHandle from 'components/decorator/formHandle';
import { createPageConfig } from 'common/utils/transform';
import { rowClassName, getCrumbsData } from 'common/utils/tools';

const FormItem = Form.Item;

import './index.less';
let formModal = null;

class FilterForm extends ListFilterForm {
  
  render() {
    const { form, isSearch, addressLike, maxFloor, locIn, nameLike } = this.props;
    formModal = form;
    const { getFieldDecorator } = formModal;

    return (
        <Form  layout="inline">
          <FormItem>
            {
              getFieldDecorator('addressLike', {
                initialValue: addressLike || '',
              })(
                <Input style={{ width: '220px' }} placeholder="请输入地址" onChange={this.onChange('addressLike', false)}/>,
              )
            }
          </FormItem>
          <FormItem>
            {
              getFieldDecorator('locIn', {
                initialValue: locIn || '',
              })(
                <Input style={{ width: '220px' }} placeholder="请输入坐标数组" 
                suffix={<Icon type="environment-o" onClick={ () => { this.props.onClickShowMap(true) } } style={{fontSize: '18px', color: '#5986e1', cursor: 'pointer'}}/>}
                className="floor-manage-suffix"
                onChange={ this.onChange('locIn', false)}  />,
              )
            }
          </FormItem>
          <FormItem>
            {
              getFieldDecorator('nameLike', {
                initialValue: nameLike || '',
              })(
                <Input style={{ width: '220px' }} placeholder="请输入地址名称" onChange={this.onChange('nameLike', false)}/>,
              )
            }
          </FormItem>
          <Button type="primary" size={'default'} style={{ marginRight: '12px' }} onClick={this.props.onSubmit}>搜索</Button>
          { isSearch && <Button type="primary" size={'default'}
          className="axg-button-like-link" onClick={this.clear}>重置</Button> }
        </Form>
    )
  }

}

const FilterFormWrapper = Form.create()(FormHandle(FilterForm));


class Floormaptable extends BaseFilteredList {
  selectCoordinateObj = null;
  columns = [
    {title: 'id', key: 'id', dataIndex: 'id'},
    {title: '地址', key: 'address', dataIndex: 'address'},
    {title: '经度', key: 'locx', dataIndex: 'locx'}, 
    {title: '纬度', key: 'locy', dataIndex: 'locy'},
    {title: '地址名称', key: 'name', dataIndex: 'name'},
    {'title': '操作', key: 'openration', dataIndex: 'id',render: (text, row) => {
      return <div>
        <Link to={`/manage/mapdata/floormaptable/edit?id=${text}`}>修改楼宇信息</Link>&nbsp;&nbsp;&nbsp;&nbsp;
        <Link to={`/manage/mapdata/buildinginfo?buildingid=${text}&louyuX=${row.locx}&louyuY=${row.locy}`}>查看楼层信息</Link>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="javascript:;" onClick={this.deleteBuilding(text)}>删除</a>
      </div>
    }}  
  ]

  static propTypes = {
    location: PropTypes.object.isRequired,
    dispatch: PropTypes.func.isRequired,
    floormaptable: PropTypes.object.isRequired,
  }
  constructor() {
    super();
    this.module = 'floormaptable';
    this.state = {
      isShowMap: false
    }
  }
  initCrumbsData = () => {
    const { dispatch, routes } = this.props;
    getCrumbsData(routes, dispatch);
    this.props.dispatch({
      type: 'floormaptable/resetState'
    })
  }
  deleteBuilding = (id) => {
    const { dispatch } = this.props;
    return () => {
      dispatch({
        type: `${this.module}/deleteFloor`,
        payload: {
          id: id
        }
      })
    }
  }
  selectCoordinate = (data) => {
    const self = this;
    this.setState({
      ...self.state,
      locIn: data
    })
  }

  onClickShowMap = (bool) => {
    this.setState({
      isShowMap: true
    })
  }

  closeModal = () => {
    this.setState({
      isShowMap: false
    })
  }
  
  confirmModal = () => {
    const self = this;
    const { getSlotLayers } = this.selectCoordinateObj;
    if(!self.state.locIn.length) { return message.error('请选择地图区域')};
    getSlotLayers(1).getSource().clear();

    this.props.dispatch({
        type: `${this.module}/paramsChange`,
        payload: {
          locIn: JSON.stringify(self.state.locIn)
        }
    })
    
    this.setState({
      ...self.state,
      isShowMap: false
    })
  }

  render = () => {
    
    const { isShowMap } = this.state;
    const { floormaptable } = this.props;
    const { searchParams, isSearch, list } = floormaptable;
    let pageConfig = createPageConfig(floormaptable, this.list);

    return (
      <div className="floor-manage-wrapper">
        <div className="list-filter-form">
          <Row>
            <Col span={24} >
              <FilterFormWrapper 
              {...searchParams}
              onSubmit={ () => this.list(searchParams) }
              onClear={ this.clear }
              isSearch={true}
              onChange={ this.onSearchChange }
              onClickShowMap={ this.onClickShowMap } />
            </Col>
          </Row>
        </div>
        <Row  style={{paddingBottom: '10px'}}>
            <Button style={{float: 'right'}}><Link to="/manage/mapdata/floormaptable/add">添加楼宇</Link></Button>
        </Row>
        {
          !!list && !!list.length &&
          <div className="list-result">
            <Table bordered columns={ this.columns } dataSource={ list } pagination={ pageConfig } rowClassName={rowClassName}/>
          </div>
        }
        {
          !!!(list && list.length) &&
          <ListResultStatus list={list} isSearch={isSearch} listEmptyTitle='还没有楼宇信息哦~' />
        }
        <Modal
          title="请选择地图区域"
          visible={isShowMap}
          width={'90%'}
          onClose={ this.closeModal }
          onOk={ this.confirmModal }
        >
        <SelectMapLanlat view={{center: [116.23,39.54], projection: 'EPSG:4326', extend: [3.86, 73.66, 53.55, 135.05], zoom: 4}} 
        drawAreaParam={{shape: 'Polygon', isSource: true, selectCoordinate: (data) => { this.selectCoordinate(data) }}}
        ref={el => this.selectCoordinateObj = el}
        target={"mapModal"}/>
        </Modal>
      </div>
    );

  }
}

export default connect(({ floormaptable }) => ({ floormaptable }))(Floormaptable);
