import React, { PropTypes } from 'react';
import { connect } from 'react-redux';

import { SearchBar } from 'antd-mobile';

import './search.less';


class Search extends React.Component {
    /* static propTypes = {
        location: PropTypes.object.isRequired,
        dispatch: PropTypes.func.isRequired,
    } */
    constructor() {
        super();
        this.module = 'search';
        
    }

    render() {
        
        const { searchPlaceholder } = this.props;

        return (
            <div className="search-container">
                <SearchBar placeholder={searchPlaceholder} showCancelButton={false} disabled/>
            </div>
        );
    }
}

export default connect()(Search);