import React, { PropTypes } from 'react';
import { connect } from 'react-redux';

import { Modal, Button,List } from 'antd-mobile';
import './floorList.less';
import { Link } from 'react-router';
import _ from 'underscore';

function closest(el, selector) {
    const matchesSelector = el.matches || el.webkitMatchesSelector || el.mozMatchesSelector || el.msMatchesSelector;
    while (el) {
        if (matchesSelector.call(el, selector)) {
            return el;
        }
        el = el.parentElement;
    }
    return null;
}


class FloorList extends React.Component {
    listItem =[];
    constructor(props) {
        super(props);
        this.state = {
            isShow: true
        };
    }

    onWrapTouchStart = (e) => {
        // fix touch to scroll background page on iOS
        if (!/iPhone|iPod|iPad/i.test(navigator.userAgent)) {
            return;
        }
        const pNode = closest(e.target, '.am-modal-content');
        if (!pNode) {
            e.preventDefault();
        }
    }

    onClose = () => {
        this.props.transferShowFloorList();
    }


    render() {
        const { visiable, distance } = this.props;
        let outputDistance = 0, distanceUnit = '公里';
        if (distance > 1000) {
            outputDistance = (Math.round(distance / 1000 * 100) / 100);
            distanceUnit = '公里';
        } else {
            outputDistance = (Math.round(distance * 100) / 100);
            distanceUnit = '米';
        }
        const { wifibuildimg } = this.props.outdoor;
        
        const buidlingFloorList = wifibuildimg.buidlingFloorList;

       /*  const buidlingFloorList = [
            {
                apsList: null,
                buildingid: "b1c37887d5414f04ad86a6c8cc5e67c8",
                componentList: null,
                fileOriginalName: "map-20180509003.json",
                floor: 2,
                height: 12.2,
                id: "776f408059c211e8a838005056906feb",
                lochash: null,
                mapPath: "maps/2018-05-17/c143177e78c74e59bd628b6872853905.json",
                name: "复仇者联盟二"
            },
            {
                apsList: null,
                buildingid: "b1c37887d5414f04ad86a6c8cc5e67c8",
                componentList: null,
                fileOriginalName: "map-20180509003.json",
                floor: 2,
                height: 12.2,
                id: "776f408059c211e8a838005056906feb",
                lochash: null,
                mapPath: "maps/2018-05-17/c143177e78c74e59bd628b6872853905.json",
                name: "复仇者联盟二"
            },
            {
                apsList: null,
                buildingid: "b1c37887d5414f04ad86a6c8cc5e67c8",
                componentList: null,
                fileOriginalName: "map-20180509003.json",
                floor: 2,
                height: 12.2,
                id: "776f408059c211e8a838005056906feb",
                lochash: null,
                mapPath: "maps/2018-05-17/c143177e78c74e59bd628b6872853905.json",
                name: "复仇者联盟二"
            },
            {
                apsList: null,
                buildingid: "b1c37887d5414f04ad86a6c8cc5e67c8",
                componentList: null,
                fileOriginalName: "map-20180509003.json",
                floor: 2,
                height: 12.2,
                id: "776f408059c211e8a838005056906feb",
                lochash: null,
                mapPath: "maps/2018-05-17/c143177e78c74e59bd628b6872853905.json",
                name: "复仇者联盟二"
            },
            {
                apsList: null,
                buildingid: "b1c37887d5414f04ad86a6c8cc5e67c8",
                componentList: null,
                fileOriginalName: "map-20180509003.json",
                floor: 2,
                height: 12.2,
                id: "776f408059c211e8a838005056906feb",
                lochash: null,
                mapPath: "maps/2018-05-17/c143177e78c74e59bd628b6872853905.json",
                name: "复仇者联盟二"
            },
            {
                apsList: null,
                buildingid: "b1c37887d5414f04ad86a6c8cc5e67c8",
                componentList: null,
                fileOriginalName: "map-20180509003.json",
                floor: 2,
                height: 12.2,
                id: "776f408059c211e8a838005056906feb",
                lochash: null,
                mapPath: "maps/2018-05-17/c143177e78c74e59bd628b6872853905.json",
                name: "复仇者联盟二"
            },
            {
                apsList: null,
                buildingid: "b1c37887d5414f04ad86a6c8cc5e67c8",
                componentList: null,
                fileOriginalName: "map-20180509003.json",
                floor: 2,
                height: 12.2,
                id: "776f408059c211e8a838005056906feb",
                lochash: null,
                mapPath: "maps/2018-05-17/c143177e78c74e59bd628b6872853905.json",
                name: "复仇者联盟二"
            },
            {
                apsList: null,
                buildingid: "b1c37887d5414f04ad86a6c8cc5e67c8",
                componentList: null,
                fileOriginalName: "map-20180509003.json",
                floor: 2,
                height: 12.2,
                id: "776f408059c211e8a838005056906feb",
                lochash: null,
                mapPath: "maps/2018-05-17/c143177e78c74e59bd628b6872853905.json",
                name: "复仇者联盟二"
            },
        ] */


        if (!_.isEmpty(buidlingFloorList) && _.isArray(buidlingFloorList)) {
            this.listItem = buidlingFloorList.map((item) =>
                <li><Link to={`/map/indoor?floorid=${item.id}&buildingid=${item.buildingid}&louyuX=${wifibuildimg.louyuX}&louyuY=${wifibuildimg.louyuY}`}>{item.floor }</Link></li>
            );
        }
        
        return (
            <div >
                <Modal 
                    popup 
                    visible={ visiable} 
                    animationType="slide-up"
                    onClose={this.onClose}
                >
                <div className="floor-container">
                    
                    {!_.isEmpty(buidlingFloorList) &&<div className="floor-list">
                        <ul>
                            {wifibuildimg.buidlingFloorList.map((item, index) => {
                                return (
                                    <li key={index}>
                                        <Link to={`/map/indoor?floorid=${item.id}&buildingid=${item.buildingid}&louyuX=${wifibuildimg.louyuX}&louyuY=${wifibuildimg.louyuY}`}>{`${item.floor}F`}</Link>
                                    </li>
                                )
                            })}
                        </ul>
                    </div>}
                    <div className="floor-detail">
                        <div className="POI-name">
                            <p className="build-name">{ wifibuildimg.name }</p>
                                <p className="build-distance">距您<span className="distance"> {outputDistance}</span> {' '+distanceUnit}</p>
                        </div>
                        <div className="POI-addr">
                            <p className="addr">{wifibuildimg.address}</p>
                            {!_.isEmpty(wifibuildimg.phoneNumber) && <p className="phoneNumber">{wifibuildimg.phoneNumber}</p>}
                        </div>
                    </div>
                </div>                   
                </Modal> 
            </div>
        );
    }
}

export default connect(({ outdoor }) => ({ outdoor }))(FloorList);

