import React, { PropTypes } from 'react';
import { connect } from 'react-redux';

import _ from 'underscore';

import { Layout, Spin, Modal,Icon } from 'antd';


import LayerVector from 'ol/layer/vector';
import SourceVector from 'ol/source/vector';
import GeoJSON from 'ol/format/geojson';
import Style from 'ol/style/style';
import Fill from 'ol/style/fill';
import Stroke from 'ol/style/stroke';
import Text from 'ol/style/text';
import Overlay from 'ol/overlay';
import Point from 'ol/geom/point';
import proj from 'ol/proj';
import View from 'ol/view';
import XYZ from 'ol/source/xyz';
import TileLayer from 'ol/layer/tile';
import ScaleLine from 'ol/control/scaleline';
import Sphere from 'ol/sphere';
import olIcon from 'ol/style/icon';
import Geolocation from 'ol/geolocation';


import SelectMapLanlat from 'components/biz/selectMapLanlat';
import SearchBar from '../search/search'
import FloorList from '../floorList/floorList'


import 'static/css/main.less';
import './outdoor.less'

class Outdoor extends React.Component {
  selectCoordinateObj = null;
  view = {};
  defaultLayer = [];
  selectFeature = {};
  styleCache = {};
  
  static propTypes = {
    location: PropTypes.object.isRequired,
    dispatch: PropTypes.func.isRequired,
  }

  constructor() {
    super();
    this.state = {
      isShowFloorList : false,
      distance : 0,
      isShowBuild: false,
      locPosition: [],
      selectFeature: {},
      layer: {},
      transExtend: []
    }
    this.module = 'outdoor';
  }

 
  componentWillMount = () => {
    /* this.props.dispatch({
      type: `${this.module}/countryVectorMap`,
    }) */
    // this.initMap();
    this.buildLayer = new LayerVector({
      source: new SourceVector({})
    })
  }

  componentDidMount = () => {
    let self = this;
    const { map } = this.selectCoordinateObj;

    if (this.selectCoordinateObj) {
      const { map, Geolocation, Feature, Style, Circle, Fill, Stroke, VectorLayer, Vector, Cluster,Proj } = this.selectCoordinateObj;
      const geolocation = new Geolocation({
        projection: map.getView().getProjection(),
        tracking: true
      });

      
      // 
      geolocation.once('change', function (evt) {
        const locPosition = geolocation.getPosition();
        map.getView().setCenter(locPosition);
        map.getView().setResolution(2.388657133911758);
      });

      geolocation.on('change', function (evt) {
        const locPosition = geolocation.getPosition();
        self.state.locPosition = proj.transform(locPosition, 'EPSG:3857', 'EPSG:4326');
      })

      const accuracyFeature = new Feature();
      geolocation.on('change:accuracyGeometry', function () {
        accuracyFeature.setGeometry(geolocation.getAccuracyGeometry());
      });

      let Svg = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30px" height="30px" viewBox="0 0 30 30" enable-background="new 0 0 30 30" xml:space="preserve">' +
        '<path fill="#156BB1" d="M22.906,10.438c0,4.367-6.281,14.312-7.906,17.031c-1.719-2.75-7.906-12.665-7.906-17.031S10.634,2.531,15,2.531S22.906,6.071,22.906,10.438z"/>' +
      '<circle fill="#FFFFFF" cx="15" cy="10.677" r="3.291"/></svg>';
      // let Svg = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><defs><style>.cls-1{fill:#fff;}.cls-2{fill:#08a1e9;fill-rule:evenodd;}</style></defs><circle class="cls-1" cx="24" cy="24" r="24"/><path class="cls-2" d="M24.05,10.77,12.42,32.35a1,1,0,0,0,1.31,1.39l9.85-4.55a1,1,0,0,1,.84,0l10.11,4.67a1,1,0,0,0,1.33-1.33l-10-21.71A1,1,0,0,0,24.05,10.77Z"/></g></g></svg>';
      let img = new Image();
      img.src = 'data:image/svg+xml,' + escape(Svg);

      const positionFeature = new Feature();
      positionFeature.setStyle(new Style({
        image: new olIcon({
          img: img,
          imgSize: [26, 26],
        })
      }));

      geolocation.on('change:position', function () {
        let coordinates = geolocation.getPosition();
        positionFeature.setGeometry(coordinates ?
          new Point(coordinates) : null);
      });


      const PositionLayer = new VectorLayer({
        map: map,
        source: new Vector({
          features: [ positionFeature]
        })
      });
      map.addLayer(PositionLayer);

      const viewExtend = map.getView().calculateExtent(map.getSize());
      this.state.transExtend = Proj.transformExtent(viewExtend, 'EPSG:3857', 'EPSG:4326');
      this.props.dispatch({
        type: `${self.module}/getBuildList`,
        payload: {
          getWay: 'EXTENT',
          extent: this.state.transExtend + ''
        }
      });
      this.getMapExtend();
    }
  }


  
  // 获取范围
  getMapExtend = () => {
    const self = this;
    const { map, Proj, Select, condition } = this.selectCoordinateObj;

    map.on('moveend', function () {
      const viewExtend = map.getView().calculateExtent(map.getSize());
      let transExtend = Proj.transformExtent(viewExtend, 'EPSG:3857', 'EPSG:4326');

      self.props.dispatch({
        type: `${self.module}/getBuildList`,
        payload: {
          getWay: 'EXTENT',
          extent: transExtend+''
        }
      });
      self.renderBuildList();
    });
  }


  // 获取距离
  getStraightLintDistance = (endPosition) => {
    const self = this;
    const { map, Proj, Select, condition } = this.selectCoordinateObj;
    const startPosition = proj.transform(map.getView().getCenter(), 'EPSG:3857', 'EPSG:4326');
    let wgs84Sphere = new Sphere(6378137);
    const distance = wgs84Sphere.haversineDistance(self.state.locPosition, endPosition);
    return distance;
    
  }

  // 选择楼宇
  selectBuild = (layer) => {
    const self = this;
    const { map, Select, Condition, Circle, Fill, Stroke, Text } = this.selectCoordinateObj;

    self.state.selectFeature = new Select({
      multi: false,
      layers: [layer]
    });

    map.getInteractions().extend([self.state.selectFeature]);


    self.state.selectFeature.on('select', function (event) {
      // const featurePosition = event.target.getFeatures()[0].getArray()[0].getGeometry().getCoordinates();
      const selectFeature = event.selected[0].values_.features[0];
      const featurePosition = selectFeature.getGeometry().getCoordinates();

      const selectPosition = proj.transform(featurePosition, 'EPSG:3857', 'EPSG:4326');
      const selectDistance = self.getStraightLintDistance(selectPosition);
      const buildId = selectFeature.get('id');
      
      self.setState({
        isShowFloorList: true,
        distance: selectDistance,
      });

      self.props.dispatch({
        type: `${self.module}/getWifiBuilding`,
        payload: {
          id: buildId,
          platform: 'mobile'
        }
      });
    });
  }


  // 切换显示状态
  transferShowFloorList = () => {
    const {map} = this.selectCoordinateObj;
    let self = this;
    let clear = {};
    if (!_.isObject(self.state.selectFeature)) {
      clear = self.state.selectFeature.getFeatures().clear();
      self.setState({
        selectFeature: clear,
      });
    }

    this.setState({
      isShowFloorList: !this.state.isShowFloorList,
      
    });
  }

  buildStyle = (feature, resolution) => {
    let self = this;
    const { Style, olIcon, Fill, Circle, Stroke } = this.selectCoordinateObj;

    const features = feature.get('features');
    const size = features.length;
    // console.log(features);

    // const type = feature.get('name');
    const threshold = 1;
    // const type = (resolution < 100 && resolution > 50) ? feature.get('name') : '';
    const type = features[0].get('name');
    if (size > threshold) {
      if (!self.styleCache[type]) {
        self.styleCache[type] = new Style({
          image: new Circle({
            radius: 9,
            fill: new Fill({
              color: '#b4e3f8'
            }),
            stroke: new Stroke({
              color: '#08a0e8',
              width: 2
            })
          }),
          text: new Text({
            font: '12px Calibri,sans-serif',
            fill: new Fill({
              color: '#313131'
            }),
            offsetX: 30,
            offsetY: 10,
          })
        });
      }
    } else {
      if (!self.styleCache[type]) {
        self.styleCache[type] = new Style({
          image: new Circle({
            radius: 9,
            fill: new Fill({
              color: '#b4e3f8'
            }),
            stroke: new Stroke({
              color: '#08a0e8',
              width: 2
            })
          }),
          text: new Text({
            text: type,
            font: '12px Calibri,sans-serif',
            fill: new Fill({
              color: '#313131'
            }),
            offsetX: 30,
            offsetY: 10,
          })
        });
      }
    }
    
    return [self.styleCache[type]];
  }

  getText =  (feature, resolution) => {
    const { map } = this.selectCoordinateObj;
    console.log(resolution);
    console.log(map.getView().getZoom());
    let text = feature.get('name');
    const Zoom = map.getView().getZoom();
    const maxResolution = 800;
    if (Zoom > 12) {
      text = '';
    } 

    return text;
  };
  
  // 渲染楼宇
  renderBuildList =()=> {
    const self = this;
    const { buildListGeojson } = this.props.outdoor;
    const { map, VectorLayer, Vector, Geojson, Circle, Stroke, Style, Fill, addOverlays, Select, Cluster } = this.selectCoordinateObj;
    if (!_.isEmpty(buildListGeojson.features)) {
      const source = new Vector({
        features: (new Geojson()).readFeatures(buildListGeojson, {
          dataProjection: 'EPSG:4326',
          featureProjection: 'EPSG:3857'
        })
      });

      const clusterDistance = 30;

      const clusterSource = new Cluster({
        distance: clusterDistance,
        source: source
      });  

      self.state.layer = new VectorLayer({
        source: clusterSource,
        style: self.buildStyle
      }); 

      map.addLayer(self.state.layer);

      /* self.state.layer = new VectorLayer({
        source: source,
        style: self.buildStyle
      }) 

      
      map.addLayer(self.state.layer);
      
      */
      self.selectBuild(self.state.layer);
    }
  }

  // 回到定位点
  fly2Location = () => {
    const { map, Geolocation } = this.selectCoordinateObj;
    const geolocation = new Geolocation({
      projection: map.getView().getProjection(),
      tracking: true
    });

    geolocation.once('change', function (evt) {
      map.getView().setCenter(geolocation.getPosition());
      map.getView().setResolution(2.388657133911758);
    });

    map.getView().setRotation(0);
    // console.log(location);
    /* const { map, Geolocation } = this.selectCoordinateObj;
    map.getView().setCenter(proj.transform(this.state.locPosition, 'EPSG:3857', 'EPSG:4326')); */
  }


  render = () => {
    const { outdoor } = this.props;
    const { buildListGeojson } = this.props.outdoor;
    let self = this;

    
    this.defaultView = new View({
      center: proj.transform([116.403694, 39.915599], 'EPSG:4326', 'EPSG:3857'), 
      zoom: 10.1,
      maxZoom: 21,
      minZoom: 3
    });
    
    const scaleLineControl = new ScaleLine({
      minWidth: '50'
    });


    this.layerTile = new TileLayer({
      source: new XYZ({
        url: 'http://wprd0{1-4}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&style=7&x={x}&y={y}&z={z}'
      })
    });


    if (this.selectCoordinateObj && !_.isEmpty(buildListGeojson.features)) {
      this.renderBuildList();
    }
    
/*     if (this.selectCoordinateObj) {
      
      console.log(this.selectCoordinateObj);
      const { map, Geolocation, Feature, Style, Circle, Fill, Stroke, VectorLayer, Vector, Cluster, Proj } = this.selectCoordinateObj;


      const geolocation = new Geolocation({
        projection: map.getView().getProjection(),
        tracking: true
      });

      
      geolocation.once('change', function (evt) {
        const locPosition = geolocation.getPosition();
        map.getView().setCenter(locPosition);
        map.getView().setResolution(2.388657133911758);
      });

      geolocation.on('change', function (evt) {
        const locPosition = geolocation.getPosition();
        self.state.locPosition = proj.transform(locPosition, 'EPSG:3857', 'EPSG:4326');
      })

      const accuracyFeature = new Feature();
      geolocation.on('change:accuracyGeometry', function () {
        accuracyFeature.setGeometry(geolocation.getAccuracyGeometry());
      });

      let Svg = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30px" height="30px" viewBox="0 0 30 30" enable-background="new 0 0 30 30" xml:space="preserve">' +
        '<path fill="#156BB1" d="M22.906,10.438c0,4.367-6.281,14.312-7.906,17.031c-1.719-2.75-7.906-12.665-7.906-17.031S10.634,2.531,15,2.531S22.906,6.071,22.906,10.438z"/>' +
        '<circle fill="#FFFFFF" cx="15" cy="10.677" r="3.291"/></svg>';
      // let Svg = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><defs><style>.cls-1{fill:#fff;}.cls-2{fill:#08a1e9;fill-rule:evenodd;}</style></defs><circle class="cls-1" cx="24" cy="24" r="24"/><path class="cls-2" d="M24.05,10.77,12.42,32.35a1,1,0,0,0,1.31,1.39l9.85-4.55a1,1,0,0,1,.84,0l10.11,4.67a1,1,0,0,0,1.33-1.33l-10-21.71A1,1,0,0,0,24.05,10.77Z"/></g></g></svg>';
      let img = new Image();
      img.src = 'data:image/svg+xml,' + escape(Svg);

      const positionFeature = new Feature();
      positionFeature.setStyle(new Style({
        image: new olIcon({
          img: img,
          imgSize: [26, 26],
        })
      }));

      geolocation.on('change:position', function () {
        let coordinates = geolocation.getPosition();
        positionFeature.setGeometry(coordinates ?
          new Point(coordinates) : null);
      });


      const PositionLayer = new VectorLayer({
        map: map,
        source: new Vector({
          features: [positionFeature]
        })
      });

      map.addLayer(PositionLayer);
    
    } */

    /* if (this.selectCoordinateObj && !_.isEmpty(buildListGeojson)) {
      let self = this;
      const { map, VectorLayer, Vector, Geojson, Circle, Stroke, Style, Fill, addOverlays, Select } = this.selectCoordinateObj;
      if (!_.isEmpty(buildListGeojson.features)) {
  
        self.renderBuildList();
      }
    } */

    

    return (
      <div>
        {<SearchBar searchPlaceholder="查找楼宇"/>}
        {<FloorList visiable={this.state.isShowFloorList} distance={this.state.distance} transferShowFloorList={() => this.transferShowFloorList()}/>}
        {<SelectMapLanlat view={ this.defaultView }
          defaultControls={{ attribution: false }}
          extendControls={[ scaleLineControl ]}
          layers={[this.buildLayer, this.layerTile ]}
          callback2Location={() => this.fly2Location() }
          ref={el => this.selectCoordinateObj = el }
          target="outdoor" /> } 
      </div>
    );
  }
}

export default connect(({ outdoor }) => ({ outdoor }))(Outdoor);
