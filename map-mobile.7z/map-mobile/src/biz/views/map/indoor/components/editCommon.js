import { app } from 'components/common/dragIcon';
import { tools } from 'common/utils';
import _ from 'underscore';



class editCommon {
	singClickAddPointEvent = null;
	pointerSource = null;
	pointerFeatures = [];
	geoJson = null;
	doubleClickPointerIconEvent = null;
	featureIndex = null;
	index = 0;

	constructor(mapObj) {
		this.mapObj = mapObj;
	}

	initVectorlayer = () => {


	}

	/*单击获取事件
	 *@callback fun 
	*/
	getSingclickEvent = (callback) => {
		const { map } = this.mapObj;
		//判断点击添加
		if (this.singClickPointEvent) {
			map.un('singleclick', this.singClickPointEvent);
		}

		this.singClickPointEvent = (evt) => {
			callback && callback(evt);
		}

		map.on('singleclick', this.singClickPointEvent);
	}

    /*
     * 页面监听变化，feature放大缩小功能
     *@scaleNum number 缩放倍数
     *@features array  要缩放的feature数组
    */
	listenViewChange = (scaleNum, features) => {
		const { map } = this.mapObj;
		const self = this;
		// 监听地图层级变化
		map.getView().on('change:resolution', function () {
			let that = this;
			const featureList = features || self.pointerFeatures;

			featureList.forEach((anchor) => {
				var style = anchor.getStyle();
				// console.log(that.getZoom() / scaleNum * 0.5);
				style.getImage().setScale(that.getZoom() / scaleNum * 0.7);
				anchor.setStyle(style);

			})
		})
	}

	/*清除矢量图的数据
	 *@sourceList 矢量图数据资源list
	*/
	removeSourceVector = (sourceList) => {
		sourceList.forEach((item, index) => {
			item.clear()
		});
	}

	/* @style object
	 * @pointer array
	 * @fields object (properties: coordinateName坐标字段名 name坐标点名称)
	*/
	addPointerLayers = (pointers, layer, fields) => {
		const { map, Vector, VectorLayer, Circle, Fill, Stroke,
			Interaction, Point, Feature, Style, olIcon, Proj } = this.mapObj;

		layer.getSource().clear();
		this.pointerFeatures = [];

		pointers.forEach((item, index) => {
			if (item.operationType === 'DELETE') return;
			const coodinate = tools.getType(item) === 'array' && item || fields && item[fields['coordinateName']] || console.log('输入坐标格式错误');
			const name = tools.getType(item) === 'array' && Math.random() || fields && item[fields['name']] || console.log('输入坐标格式错误');

			//this.pointerSource[index] = new Vector();
			this.pointerFeatures[index] = new Feature({
				geometry: new Point(this.transformCoordinate(coodinate)),
				name: name
			})


			if (item.style) {
				this.pointerFeatures[index].setStyle(new Style({
					...item.style
				}));
			}

			layer.getSource().addFeature(this.pointerFeatures[index]);
		});

	}
    /*双击点的icon
     *
    */
	doubleClickPointerIcon = ({ shapeType, style, callback }) => {
		const { map, Style, Stroke, Circle, Fill, olIcon } = this.mapObj;

		this.doubleClickPointerIconEvent = (evt) => {
			this.featureIndex = null;
			const Feature = map.forEachFeatureAtPixel(evt.pixel, (feature) => {
				if (feature.getGeometry().getType() === shapeType) {
					return feature;
				};
				return null;
			})

			if (Feature) {
				const nowCoordinates = Feature.getGeometry().flatCoordinates;
				for (let i = 0; i < this.pointerFeatures.length; i++) {
					const coordinates = this.pointerFeatures[i].getGeometry().flatCoordinates;

					if (_.isEqual(coordinates, nowCoordinates)) {
						this.featureIndex = i;
						this.pointerFeatures[i].setStyle(new Style({
							...style
						}));
					}
				}
			}
			if (this.featureIndex !== null) {
				callback && callback(this.featureIndex, Feature);
			}
		}
		map.on('dblclick', this.doubleClickPointerIconEvent);
	}
	//创建canvas背景图
	createCanvasBackImage = (src, callback) => {
		const canvas = document.createElement('canvas');
		const cxt = canvas.getContext('2d');
		let img = new Image(), colorLike = null;
		img.src = src;

		img.onload = () => {
			//console.log(CanvasRenderingContext2D)
			let pattern = cxt.createPattern(img, 'repeat');
			//cxt.CanvasRenderingContext2D.fillStyle = pattern;
			//colorLike = CanvasRenderingContext2D.fillStyle;
			callback && callback(pattern);
		}
	}

	//贴图功能
	pasteImageToFeature = (geometry, style, layer) => {
		const { Feature, Polygon, Style, Vector, VectorLayer, map } = this.mapObj;

		if (geometry.geometry.type !== 'Polygon') return;

		const backImageFeature = new Feature({
			geometry: new Polygon(this.transformCoordinateList(geometry.geometry.coordinates))
		});
		//console.log(this.transformCoordinateList(geometry.geometry.coordinates))
		layer.getSource().addFeature(backImageFeature);

		backImageFeature.setStyle(new Style({
			...style
		}))
		return {
			layer: layer
		}
	}
	//添加贴图功能属性
	addBackImageToFeature = (props) => {
		const { shapeType, geojson, pasteType, callback, Feature } = props;
		const { map, Proj } = this.mapObj;
		const features = geojson.features;
		// this.ClickBackImageToFeatureEvent = (evt) => {
		//     const Feature = map.forEachFeatureAtPixel(evt.pixel, (feature) => {
		//         if(feature.getGeometry().getType() === shapeType) {
		//             //console.log(feature)
		//             return feature;
		//         };
		//         return null;
		//     });
		//if(Feature) {
		const currentCoordintes = Feature.getGeometry().flatCoordinates;

		const newFeatures = features.map((item, index) => {
			let coordinates = null;
			if (item.geometry.type === 'Polygon') {
				coordinates = item.geometry && this.delayerArray(this.transformCoordinateList(item.geometry.coordinates));
			}

			if (_.isEqual(currentCoordintes, coordinates)) {
				item.properties.pasteType = pasteType;
			};
			return item;
		});
		geojson.features = newFeatures;
		callback && callback(geojson);
		//}
		//};
		// map.on('singleclick', this.ClickBackImageToFeatureEvent)

	}

	geojsonTofile = (data) => {
		//生成类型数组视图
		const byteString = encodeURIComponent(JSON.stringify(data));
		const UnitArray = new Uint8Array(byteString.length);
		for (let i = 0; i < byteString.length; i++) {
			UnitArray[i] = byteString.charCodeAt(i);
		};
		//组装blob,类file
		const blob = new Blob([UnitArray], { type: 'application/json' });
		console.log(blob)
		return blob;
	}

	//边框移上去的hover效果
	hoverFeature = (strokeStyle, shapeType) => {
		const { map, Vector, VectorLayer } = this.mapObj;

		map.on('pointermove', (evt) => {
			const Feature = map.forEachFeatureAtPixel(evt.pixel, (feature) => {
				if (feature.getGeometry().getType() === shapeType || !shapeType) {
					return feature;
				};
				return null;
			});

		})
	}

	//将坐标拍成扁平化数据
	delayerArray = (coordinates) => {
		const coordinateString = JSON.stringify(coordinates);
		const replaceCoordinateString = coordinateString.replace(/[\[\]]/g, '');
		const replaceCoordinate = replaceCoordinateString.split(',').map(item => (
			parseFloat(item)
		))
		return replaceCoordinate;
	}
	//清除单击事件
	removeSingclickEvent = () => {
		const { map } = this.mapObj;
		this.singClickPointEvent && map.un('singleclick', this.singClickPointEvent);
	}
	//删除双击事件
	removeDoubleClickEvent = () => {
		const { map } = this.mapObj;
		this.doubleClickPointerIconEvent && map.on('dblclick', this.doubleClickPointerIconEvent);
	}
	//点击放大缩小 ture 放大  false 缩小
	clickScaling = (bool, step, animation) => {
		const { map } = this.mapObj;
		const view = map.getView();
		const currentZoom = view.getZoom();
		const cStep = step || 1;
		const zoom = bool ? currentZoom + cStep : currentZoom - cStep;
		animation && view.animate({
			zoom: zoom,
			...animation
		}) || view.setZoom(zoom);
		return zoom;
	}
	//
	setScaling = (scale, zoom) => {
		const { map } = this.mapObj;
		const view = map.getView();
		view.setZoom(scale * zoom);
	}

	//点击旋转  true 顺时针  false 逆时针
	clickRotate = (bool, step, animation) => {
		const { map } = this.mapObj;
		const view = map.getView();
		const currentRotate = view.getRotation();
		const cStep = step || Math.PI / 12;
		const rotation = bool ? currentRotate + cStep : currentRotate - cStep;
		// view.setRotation(rotation)
		animation && view.animate({
			rotation: rotation,
			...animation
		}) || view.setRotation(rotation);
		return rotation;
	}
	//转化坐标数组
	transformCoordinateList = (coordinateList) => {
		let listWrapper = [];

		for (let i = 0; i < coordinateList.length; i++) {
			const list = coordinateList[i].map(item => {
				return this.transformCoordinate(item);
			});
			listWrapper.push(list);
		}
		return listWrapper;
	}


	//转换坐标
	transformCoordinate = (coordinates) => {
		const { Proj } = this.mapObj;
		let nCoordinate = null;
		if (this.getProjection() === 'EPSG:3857') {
			nCoordinate = Proj.transform(coordinates, 'EPSG:4326', 'EPSG:3857');
		} else {
			nCoordinate = coordinates;
		}

		return nCoordinate;
	}
	//获取现在的坐标系
	getProjection = () => {
		const { map } = this.mapObj;
		const view = map.getView();
		return view.getProjection().code_;
	}
	//清除掉图层列表
	removeLayersList = (layerList) => {
		const { map } = this.mapObj;

		for (let i = 0; i < layerList.length; i++) {
			map.removeLayer(layerList[i]);
		}

	}
}

export default editCommon;