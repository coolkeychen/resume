import React, { PropTypes } from 'react';
import { connect } from 'react-redux';

import { queryURL,sendMessage } from 'common/utils/tools';
import { Modal } from 'antd-mobile';
import Base64Icon from 'common/global/base64Icon';
import _ from 'underscore';

import EditCommon from './components/editCommon';
import { app } from 'components/common/dragIcon';

import 'antd-mobile/dist/antd-mobile.css';
import proj from 'ol/proj';
import View from 'ol/view';
import VectorLayer from 'ol/layer/vector';
import Vector from 'ol/source/vector';
import ScaleLine from 'ol/control/scaleline';


import SelectMapLanlat from 'components/biz/selectMapLanlat';
import SearchBar from '../search/search';

import 'static/css/main.less';
import './indoor.less'

class Indoor extends React.Component {
    selectCoordinateObj = null;
    module = 'indoor';
    styleCache = {};
    backImageSource = [];
    backImageFeatures = [];
    view = {};
    index = 0;
    featureJSon = {};
    
    static propTypes = {
        location: PropTypes.object.isRequired,
        dispatch: PropTypes.func.isRequired,
    }


    constructor() {
        super();
        this.state = {
            modal: false,
        }
    }

    componentWillMount = () => {
        this.louyuX = queryURL('louyuX');
        this.louyuY = queryURL('louyuY');
        this.floorid = queryURL('floorid');
        // this.floorid = 'c02805cc58f211e892c5005056907f82';

        this.backImageLayer = new VectorLayer({
            source: new Vector({})
        })

        this.vectorlayer = new VectorLayer({
            source: new Vector({}),
            style: function (feature) {

            }
        })
        
        this.props.dispatch({
            type: `${this.module}/getBuildingDetail`,
            payload: {
                id: this.floorid
            }
        });
    }

    componentDidMount =() => {
        const { geojson, detail } = this.props.indoor;
    }


    // 楼层基础数据地图贴图
    pasteImageToFeature = (geojsonFeatures) => {
        const { createCanvasBackImage, pasteImageToFeature, removeSourceVector, initVectorlayer } = this.editFloorCommon;
        const { olIcon, Fill } = this.selectCoordinateObj;
        // const { pointers } = this.props.addBuildingInfo;
        this.backImageLayer.getSource().clear()

        geojsonFeatures.forEach(item => {
            const pasteType = item.properties.pasteType;
            if (!pasteType) { return };
            //const fillStyle = null;
            createCanvasBackImage(Base64Icon[pasteType], (fillStyle) => {
                const style = {
                    fill: new Fill({
                        color: fillStyle
                    })
                }
                const { source, features } = pasteImageToFeature(item, style, this.backImageLayer);
            });
        });
    }

    addPointerLayers = (pointers) => {
        const { Circle, Fill, Stroke, map, olIcon } = this.selectCoordinateObj;
        const { addPointerLayers } = this.editFloorCommon;
        map.removeInteraction(new app('Point', this.dragPointerIcon));
        const pointerStyle = pointers.map(item => {
            return {
                ...item,
                style: {
                    image: new olIcon({
                        src: item.url,
                        scale: 0.7
                    })
                }
            }
        })

        addPointerLayers(pointerStyle, this.pointerVectorLayer, { coordinateName: 'coordinate', name: "name" });
        map.addInteraction(new app('Point', this.dragPointerIcon));
    }

    // 楼层组件 styleFunction
    componentStyle = (feature, resolution) => {
        let self = this;
        const { Style, olIcon } = this.selectCoordinateObj;
        const url = feature.get('url');
        if (!self.styleCache[url]) {
            self.styleCache[url] = new Style({
                image: new olIcon({
                    scale: 0.5,
                    src: url
                })
            });
        }
        return [self.styleCache[url]];
    }

    // 楼层组件渲染
    paintComponent = (componentList) => {
        let self = this;
        const { olIcon,Style, Fill, map, VectorLayer, Vector, Geojson} = this.selectCoordinateObj;

        const componentSource= new Vector({
            features: (new Geojson()).readFeatures(componentList, {
                dataProjection: 'EPSG:4326',
                featureProjection: 'EPSG:3857'
            })
        });

        /* componentSource.forEachFeature(function (feature) {
            const component = feature.get('component');
            let url = component.iconPath;
            console.log(component.iconPath);
            feature.set('url', component.iconPath);
            const style = new Style({
                image: new olIcon({
                    scale: 0.7,
                    src: url
                })
            })
            feature.setStyle(style);
        }); */
        componentSource.forEachFeature(function (feature) {
            const component = feature.get('component');
            feature.set('url', component.iconPath);
        })

   
        const featureVector = new VectorLayer({
            source: componentSource,
            style: self.componentStyle
        });
        map.addLayer(featureVector);
    }


    // 初始化矢量图层
    createVectorLayer = (geojson) => {
        let self = this;
        const { VectorLayer,Vector, Geojson }  = this.selectCoordinateObj;

        return new VectorLayer({
            source: new Vector({
                features: (new Geojson()).readFeatures(geojson , {
                    dataProjection: 'EPSG:4326',
                    featureProjection: 'EPSG:3857'
                })
            }),
            style: self.styleFunction
        });
    }

    render() {

        const { geojson, detail, componentList } = this.props.indoor;

        this.view = new View({
            center: proj.transform([118.05867969989775, 24.595694880701107], 'EPSG:4326', 'EPSG:3857'),
            zoom: 19.9,
            maxZoom: 23,
            minZoom: 3
        });

        const scaleLineControl = new ScaleLine({
            minWidth: '50'
        });

        
        this.editFloorCommon = new EditCommon(this.selectCoordinateObj);

        if (this.selectCoordinateObj && !_.isEmpty(geojson)) {
            const { map, Vector, VectorLayer, Geojson, Circle, Fill, Stroke,
                Interaction, Point, Feature, Style, PluggableMap, olIcon, Text } = this.selectCoordinateObj;
            let highlightStyle = new Style({
                stroke: new Stroke({
                    color: 'red',
                }),
                fill: new Fill({
                    color: 'transparent'
                }),
                text: new Text({
                    font: '12px Calibri,sans-serif',
                    stroke: new Stroke({
                        color: '#313131',
                        width: 1
                    })
                })
            })

            this.vectorlayer.setSource(new Vector({
                features: (new Geojson()).readFeatures(geojson, {
                    dataProjection: 'EPSG:4326',
                    featureProjection: 'EPSG:3857'
                })
            }))

            this.vectorlayer.setStyle(function (feature) {
                if (feature.get('Layer')) {
                    highlightStyle.getText().setText(feature.get('Layer'));
                }
                if (feature.get('name') === 'door') {
                    highlightStyle.getStroke().setColor('transparent');
                } else if (feature.get('name') === 'wall') {
                    highlightStyle.getStroke().setColor('#313131');
                } else if (feature.get('name') === 'table') {
                    highlightStyle.getStroke().setColor('#aa8e61');
                } else if (feature.get('pasteType')) {
                    highlightStyle.getStroke().setColor('transparent');
                }
                return highlightStyle;
            })
        }

        if (this.selectCoordinateObj && !_.isEmpty(geojson) && !this.index++) {

            //var pointFeature = new Feature(new Point([118.05881258587897, 24.595455700331335]));
            //this.editFloorCommon = new EditCommon(this.selectCoordinateObj);
            this.geojsonFeatures = geojson.features;
            //this.addOverlays([[118.05881258587897, 24.595455700331335]]);
            this.pasteImageToFeature(this.geojsonFeatures);
            
            //组件渲染
            if (!_.isEmpty(componentList)) {
                this.paintComponent(componentList);
            }
        };


        return (
            <div>
                {<SearchBar searchPlaceholder="查找楼层、设施类型" />}
                {<SelectMapLanlat view={ this.view }
                    layers={[this.backImageLayer, this.vectorlayer]}
                    defaultControls={{ attribution: false }}
                    extendControls={[ scaleLineControl ]}
                    ref={el => this.selectCoordinateObj = el}
                    target={"indoor"} />}
            </div>
        )
    }

}

export default connect(({ indoor }) => ({ indoor }))(Indoor);