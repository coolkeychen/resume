import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { Link } from 'react-router'

import { Form, Input, Button } from 'antd';

import './index.less';

const FormItem = Form.Item;

class Logon extends React.Component {
	

	constructor() {
		super()
	}

	render() {
		console.log(this.props.routes)
		const { logon, form } = this.props;
		const { loginLoading } = logon;
		const { getFieldDecorator } = form;
		const formItemLayout = {
		      labelCol: {
		        xs: { span: 24 },
		        sm: { span: 0 },
		      },
		      wrapperCol: {
		        xs: { span: 24 },
		        sm: { span: 24 },
		      },
        };
		return (
		    <div className="map-logon-wrapper">
		    	<div className="map-logon-inner">
		    		<p className="map-logon-logo">
		    		</p>
		    		<div className="map-logon-box clearfix">
						<div className="logon-box-left"></div>
						<div className="logon-box-right">
							<h3 className="logon-title">欢迎使用<p></p>地图后台管理系统</h3>
						    <p className="logon-title-english">Welcome to use<p></p>
						    SIHENG intelligent agricultural management platform</p>
						    <Form>
						    	<FormItem {...formItemLayout}>
						    		{getFieldDecorator('phone', { validateTrigger: ['onSubmit', 'onBlur'], rules:[{

						    			pattern: new RegExp("^1[345678]\\d{9}$"), message: "输入手机号码格式错误"
						    	     },
						    	     {
						    	     	required: true, message: "请输入手机号码"
						    	     }
						    	    ]})(
						    			<Input size="large" placeholder="请输入手机号码"/>
						    		)}
						    	</FormItem>
						    	<FormItem {...formItemLayout}>
									{getFieldDecorator('password', {})(
						    			<Input size="large" placeholder="请输入密码" type="password"/>
						    		)}
						    	</FormItem>
						    </Form>
						    <p className="logon-reset-passwork"><Link to={'/reset'}>忘记密码？</Link></p>
						    <div className="logon-botton-wrapper">
							    <Button type="primary" size="large" onClick={this.handleOk} loading={loginLoading}>
	                                  登录
	                            </Button>
						    </div>
						</div>
		    		</div>
		    	</div>
		    	<div className="logon-copyright">Copyright 2018 SIHENG Technology. All rights reserved.</div>
		    </div>
		)
	}
}

export default connect(({ logon }) => ({ logon }))(Form.create()(Logon));