import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { Link } from 'react-router'

import { Form, Input, Button, Icon, Steps } from 'antd';

import './index.less';

const FormItem = Form.Item;
const Step = Steps.Step;

class Reset extends React.Component {
	
	
	constructor() {
		super();
		this.state = {
			current: 0
		}
	}

	handleOk = (index) => {
		this.setState({
			current: index
		})
	}

	render() {
		const { reset, form } = this.props;
		//const { loginLoading } = logon;
		const { getFieldDecorator } = form;
		const { current } = this.state;

		const formItemLayout = {
		      labelCol: {
		        xs: { span: 24 },
		        sm: { span: 0 },
		      },
		      wrapperCol: {
		        xs: { span: 24 },
		        sm: { span: 24 },
		      }
        };
        const steps = [{
        		title: "填写账户"
            },{
            	title: "输入手机验证码"
            },{
            	title: "重置密码"
        }]
		return (
		    <div className="map-reset-wrapper">
		    	<div className="map-reset-inner">
		    		<p className="map-reset-logo"></p>
		    		<div className="map-reset-box">
		    		    <div className="map-reset-arrow">
		    		       <Link to={'/logon'}><Icon type="arrow-left" style={{color: '#e1e1e1', 'fontSize': '24px'}}/></Link>
		    		      </div>
						<div className="map-reset-step">
							<Steps current={current}>
								{ steps.map(item => <Step title={item.title}/>) }
							</Steps>
						</div>
						{ !current && <div>
						    <Form>
						    	<FormItem {...formItemLayout}>
						    		{getFieldDecorator('phone', { validateTrigger: ['onSubmit', 'onBlur'], rules:[{

						    			pattern: new RegExp("^1[345678]\\d{9}$"), message: "输入手机号码格式错误"
						    	     },
						    	     {
						    	     	required: true, message: "请输入手机号码"
						    	     }
						    	    ]})(
						    			<Input size="large" placeholder="请输入手机号码"/>
						    		)}
						    	</FormItem>
						    </Form>
						    <p className="reset-text-warn">注: 账户名为用户的11位手机号码</p>
						    <div className="logon-reset-wrapper">
							    <Button type="primary" size="large" onClick={() => {this.handleOk(1)}} >
		                              下一步
		                        </Button>
						    </div>
					    </div>}
						{ current === 1 && <div>
						    <Form>
						    	<FormItem {...formItemLayout}>
						    		{getFieldDecorator('vi', { validateTrigger: ['onSubmit', 'onBlur'], rules:[{

						    			pattern: new RegExp("[0-9]{6}"), message: "输入手机号码格式错误"
						    	     },
						    	     {
						    	     	max: 6, message: "最多只能输入六个有效数字"
						    	     },
						    	     {
						    	     	required: true, message: '请输入验证码'
						    	     }
						    	    ]})(
						    			<Input size="large" placeholder="请输入6位验证码"/>
						    		)}
						    	</FormItem>
						    </Form>
						    <p className="reset-text-warn">注: 验证码为六位数字</p>
						    <div className="logon-reset-wrapper">
							    <Button type="primary" size="large" onClick={() => {this.handleOk(2)}} >
		                              下一步
		                        </Button>
						    </div>
					    </div> }
					    { current === 2 && <div>
						    <Form>
						    	<FormItem {...formItemLayout}>
						    		{getFieldDecorator('password', { validateTrigger: ['onSubmit', 'onBlur'], rules:[
						    	     {
						    	     	required: true, message: "请输入密码"
						    	     }
						    	    ]})(
						    			<Input size="large" placeholder="请输入密码"/>
						    		)}
						    	</FormItem>
						    	<FormItem {...formItemLayout}>
						    		{getFieldDecorator('password', { validateTrigger: ['onSubmit', 'onBlur'], rules:[
						    	     {
						    	     	required: true, message: "请输入再次输入密码"
						    	     }
						    	    ]})(
						    			<Input size="large" placeholder="请输入再次输入密码"/>
						    		)}
						    	</FormItem>
						    </Form>
						    <p className="reset-text-warn">注: 前后的密码要一致</p>
						    <div className="logon-reset-wrapper">
							    <Button type="primary" size="large" onClick={() => {this.handleOk(1)}} >
		                              上一步
		                        </Button>
						    </div>
					    </div> }
				    </div>
		    	</div>
		    	<div className="reset-copyright">Copyright 2018 SIHENG Technology. All rights reserved.</div>
		    </div>
		)
	}
}

export default connect(({ reset }) => ({ reset }))(Form.create()(Reset));