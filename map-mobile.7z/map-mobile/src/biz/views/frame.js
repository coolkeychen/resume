import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { Layout, Spin, Modal } from 'antd';

import CustomHeader from 'components/common/header';
import SiderMenu from 'components/common/siderMenu';
import Breadcrumb from 'components/common/crumbs';

import 'static/css/main.less';

const { Content, Header, Sider } = Layout;

class Frame extends React.Component {
  globalPath = null;
  static propTypes = {
    location: PropTypes.object.isRequired,
    dispatch: PropTypes.func.isRequired,
    frame: PropTypes.object.isRequired,
  }

  render = () => {
    let { children, dispatch, frame, loading } = this.props;

    const siderProps = {
      frame,
      handleSelect(payload) {
        dispatch({
          type: 'frame/switchModule',
          payload
        });
      }
    };
    const headerProps = {
      frame
    };
    const { userId } = frame;
    return (
      <Layout style={{height: '100%'}}>
        <Spin spinning={ loading.global }>
        </Spin>
        <Sider width={200} trigger={null} className="axg-sider">
            <SiderMenu {...siderProps} />
        </Sider>
        <Layout className="axg-content">
          <Header>
             <CustomHeader {...headerProps} />
          </Header>
          <Content id="content-body" style={{ overflow: 'initial', background: 'white'}}>
            { frame.crumbsData && <Breadcrumb crumbList={frame.crumbsData}/> || console.error('请检查配置面包屑')}
            <div style={{padding: '20px'}}>
            { children }
            </div>
          </Content>
        </Layout>
        }
      </Layout>
    );
  }
}

export default connect(({ frame, loading }) => ({ frame, loading }))(Frame);
