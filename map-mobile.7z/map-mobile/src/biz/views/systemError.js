import { connect } from 'dva';
import React, { PropTypes } from 'react';
import { Link } from 'react-router';
import { Button } from 'antd';

function Page({}) {

  return (
    <div id="content" className="warn-wrapper-content">
      <div className="warn-wrapper">
        <div className="warn-image system-error" />
        <div className="warn-label">哎呀，系统出错啦，请稍后重试~</div>
        <Link className="ant-btn-primary ant-btn axg-link-like-button" to={`/index`}>重试</Link>
      </div>
    </div>
  );
}

Page.propTypes = {
};

export default connect(({}) => ({}))(Page);
