import { request } from 'common/utils/request.js';

export async function getBuiildingList(params) {
	return request('/wifiBuildingFloor/pageByExample', { method: 'GET', data: params})
}

export async function postBuiilding(params) {
	return request('/wifiBuildingFloor/createOrUpdate', { method: 'POST', data: params})
}

export async function getBuiildingDetail(params) {
	return request(`/wifiBuildingFloor/${params.id}`, { method: 'GET'})
}


export async function deleteBuilding(params) {
	return request(`/wifiBuildingFloor/${params.id}`, { method: 'DELETE'})
}

export async function postFile(params) {
	return request('/aliyunOss/upload', { method: 'POST'})
}

export async function getGeojson(url) {
	console.log(url)
	return request(url, { method: 'GET'})
}

