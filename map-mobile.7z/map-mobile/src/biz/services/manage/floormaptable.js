import { request } from 'common/utils/request.js';

export async function getLouyuList(params) {
	return request('/wifiBuilding/pageByExample', { method: 'GET', data: params})
}

export async function postLouyu(params) {
	return request('/wifiBuilding/createOrUpdate', { method: 'POST', data: params})
}

export async function getLouyuDetail(params) {
	return request(`/wifiBuilding/${params.id}`, { method: 'GET'})
}


export async function deleteLouyu(params) {
	return request(`/wifiBuilding/${params.id}`, { method: 'DELETE'})
}