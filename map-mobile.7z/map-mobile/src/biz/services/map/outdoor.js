import { requestLocal, request } from 'common/utils/request.js'


// 获取区域内楼宇数据列表
export async function getBuildList(params) {
  return request('/map/wifiBuilding', { method: 'GET', data: params })
}


// 获取楼宇信息
export async function getWifiBuilding(params) {
  return request(`/wifiBuilding/${params.id}`, { method: 'GET', data: params})
}