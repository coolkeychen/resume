import { requestLocal, request } from 'common/utils/request.js';

export async function getBuiildingDetail(params) {
	return request(`/map/wifiBuildingFloor/${params.id}`, { method: 'GET'})
}

export async function getGeojson(url) {
	return request(url, { method: 'GET'})
}

export async function getPluginList(data) {
	return request("/component/listByExample", { method: 'GET', data: data })
}

