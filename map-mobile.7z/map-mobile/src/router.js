import React from 'react';
import {
  Router,
  Route,
  IndexRedirect,
  Redirect
} from 'dva/router';

import frame from "./biz/views/frame";

import UnauthorizedPage from './biz/views/unauthorized';
import NotFoundPage from './biz/views/notFound';
import SystemWrongErrorPage from './biz/views/systemError';

//登录注册
import Logon from "./biz/views/logon/index";
import Reset from "./biz/views/reset/index";

//楼层数据管理
import FloorMapTable from "./biz/views/manage/floormaptable/list";
import addMapTable from "./biz/views/manage/floormaptable/add";
//楼层数据管理
import BuildingInfo from "./biz/views/manage/buildingInfo/list";
import AddBuildingInfo from "./biz/views/manage/buildingInfo/add";
import EditFloorMap from "./biz/views/manage/buildingInfo/editfloormap";

//AP数据管理
/* import ApManage from "./biz/views/manage/apmanage/list";
import addApManage from "./biz/views/manage/apmanage/add"; */

// 室外地图
import outdoor from "./biz/views/map/outdoor/outdoor";
// 室内地图
import indoor from "./biz/views/map/indoor/indoor";


export default function ({ history }) { // eslint-disable-line
  return (<Router history={history}>
    <Route path="/">
      <Route path="systemError" component={SystemWrongErrorPage}/>
      <Route path="unauth" component={UnauthorizedPage}/>
      <Route path="notfound" component={NotFoundPage} />
      <Route path="logon" component={Logon}/>
      <Route path="reset" component={Reset}/>
      <IndexRedirect to="map" />
      <Route path="map">
        <IndexRedirect to="outdoor" />
        <Route path="outdoor" component={outdoor} />
        <Route path="indoor" component={indoor} />
      </Route>
      <Redirect from='*' to='/notfound'/>
    </Route>
  </Router>);
}
