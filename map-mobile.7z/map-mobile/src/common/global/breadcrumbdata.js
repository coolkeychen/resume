export default {
	//地图楼层数据管理
	'/manage/mapdata/floormaptable': [
	   	{"name": "地图数据管理", 'key': 'mapmanage'},
	    {"name": "楼宇数据管理列表", 'key': 'floormaptable'}
	],
	'/manage/mapdata/floormaptable/add': [
	   	{"name": "地图数据管理", 'key': 'mapmanage'},
	   	{"name": "楼宇数据管理列表", 'key': 'floormaptable' ,'path': '/manage/mapdata/floormaptable'},
	    {"name": "楼宇数据新增", 'key': 'add'}
	],
    '/manage/mapdata/floormaptable/edit': [
       	{"name": "地图数据管理", 'key': 'mapmanage'},
	   	{"name": "楼宇数据管理列表", 'key': 'floormaptable' ,'path': '/manage/mapdata/floormaptable'},
	    {"name": "楼宇数据修改", 'key': 'edit'}
	],
	//楼层数据管理
	'/manage/mapdata/buildinginfo': [
       	{"name": "地图数据管理", 'key': 'mapmanage'},
	   	{"name": "楼宇数据管理列表", 'key': 'floormaptable' ,'path': '/manage/mapdata/floormaptable'},
	    {"name": "楼层信息", 'key': 'buildinfo'},
	],
	'/manage/mapdata/buildinginfo/add': [
       	{"name": "地图数据管理", 'key': 'mapmanage'},
	   	{"name": "楼宇数据管理列表", 'key': 'floormaptable' ,'path': '/manage/mapdata/floormaptable'},
	    {"name": "楼层信息", 'key': 'buildinfo'},
	    {"name": "楼层信息添加", 'key': 'add'}
	],
	'/manage/mapdata/buildinginfo/edit': [
       	{"name": "地图数据管理", 'key': 'mapmanage'},
	   	{"name": "楼宇数据管理列表", 'key': 'floormaptable' ,'path': '/manage/mapdata/floormaptable'},
	    {"name": "楼层信息", 'key': 'buildinfo'},
	    {"name": "楼层信息修改", 'key': 'edit'}
	],
	//AP数据管理
	'/manage/mapdata/apmanage': [
	   {"name": "地图数据管理", 'key': 'apmanage'},
	   {"name": "楼宇数据管理列表", 'key': 'floormaptable' ,'path': '/manage/mapdata/floormaptable'},
	   {"name": "楼层数据管理列表", 'key': 'building'},
	   {"name": "AP数据列表", 'key': 'apmanage'}
	],
	'/manage/mapdata/apmanage/add': [
		{"name": "地图数据管理", 'key': 'apmanage'},
	   	{"name": "楼宇数据管理列表", 'key': 'floormaptable' ,'path': '/manage/mapdata/floormaptable'},
	   	{"name": "楼层数据管理列表", 'key': 'building'},
        {"name": "AP数据列表", 'key': 'apmanage'},
	    {"name": "AP数据新增", 'key': 'add'}
	],
    '/manage/mapdata/apmanage/edit': [
       	{"name": "地图数据管理", 'key': 'apmanage'},
        {"name": "楼宇数据管理列表", 'key': 'floormaptable' ,'path': '/manage/mapdata/floormaptable'},
        {"name": "楼层数据管理列表", 'key': 'building'},
        {"name": "AP数据列表", 'key': 'apmanage'},
	    {"name": "AP数据修改", 'key': 'edit'}
	],
}