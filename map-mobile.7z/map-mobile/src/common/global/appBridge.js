/**
 * 状态：1为网络正常，0为网络断开
 */ 

window.checkNetworkState = (networkState) => {
    window.networkStatus = networkState;
}