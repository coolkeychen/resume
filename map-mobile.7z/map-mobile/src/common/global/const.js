export const TIME_FORMAT_FE = 'YYYY-MM-DD';
export const TIME_FORMAT_BD = 'YYYY-MM-DD HH:mm:ss';

export const FormInputStyle = {
  largeWidth: 200,
  smallWidth: 128,
};

export const TimeRangeDay = 30;
export const TimeRangeMonth = 1;
export const PAGE_SIZE = 20;
export const PAGE_OPTIONS = ['10', '20', '30','40','50'];

var uploadDomain;
var viewDomain;
var hostname = window.location.hostname;

// 测试环境
if (hostname.indexOf('anhouse.com.cn') !== -1) {
  viewDomain = 'img.gov1.anhouse.com.cn';
  uploadDomain = 'upload.gov1.anhouse.com.cn';
}
else {
  viewDomain = 'smartcity-img.pinganfang.com';
  uploadDomain = 'smartcity-upload.pinganfang.com'
}

var viewUrl =  `https://${viewDomain}/view/house`;
var uploadUrl = `https://${uploadDomain}/upload/house.html`;

// 切忌设置成更正常url一样
var secretUploadUrl = `https://${uploadDomain}/upload/secret.html`;
var secretViewUrl = `https://${viewDomain}/view/screte`;

if (process.env.NODE_ENV === 'production') {
}

export const UPLOAD_URL = uploadUrl;
export const VIEW_URL = viewUrl;
export const SECRET_UPLOAD_URL = secretUploadUrl;
export const SECRET_VIEW_URL = secretViewUrl;

export const IMAGE_THUMB_SIZE = '96x72';
export const IMAGE_COMMON_SIZE = '900x675';

export const MAX_IMAGE_NUMBER = 10;
