/**
 * 安心管
 * Copyright 2016 Baidu Inc. All rights reserved.
 *
 * @file 通用枚举数据
 */

import Enum from 'common/Enum';
import moment from 'moment';


/**
 * 付款周期
 * 1：月付、2：2月付、3：季付、4：4月付、5：5月付、6：半年付、7：7月付、8：8月付、9：9月付、10：10月付、11：11月付、12：年付
 * @enum
 */
export const PaymentCycle = new Enum(
    { alias: 'ONE', text: '月付', value: 1 },
    { alias: 'THREE', text: '季付', value: 3 },
);

/**
 * 业主or租客

 * @enum
 */
export const ROLE = new Enum(
    { alias: 'RENT', text: '租客', value: 'rent' },
    { alias: 'PROPERTY', text: '业主', value: 'property' },
);

export const ContractType = new Enum(
  { alias: 'rent', text: '租客', value: 2 },
  { alias: 'property', text: '业主', value: 1 },
);

/**
 * 费用类型

 * @enum
 */
export const EXPENSES = new Enum(
    { alias: 'RENT', text: '租金', value: 1 },
    { alias: 'SECURITY', text: '押金', value: 2 },
    { alias: 'EXTRAS', text: '杂费', value: 3 },
    { alias: 'WATER', text: '水费', value: 4 },
    { alias: 'POWER', text: '电费', value: 5 },
    { alias: 'GAS', text: '燃气费', value: 6 },
    { alias: 'MANAGERMENT', text: '物业费', value: 7 },
    { alias: 'SERVICE', text: '服务费', value: 8 },
    { alias: 'CLEAN', text: '清洁费', value: 9 },
    { alias: 'MAINTENANCE', text: '维修费', value: 10 },
    { alias: 'MATERIAL', text: '材料费', value: 11 },
    { alias: 'TV', text: '电视费', value: 12 },
    { alias: 'NET', text: '宽带', value: 13 },
    { alias: 'PUBLICSANITATION', text: '卫生', value: 14 },
    { alias: 'DISCOUNT', text: '优惠', value: 15 },
    { alias: 'OTHER', text: '其他', value: 16 },

);

// 合同状态
// 发起签约：0，房东确认：1，租客已确认：2，租赁中：4，备案完成：5，到期结束：6，无效状态：7
export const ContractStatus = new Enum(
  { alias: '0', text: '待房东确认', value: 0},
  { alias: '1', text: '待租客确认', value: 1},
  { alias: '2', text: '已完成签约', value: 2},
  { alias: '4', text: '租赁中', value: 4},
  { alias: '5', text: '备案完成', value: 5},
  { alias: '6', text: '到期结束', value: 6},
  { alias: '7', text: '无效状态', value: 7},
  { alias: '8', text: '退租中', value: 8},
);

// 退租明细状态（1-发起退租，2-房东确认，3-房东驳回，4-租客确认，5-租客驳回，6-发起理赔，7-退租完成，8-退租中） ,
export const EvictStatus = new Enum(
  { alias: '1', text: '租客申请退租', value: 1},
  { alias: '2', text: '待租客确认退租明细', value: 2},
  { alias: '3', text: '退租失败', value: 3},
  { alias: '4', text: '退租申请成功', value: 4},
  { alias: '5', text: '退租失败', value: 5},
  { alias: '6', text: '房东发起理赔', value: 6},
  { alias: '7', text: '退租完成', value: 7},
  { alias: '8', text: '退租中', value: 8},
);

// 退租明细状态（1-发起退租，2-房东确认，3-房东驳回，4-租客确认，5-租客驳回，6-发起理赔，7-退租完成，8-退租中） ,
export const OwnerEvictStatus = new Enum(
  { alias: '1', text: '房东申请退客', value: 1},
  { alias: '2', text: '待租客确认退客明细', value: 2},
  { alias: '3', text: '退租失败', value: 3},
  { alias: '4', text: '退客申请成功', value: 4},
  { alias: '5', text: '退租失败', value: 5},
  { alias: '6', text: '房东发起理赔', value: 6},
  { alias: '7', text: '退客完成', value: 7},
  { alias: '8', text: '退租中', value: 8},
);

// 账单延期
// 0:正常，1:应收逾期，2：应付逾期 ,
export const DelayState = new Enum(
  { alias: 'NORMAL', text: '正常', value: 0},
  { alias: 'UNRECEIVED', text: '应收逾期', value: 1},
  { alias: 'UNPAID', text: '应付逾期', value: 2}
);

/**
 * 账单状态

 * @enum
 *
 * 0：未激活，1：激活，2：已支付，3：逾期，4：支付中，5：支付失败，6：失效
 */
export const BILLSTATUS = new Enum(
    { alias: 'UNACTIVE', text: '未激活', value: 0 },
    { alias: 'ACTIVE', text: '激活', value: 1 },
    { alias: 'RECEIVED', text: '已支付', value: 2 },
    { alias: 'UNRECEIVED', text: '逾期', value: 3 },
    { alias: 'PAIDING', text: '支付中', value: 4 },
    { alias: 'FAIl', text: '支付失败', value: 5 },
    { alias: 'INVALID', text: '失效', value: 6 },
);

/**
 * 账单状态查询用

 * @enum
 */
export const BILLSTATUSQUERY = new Enum(
    { alias: 'UNRECEIVED', text: '应收', value: 1 },
    { alias: 'PAID', text: '已完成', value: 2 },
);


/**
 * 收租方式
 *
 * @enum
 */
export const PReceivedType = new Enum(
    { alias: 'ADVANCE', text: '按账单开始时间提前交租', value: 1 },
    { alias: 'STATIC', text: '按固定日期交租', value: 2 },
);

export const RentReceivedType = new Enum(
    { alias: 'ADVANCE', text: '按账单开始时间提前收款', value: 1 },
    // { alias: 'STATIC', text: '按固定日期收款', value: 2 },
);

/**
 * 房屋出租状态
 *
 * @enum
 */
export const RentStatus = new Enum(
    { alias: 'EMPTY', text: '空置', value: 0 },
    { alias: 'RENTED', text: '已出租', value: 1 }
);


/**
 * 延期状态状态
 *
 * @enum
 */
export const DelayStatus = new Enum(
    { alias: 'NORMAL', text: '还有', value: 0 },
    { alias: 'DELAY', text: '逾期', value: 1 },
);


/**
 * 催租状态
 *
 * @enum
 */
export const RemindStatus = new Enum(
    { alias: 'YES', text: '能催', value: 1 },
    { alias: 'NO', text: '不能催', value: 0 },
);


/**
 * 延期状态状态
 *
 * @enum
 */
export const ReceiptStatus = new Enum(
    { alias: 'FINISH', text: '已收', value: 1 },
    { alias: 'NOT_FINISH', text: '未收', value: 2 },
);

/**
 * 资源类型
 *
 * @enum
 */
export const ResourceType = new Enum(
    { alias: 'CENTRAL', text: '集中式', value: 1 },
    { alias: 'DECENTRAL', text: '分散式', value: 2 },
);

/**
 * 出租类型
 *
 * @enum
 */
export const RentType = new Enum(
    { alias: 'ZZ', text: '整租', value: 1 },
    { alias: 'HZ', text: '合租', value: 2 },
);

/**
 * 朝向
 *
 * @enum
 */
export const Direction = new Enum(
    { alias: 'SS', text: '双南', value: 1 },
    { alias: 'SN', text: '南北', value: 2 },
    { alias: 'NN', text: '北北', value: 3 },
);

/**
 * 朝向
 *
 * @enum
 */
export const Tags = new Enum(
    { alias: 'DTYX', text: '地铁沿线', value: 1 },
    { alias: 'SSKF', text: '随时看房', value: 2 },
    { alias: 'CSSQ', text: '成熟商圈', value: 3 },
);

export const Collocations = new Enum(
    { alias: 'KFT', text: '咖啡厅', value: 1 },
    { alias: 'JSF', text: '健身房', value: 2 },
    { alias: 'DYG', text: '大浴缸', value: 3 },
);

export const Situations = new Enum(
    { alias: 'JJZX', text: '精装修', value: 1 },
    { alias: 'JZX', text: '简装修', value: 2 },
    { alias: 'MPF', text: '毛培房', value: 3 },
);

export const PaymentMethods = new Enum(
    { alias: 'FSYY', text: '付三押一', value: 1 },
    { alias: 'YCX', text: '一次性支付', value: 2 },
    { alias: 'MYYF', text: '每月一付', value: 3 },
);

export const LandlordRequests = new Enum(
    { alias: 'KFT', text: '禁烟', value: 1 },
    { alias: 'JSF', text: '禁宠物', value: 2 },
    { alias: 'DYG', text: '限男生', value: 3 },
);

export const ReceiveAppoint = new Enum(
    { alias: 'JS', text: '接受', value: 1 },
    { alias: 'BJS', text: '不接受', value: 0 },
);



/*
 * 日期格式
 *
 * @enum
 */
export const DateFormat = new Enum(
  { alias: 'DAY', text: '日', value: 'YYYY.MM.DD' },
  { alias: 'MONTH', text: '月', value: 'YYYY.MM' },
);

 /*
 * 紧急程度
 *
 * @enum
 */
export const TenantPriority = new Enum(
  { alias: 'URGENT', text: '紧急', value: 0 },
  { alias: 'NORMAL', text: '正常', value: 1 },
  { alias: 'DELAY', text: '延后', value: 2 },
);

 /*
 * 性别
 *
 * @enum
 */
export const Gender = new Enum(
  { alias: 'MAN', text: '男', value: 0 },
  { alias: 'WOMAN', text: '女', value: 1 }
);

  /*
 * 来源
 *
 * @enum
 */
 export const TenantSource = new Enum(
  { alias: 'SOURCELD', text: '来电', value: 0 },
  { alias: 'SOURCE58', text: '58同城', value: 1 },
  { alias: 'SOURCEGJ', text: '赶集网', value: 2 },
  { alias: 'SOURCEAJK', text: '安居客', value: 3 },
  { alias: 'SOURCEGWYY', text: '官网预约', value: 4 },
  { alias: 'SOURCEWXGZH', text: '微信公共号', value: 5 },
  { alias: 'SOURCEBDZF', text: '百度租房', value: 6 },
  { alias: 'SOURCEZFBZF', text: '支付宝租房', value: 7 },
  { alias: 'SOURCEHZ', text: '嗨住', value: 8 },
  { alias: 'SOURCEWBZJ', text: '微博中介', value: 9 },
  { alias: 'SOURCEFTX', text: '房天下', value: 10 },
  { alias: 'SOURCEDB', text: '豆瓣', value: 11 },
  { alias: 'SOURCEBXW', text: '百姓网', value: 12 },
  { alias: 'SOURCEXY', text: '闲鱼', value: 13 },
  { alias: 'SOURCEPYJS', text: '转介绍(朋友)', value: 14 },
  { alias: 'SOURCEKHJS', text: '转介绍(客户)', value: 15 },
  { alias: 'SOURCEXGG', text: '小广告', value: 16 },
  { alias: 'SOURCEOTHER', text: '其他', value: 17 }
);

/*
 * 租客跟进
 *
 * @enum
 */
export const FollowStatus = new Enum(
  { alias: 'READY', text: '预约确认', value: 0 },
  { alias: 'WAIT', text: '待处理', value: 1 },
  { alias: 'TAKEN', text: '已带看', value: 3 },
  { alias: 'CANCEL', text: '取消预约', value: 6 },
  { alias: 'TENANT_CANCEL', text: '租客取消预约', value: 7 }
);

 /*
 * 户型
 *
 * @enum
 */
 export const Layout = new Enum(
  { alias: 'HXHZZW', text: '合住主卧', value: 0 },
  { alias: 'HXDJDW', text: '合住单间独卫', value: 1 },
  { alias: 'HXHZDJ', text: '合住单间', value: 2 },
  { alias: 'HXZJ1S', text: '整租1室户', value: 3 },
  { alias: 'HXZZ2S', text: '整租2室户', value: 4 },
  { alias: 'ZZ3S', text: '整租3室户', value: 5 }
);

 /*
 * 账户类别
 *
 * @enum
 */
 export const AccountType = new Enum(
  { alias: 'COMPANY', text: '公司', value: 1 },
  { alias: 'PERSON', text: '个人', value: 2 }
);

 /*
 * 经营模式
 *
 * @enum
 */
 export const BusinessModel = new Enum(
  { alias: 'FEDERAL', text: '分散式', value: 1 },
  { alias: 'CENTRAL', text: '集中式', value: 2 },
  { alias: 'MIXED', text: '混合经营', value: 3 }
);

 /*
 * 审核状态
 *
 * @enum
 */
 export const AuditStatus = new Enum(
  { alias: 'READY', text: '待审核', value: 0 },
  { alias: 'SUCCESS', text: '审核通过', value: 1 },
  { alias: 'FAIL', text: '审核驳回', value: 2 }
);


/*
 * 上下架状态
 *
 * @enum
 */
 export const SellStatus = new Enum(
  { alias: 'OFFLINE', text: '已下架', value: 0 },
  { alias: 'ONLINE', text: '已上架', value: 2 },
);

/*
 * 发布时间
 *
 * @enum
 */
export const PublishTimeType = new Enum(
  { alias: 'ALL', text: '不限', value: 0 },
  { alias: 'TODAY', text: '今天', value: 1 },
  { alias: 'LATEST_7', text: '近7天', value: 2 },
  { alias: 'LATEST_30', text: '近30天', value: 3 }
);

/*
 * 发布时间
 *
 * @enum
 */
export const SeeNoTenantChoice = new Enum(
  { alias: 'YES', text: '只看未添加客源', value: 1 }
);

 /*
 * 审核状态
 *
 * @enum
 */
 export const CompanyAuditStatus = new Enum(
  { alias: 'WAIT', text: '未认证', value: 1 },
  { alias: 'PASS', text: '认证通过', value: 2 },
  { alias: 'READY', text: '认证中', value: 3 },
  { alias: 'DENY', text: '认证驳回', value: 4 }
);

/*
 * 备案信息
 *
 * @enum
 */
export const RecordInfo = new Enum(
  { alias: 'ING', text: '备案未完成', value: 2 },
  { alias: 'YES', text: '已备案', value: 3 },
  { alias: 'NO', text: '备案失败', value: 4 },
);

/*
 * 备案信息
 *
 * @enum
 */
export const NatureLandInfo = new Enum(
  { alias: 'ZZ', text: '住宅', value: 1 },
  { alias: 'SY', text: '商业', value: 2 },
  { alias: 'BG', text: '办公', value: 3 },
  { alias: 'GYCF', text: '工业厂房', value: 4 },
  { alias: 'QT', text: '其他', value: 5 }
);

/*
 * 信用免押
 *
 * @enum
 */
 export const CreditStatus = new Enum(
  { alias: 'OPEN', text: '支持', value: 1 },
  { alias: 'CLOSE', text: '不支持', value: 0 }
);


// 评估结果（免押方案） 0-待评估、1-押金全免-非自费、2-押金全免、3-押金半免、4-押金不免 ,
export const EvaluateResult = new Enum(
  { alias: '0', text: '待评估', value: 0 },
  { alias: '1', text: '诚信免押全部', value: 1 },
  { alias: '2', text: '诚信免押全部', value: 2 },
  { alias: '3', text: '诚信免押一半', value: 3 },
  { alias: '4', text: '全额支付', value: 4 },
);

export const DepositPay = new Enum(
  { alias: '1', text: '诚信免押全部', value: 1 },
  { alias: '2', text: '诚信免押全部', value: 2 },
  { alias: '3', text: '诚信免押一半', value: 3 },
  { alias: '4', text: '全额支付', value: 4 },
);

export const EvaluateText = new Enum(
  { alias: '1', text: '押金支付方式=诚信免押全部，押金退还金额=0', value: 1 },
  { alias: '2', text: '押金支付方式=诚信免押全部，押金退还金额=0', value: 2 },
  { alias: '3', text: '押金支付方式=诚信免押一半，押金退还金额=押金金额/2', value: 3 },
  { alias: '4', text: '押金支付方式=全额支付，押金退还金额=押金全额', value: 4 },
);

/*
 * 是非选项
 *
 * @enum
 */
 export const YesOrNo = new Enum(
  { alias: 'YES', text: '是', value: 1 },
  { alias: 'NO', text: '否', value: 0 }
);


 /*
 * 审核状态
 *
 * @enum
 */
 export const CommunityAuditStatus = new Enum(
  { alias: 'WAIT', text: '已提交', value: 0 },
  { alias: 'PASS', text: '新建成功', value: 1 },
  { alias: 'DENY', text: '新建失败', value: 2 }
);


/*
 * 仅看自己提交的
 *
 * @enum
 */
export const SeeSelfSubmit = new Enum(
  { alias: 'YES', text: '仅看自己提交的', value: 1 }
);

export const RightTypeEnum = new Enum(
  { alias: '1', text: '依附于房屋的装修归甲方所有', value: 1 },
  { alias: '2', text: '要求乙方恢复原状', value: 2 },
  { alias: '3', text: '向乙方收取恢复工程实际发生的费用', value: 3 },
);

export const ArbitralAgencyEnum = new Enum(
  { alias: '1', text: '深圳国际仲裁院申请仲裁', value: 1 },
  { alias: '2', text: '深圳仲裁委员会申请仲裁', value: 2 },
  { alias: '3', text: '租赁房屋所在地人民法院起诉', value: 3 },
);

