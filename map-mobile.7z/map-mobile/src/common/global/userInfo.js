/**
 * @file 权限管理对象
 */

let instance = null;

class UserInfo {

  info = {};

  constructor() {
    if (!instance) instance = this;
    return instance;
  }

  /**
   * 添加权限
   *
   * @param {Array} authorities 权限说明
   */
  set(userInfo) {
    this.info = { ...userInfo };
  }
}

export default new UserInfo();
