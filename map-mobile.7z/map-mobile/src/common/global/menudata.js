export default {
	"menulist": [
		{
			"itemName": "地图数据管理",
			"key": "mapdata",
			"children": [
				{
					"itemName": "楼层数据管理",
					"url": "/manage/mapdata/floormaptable"
				},
				// {
				// 	"itemName": "AP管理",
				// 	"url": "/manage/mapdata/apmanage"
				// }
			]
	    }
	]
}