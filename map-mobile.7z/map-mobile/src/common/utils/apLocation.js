export  default  {
    apLocation() {
        alert('111');
    }
}