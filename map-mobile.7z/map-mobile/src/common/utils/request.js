const Ajax = require('axios');
import { message } from 'antd';
import _ from 'underscore';
import { routerRedux } from 'dva/router'

import userInfo from 'common/global/userInfo';

const delayCloseTime = 5;

const prefix = '/api/v1.0/';

const info = function (error, text) {
  message.error(
    error && error.response && error.response.data && error.response.data.msg || text || '服务器错误',
    delayCloseTime,
  );
};

const httpStatus = {
  403: error => {
    if (error && error.response && error.response.data) {
      const data = error.response.data;
      if (data.msg) {
        info(error);
      }
      else {
        info(error, '权限错误');
      }
    }
    else {
      info(error, '权限错误');
    }
    // window.location.href = '/unauth';
  },
  401: (error, options) => {
    if (!options || !options.noRefresh) {
      window.location.href = '/logon';
    }
  },
  500: error => {
    window.location.href = '/systemError'
  },
  502: error => {
    window.location.href = '/systemError'
  },
  504: error => {
    window.location.href = '/systemError'
  },
};

function errorHandle(error, options) {
  const code = error && error.response && error.response.status;
  let err;
  if (code && httpStatus[code]) {
    err = httpStatus[error.response.status](error, options);
  } else if (!networkStatus) {
    info(error, '当前网络已断开！');
  }
  else {
    info(error, '服务器错误，请刷新重试');
  }
  return err ? {error: err} : {error};
}


export function request(url, options) {
  if ((options.method === 'GET' || !options.method) && options.data) {
    options.params = options.data;
    options.data = null;
  }

  if ((options.method === 'POST' || options.method === 'PUT') && !options.data && options.params) {
    options.data = options.params;
    options.params = null;
  }

  let { id, userName } = userInfo.info;
  let nurl = null;

  let userStr = '_u=' + (id || -1);
  let timeStamp = '_t=' + new Date().getTime();

  let query = url.indexOf('?') >= 0 ? '&' : '?';

  if(/aliyun/.test(url)) {
    nurl = url;
  } else {
    nurl =  `${prefix}${url}${query}${timeStamp}&${userStr}`;
  }
  

  return Ajax({
    method: options.method || 'GET',
    url: nurl,
    data: options.data || {},
    params: options.params || {},
    timeout: 50000
  }).then(
    ({data}) => {
      if (data.code === 200 || 
        (typeof data.code === 'undefined' && typeof data.SUCCESS === 'undefined')) {
        if(data.code === 200) {
          return { data: data.data };
        } else {
          return { data: data }
        }
      }
      else {
        let resp = {};
        if (data.message) {
          resp.globalError = data.message;
        }
        if (data.fieldErrors) {
          resp.fieldErrors = data.fieldErrors;
        }
        return resp;
      }
    }
  ).catch((error) => {
    // console.log(error);
    return errorHandle(error, options);
  });
};

export function upload(url, data) {
  var form = new FormData(); // FormData 对象
  _.each(
    data,
    (value, key) => {
      form.append(key, value);
    }
  );
  return Ajax.post(
    prefix + url,
    form,
    {
      method: 'post',
      headers: { 'Content-Type': 'multipart/form-data' }
    }).then(response => ({ data: response.data || '' }))
    .catch((error) => {
      return errorHandle(error);
    }
  );
}
