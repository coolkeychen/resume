import * as ajax from './request';
import transform from './transform';
import tools from './tools';

export default {
  ...ajax,
  transform,
  tools,
};
