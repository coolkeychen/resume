//import permission from 'common/permission';
import breadcrumbdata from 'common/global/breadcrumbdata';
import Sockette from 'sockette';


export default {
  // download(url) {
  //   var tempLink = document.createElement('a');
  //   tempLink.setAttribute('download', '');
  //   tempLink.href = window.location.host + url;
  //   tempLink.setAttribute('target', '_blank');
  //   document.body.appendChild(tempLink);
  //   tempLink.click();
  //   document.body.removeChild(tempLink);
  // }
  queryURL(name) {
    let reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`, 'i')
    let r = window.location.search.substr(1).match(reg)
    if (r != null) return decodeURIComponent(r[2])
    return null
  },
  getCrumbsData(routes, dispatch, data) {
      const path = routes.map(route => route.path).join('/').replace(/\/\//, '/');
      let crumbsData = null;
      if(crumbsData) {
        crumbsData = data
      } else {
        crumbsData = breadcrumbdata[path]
      }
      dispatch({
        type: 'frame/putCrumbData',
        payload: {
          crumbsData
        }
      })
  },
  download(url) {
    var id = 'download-iframe';
    var frame;
    if (document.getElementById(id)) {
      frame = document.getElementById(id);
    }
    else {
      frame = document.createElement('iframe');
      frame.setAttribute('id', id);
      document.body.appendChild(frame);
    }
    frame.style.height= '1px';
    frame.style.width = '1px';
    frame.src = 'http://' + window.location.host + url;
  },

  rowClassName(record, index) {
    // 奇数行
    if (index % 2 === 0) {
      return 'axg-table-row-odd';
    }

    return 'axg-table-row-even';
  },

  goUnauth() {
    window.location.href = '/unauth';
  },

  // getAuthSidebar(sidebarData=[]) {
  //   return sidebarData.filter(item => permission.isAllow(item.auth));
  // },

  isEmpty(str) {
    if (!str || str.replace(/\s+/g, '').length === 0) {
      return true;
    }

    return false;
  },

  sendMessage(url,json) {
    /* if (!url) {
        return;
    }  

    const ws = new Sockette('ws://10.17.5.124:8080/ws', {
      timeout: 5e3,
      maxAttempts: 10
    });

    const linkf = (e) => {
      console.log('连接开启！');
    }

    

    console.log(ws);
    

    ws.open();
    ws.send(sendjson);
    ws.open();
    ws.close();
    setTimeout(ws.reconnect, 10e3);*/
   
    let sendjson = {
        "method":"GET",
        "uri":"/test/webSocketMessage",
        "body":{
            "test":"123456"
        }
    }
   

    /* var ws = new WebSocket('ws://10.17.5.124:8080/ws');
    ws.onmessage = function(msg) { console.log(msg); };
    if (ws.readyState===1) {
        ws.send(JSON.stringify(message));
    }else{
    } */

    const socket = new WebSocket("ws://10.17.5.124:8080/ws");

    const message = JSON.stringify(sendjson);
    //添加事件监听
    socket.addEventListener('open', function () {
        socket.send(message)
    });

    socket.onmessage = function(event) { console.log(event.data) };

  },

  apLocation() {

        alert('111');
    }
}
