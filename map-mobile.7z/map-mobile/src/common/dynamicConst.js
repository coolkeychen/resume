/**
 * @file 后端字段管理对象
 */

import _ from 'underscore';

let instance = null;

class DynamicConst {

  const = {}

  constructor() {
    if (!instance) instance = this;
    return instance;
  }

  /**
   * 添加权限
   *
   * @param {Array} authorities 权限说明
   */
  build(data) {
    this.const = { ...data };
  }

  getItem(key) {
    return this.const[key];
  }

  toCheckArray(key) {
    let item = this.const[key];
    if (!item) {
      return [];
    }

    return Object.keys(item).map(
      (key) => {
        let obj = item[key];
        return { label: obj.alias || obj, value: obj.value || key };
      },
    )
  }

  getTextFromValue(key, value) {
    let target = this.getItem(key);
    if (_.isArray(target)) {
      let item = target.find((item, key) => {
        if (item.value || item.value === 0) {
          return item.value === value;
        }
        else {
          return key === value;
        }
      });
      return item ? (item.alias || item) : null;
    }
    return target ? target[value] : null;
  }

}

export default new DynamicConst();
