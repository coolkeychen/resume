
(function(doc, win) {
	var docEle = doc.documentElement || doc.body;

	fn = function() {
		var width = docEle.clientWidth;
		var fontSize = width / 750 * 28;
		docEle.style.fontSize = fontSize + 'px';
	}
	win.addEventListener('resize', fn, false);
    doc.addEventListener("DOMContentLoaded", fn, false);
})(document, window)