import React, { Component } from 'react';
import _ from 'underscore';
import { transform, tools } from 'common/utils';
import List from 'components/common/list';
import { PAGE_SIZE } from 'common/global/const';
import ListResultStatus from 'components/biz/listResultStatus';

const FormList = (Wrapper, moduleName) => {
  class WrapperComponent extends Component {

    state = {
      query: {
        pageSize: PAGE_SIZE,
        pageNo: 1,
      }
    }

    onSelectChange = (field) => {
      return (value) => {
        this.listChange({
          [field]: value,
          pageNo: 1,
        });
      }
    }

    getList = (searchParams={}) => {
      const params = {
        ...this.props.searchParams,
        ...this.state.query,
        ...searchParams,
      };

      this.props.dispatch({
        type: `${this.props.moduleName}/paramsChange`,
        payload: params,
      });

      this.props.dispatch({
        type: `${this.props.moduleName}/${this.props.type}` + 'List',
        payload: params,
      });
    }

    // downLoad = (fields) => {
    //   const params = transform.fieldsToParams(fields, this.props.dateType === 'month' ? 'YYYY-MM' : 'YYYY-MM-DD');
    //   const url = this.props.downloadUrl ? this.props.downloadUrl : `/api/score/${this.props.moduleName}/download`;
    //   tools.download(url + transform.objectToHashString({ ...params}));
    //   this.props.dispatch({
    //     type: this.props.type + '/toggleDownload',
    //     payload: true,
    //   });
    // }

    paramsChange = (searchParams, callback) => {
      const params = {
        ...this.props.searchParams,
        ...this.state.query,
        ...searchParams,
      };
      this.setState({query: params}, callback);
    }

    listChange = (params={}) => {
      this.paramsChange(params, this.getList);
    }

    handleFormFields = (fields, callback) => {
      let value = fields;
      if (this.props.handleFormFields) {
        value = this.props.handleFormFields(value);
      }
      const params = transform.fieldsToParams(value);
      this.listChange({...params, pageNo: 1});
    }

    onSubmit = (fields) => {
      this.handleFormFields(fields);
    }

    render() {
      const error = this.props.fieldErrors;
      const listClass = this.props.isHidden ? 'list-container hide' : 'list-container';
      const isSearch = _.find(this.state.query, (item, key) => key !== 'pageSize' && key !== 'pageNo' && !!item);

      return (
        <div className={listClass}>
          <Wrapper
            {...this.props}
            autoSubmit = {true}
            download = { this.downLoad }
            onSubmit = { this.onSubmit }
            onSelectChange = { this.onSelectChange }
            getList = { this.getList }
            isSearch = {!!isSearch}
            listChange = { this.listChange }
          />
          <div className="list-result clearfix">

          {
            (!!this.props.list && this.props.list.length > 0)
            ? (<List
              { ...this.props }
              bordered={true}
              dataSource={this.props.list}
              pagination={{ pageSize: this.state.query.pageSize, current: this.state.query.pageNo, total: this.props.total }}
              onChange={this.listChange}
            />)

            : (<ListResultStatus list={[]} isSearch={!!isSearch} listEmptyTitle={this.props.listEmptyTitle} />)
          }
          </div>
        </div>
      );
    }
  }

  return WrapperComponent;
};

export default FormList;
