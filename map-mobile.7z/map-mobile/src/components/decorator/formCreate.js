import { Form } from 'antd';

const FormCreate = Form.create({
  
});

export default FormCreate;
