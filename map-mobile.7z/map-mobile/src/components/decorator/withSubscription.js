/*
* @author:  lisijin025
* @createTime:  2017-06-09, 13:56:27 GMT+0800
* @description:  封装高阶组件
*/
import React, { Component } from 'react';

const withSubscription = (Wrapper, otherProps) => {
  class WrapperComponent extends Component {

    render() {
      return (
        <Wrapper
          { ...this.props }
          { ...otherProps }
        />
      );
    }
  }

  return WrapperComponent;
}

export default withSubscription;