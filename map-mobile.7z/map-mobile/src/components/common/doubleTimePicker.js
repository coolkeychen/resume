/*
* @author:  libenzhi957
* @createTime:  2017-06-21, 17:00:44 GMT+0800
* @description: 时间区间选择
*/

import React, { Component } from 'react';
import { TimePicker, Form, Row, Col, Button } from 'antd';
import moment from 'moment';

export default class DoubleTimePicker extends Component {
  
  onChange = type => value => this.changeHandle(type, value);

  changeHandle = (type, value) => {
    this.props.onChange({
      ...this.props.value,
      [type]: value
    });
  }

  render() {
    const { timeFormat } = this.props;

    return (
      <div className="axg-double-time-picker">
        <TimePicker
          value={this.props.value && this.props.value.startTime && moment(this.props.value.startTime, timeFormat) || null}
          format={timeFormat}
          onChange={ this.onChange('startTime') }
          placeholder="起始时间"
        />
        <span> - </span>
        <TimePicker
          value={this.props.value && this.props.value.endTime && moment(this.props.value.endTime, timeFormat) || null}
          format={timeFormat}
          onChange={ this.onChange('endTime') }
          placeholder="结束时间"
        /> 
      </div>
    );
  } 
  
}