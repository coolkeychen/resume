import React, { PropTypes } from 'react';
import { Select, Icon, InputNumber } from 'antd';

import { fromNumberToArray, fromNumberToString, selectOptions } from 'common/utils/transform';

const Option = Select.Option;

export default class LayoutField extends React.Component {

  constructor(props) {
    super(props);
    let state = this.setStateFromProps(props);
    this.state = {
      ...state
    };
  }

  componentWillReceiveProps(nextProps) {
    let state = this.setStateFromProps(nextProps);
    this.setState({ ...state });
  }

  setStateFromProps(props) {
    let { hallNum, toiletNum, roomNum } = props.value;
    return {
      hallNum: fromNumberToString(hallNum),
      toiletNum: fromNumberToString(toiletNum),
      roomNum: fromNumberToString(roomNum),
    };
  }

  fireChange = () => {
    let { hallNum, toiletNum, roomNum } = this.state;
    this.props.onChange({ hallNum, toiletNum, roomNum });
  }

  onHallChange = (hallNum) => {
    this.setState({ hallNum }, this.fireChange);
  }

  onToiletChange = (toiletNum) => {
    this.setState({ toiletNum }, this.fireChange);
  }

  onRoomChange = (roomNum) => {
    this.setState({ roomNum }, this.fireChange);
  }

  render() {
    let { hallNum, toiletNum, roomNum } = this.state;
    return (
      <div className="ant-input-group-wrapper">
        <InputNumber min={0} max={20} value={roomNum}
          style={{ width: 90, marginRight: 10 }} onChange={this.onRoomChange}>
        </InputNumber>
        室
        <InputNumber min={0} max={20} value={hallNum}
          style={{ width: 90, marginLeft: 10, marginRight: 10 }} onChange={this.onHallChange}>
        </InputNumber>
        厅
        <InputNumber min={0} max={20} value={toiletNum}
          style={{ width: 90, marginLeft: 10, marginRight: 10 }} onChange={this.onToiletChange}>
        </InputNumber>
        卫
      </div>
    );
  }
}

LayoutField.propTypes = {};
