import React, { PropTypes } from 'react';
import { Table } from 'antd';
import { PAGE_SIZE, PAGE_OPTIONS } from 'common/global/const';
import { rowClassName } from 'common/utils/tools';

export default class List extends React.Component {

  static propTypes = {
    columns: PropTypes.array,
    dataSource: PropTypes.array,
    pagination: PropTypes.object,
    loading: PropTypes.bool,
    bordered: PropTypes.bool,
    onChange: PropTypes.func,
  };

  static defaultProps = {
    columns: [],
    dataSource: [],
    pagination: {},
    loading: false,
    bordered: false,
  };

  constructor(props) {
    super(props);
    this.state = {
      expandedRowKeys: [],
    };
  }

  onPageChange(page) {
    this.props.onChange({
      beginDate: page.beginDate,
      pageNo: page.current,
      pageSize: page.pageSize,
      endDate: page.endDate,
    });
  }

  // 点击展开的时候，闭合其他行
  onExpand(expanded, record) {
    var name = this.props.rowKey || 'key';
    this.setState({
      expandedRowKeys: expanded ? [record[name]] : [],
    });
  }

  genClass = (record, index) => {
    const getRowClass = this.props.rowClassName || rowClassName;
    const lineClass = getRowClass(record, index);
    let other = '';
    if (record[this.props.rowKey || 'key'] && record[this.props.rowKey || 'key'] === this.state.expandedRowKeys[0]) {
      other = 'expanded-line';
    }
    return lineClass + ' ' + other;
  }

  render() {
    const paginationType = {
      showSizeChanger: false,
      pageSizeOptions: PAGE_OPTIONS,
    }

    let { columns, dataSource, pagination, loading, expandedRowRender, rowKey, bordered } = this.props;
    return (
      <Table
        rowKey= { rowKey }
        columns = { columns }
        dataSource = { dataSource }
        pagination = { { ...paginationType, ...pagination  }}
        loading = { loading }
        onChange = { ::this.onPageChange }
        expandedRowRender = { expandedRowRender }
        bordered = { bordered }
        expandedRowKeys = { this.state.expandedRowKeys }
        onExpand = { ::this.onExpand }
        rowClassName = { this.genClass }
      />
    );
  }
}
