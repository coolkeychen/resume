import React, { PropTypes } from 'react';
import { Link } from 'react-router';
import { Select, Input, Icon, Row, Col, Modal, Button, Tooltip, Alert, message } from 'antd';
import _ from 'underscore';

import { transform } from 'common/utils';
import { getCommunities } from 'biz/services/frame';

import CommunityBuilder from './communityBuilder';

import './richRegion.less';

const Option = Select.Option;

function formatCommunities(communities) {
  if (!communities) {
    return [];
  }
  return communities.map(({ communityId, fullname }) => ({ id: communityId, text: fullname }));
}

export default class CommunitySelector extends React.Component {

  constructor(props) {
    super(props);
    let state = this.getStateFromProps(props);
    this.state = { showEditor: false, ...state };
    this.store = {};
  }

  getStateFromProps(props) {
    let { value } = props;
    // 只提取其中的部分数据
    let {  communityName, communityId } = value;
    // 根据传入的省市区版块id配置对应的选择下拉数据
    let parsedData = { communityName, communityId };

    // 做两个副本，一个是真实的数据，一个是供编辑使用的
    let cacheData = { ...parsedData };
    let realData = { ...parsedData };

    return { cacheData, realData };
  }

  componentWillReceiveProps(nextProps) {
    let state = this.getStateFromProps(nextProps);
    this.setState({ ...state });
  }

  updateCacheData(data, callback) {
    let { cacheData } = this.state;
    this.setState({ cacheData: { ...cacheData, ...data } }, callback);
  }

  showEditor = () => {
    this.setState({ showEditor: true });
  }

  closeEditor = () => {
    this.setState({ showEditor: false, cacheData: { ...this.state.realData } });
  }

  // 输入小区改变，会引发
  // 1. 搜索提示列表
  // 2. 清空communityId
  onCommunityChange = async (name) => {
    const param = { name };
    this.updateCacheData({ communityName: name, communityId: null });
    let { data } = await getCommunities(param);
    let communities = data ? data.list : [];
    this.updateCacheData({ communities });
  }

  // 根据HDMP获取社区地理位置并更新
  onCommunitySelect = (communityId, option) => {
    let { communityName } = this.state.cacheData.communities.find(item => item.communityId == communityId);
    this.updateCacheData({ communityName, communityId });
  }

  fireChange = () => {
    this.props.onChange({ ...this.state.realData });
  }

  submit = () => {
    let { cacheData } = this.state;
    let { communityName, communityId } = cacheData;

    if (!communityId) {
      message.error('请选择一个已经存在的小区！');
      return false;
    }

    this.setState({ realData: { ...cacheData }, showEditor: false }, this.fireChange);
  }

  buildOne = () => {
    this.setState({showCommunityBuilder: true});
  }

  closeBuilder = () => {
    this.setState({showCommunityBuilder: false});
  }

  render() {
    let modalFormItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 18 },
    };

    let { showEditor, cacheData, realData, showCommunityBuilder } = this.state;
    let { communityName, communityId } = realData;
    let { readonly } = this.props;

    return (
      <div className="axg-rich-region">
        <p>
          { communityId && <Icon type="environment" /> } {communityName}
          { <Button type="primary" onClick={this.showEditor}>{ communityId ? '修改小区' : '添加小区' }</Button> }
          <Link to={`/index/housing/communityList`}>查询新建小区审核进度</Link>
        </p>
        <Modal title="小区地址" maskClosable={ false } className="axg-rich-region-modal" width={700} visible={showEditor} onOk={ this.submit } onCancel={ this.closeEditor }>
          <Row className="axg-rich-region-form-item">
            <Col className="ant-form-item-label"  { ...modalFormItemLayout.labelCol }>
              <label className="ant-form-item-required" title="小区名">小区名</label>
            </Col>
            <Col className="ant-form-item-control-wrapper" { ...modalFormItemLayout.wrapperCol }>
              <div className="ant-form-item-control">
                <Select
                  className="axg-rich-region-select-item"
                  mode="combobox"
                  value={cacheData.communityName}
                  placeholder="输入或选择小区名"
                  notFoundContent=""
                  defaultActiveFirstOption={false}
                  showArrow={false}
                  filterOption={false}
                  onSearch={this.onCommunityChange}
                  onSelect={this.onCommunitySelect}
                  ref="regionSelect"
                  style={{width: 227}}
                >
                  { transform.selectOptions(formatCommunities(cacheData.communities)) }
                </Select>
              </div>
              <div className="ant-form-item-control">
                搜不到该小区，<Button className="axg-button-like-link" type="default" onClick={this.buildOne} size="large">点我创建</Button>
              </div>
            </Col>
          </Row>
        </Modal>
        <CommunityBuilder
          show={showCommunityBuilder}
          onClose ={this.closeBuilder}
          onSuccess = {this.closeBuilder}
          defaultLongitude="22.554878" defaultLatitude="114.093151" />
      </div>
    );
  }
}

CommunitySelector.propTypes = {};
