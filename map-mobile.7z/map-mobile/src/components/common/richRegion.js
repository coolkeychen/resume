import React, { PropTypes } from 'react';
import { Select, Input, Icon, Tooltip, Row, Col, Modal, Button, Spin, message } from 'antd';
import _ from 'underscore';

import { transform } from 'common/utils';
import { getRegions } from 'biz/services/frame';

import './richRegion.less';

const Option = Select.Option;

async function getDataOfRegion(regionId) {
  let blocksRes = regionId ? await getRegions(regionId) : [];
  let blocks = blocksRes;
  let blockId = blocks[0] ? blocks[0].id : undefined;

  return { blocks, blockId };
}

async function getPCRBData(data) {
  let { regionId, blockId } = data;
  let regions = await getRegions(365);
  let blocks = regionId ? await getRegions(regionId) : {};
  return { regions, blocks };
}

export default class RichRegion extends React.Component {

  constructor(props) {
    super(props);
    let state = this.getStateFromProps(props);
    this.state = { showMap: false, ...state };
    this.store = {};
  }

  parseDataFromInput(data) {
    let { regionId, blockId } = data;
    regionId = regionId ? ('' + regionId) : undefined;
    blockId = blockId ? ('' + blockId) : undefined;
    return { ...data, regionId, blockId };
  }

  getStateFromProps(props) {
    let { value } = props;
    // 只提取其中的部分数据
    let { latitude, longitude } = value;
    // 根据传入的省市区版块id配置对应的选择下拉数据
    let parsedData = { latitude, longitude, ...this.parseDataFromInput(value) };

    // 做两个副本，一个是真实的数据，一个是供地图使用的
    let cacheData = { ...parsedData };
    let realData = { ...parsedData };

    return { cacheData, realData };
  }

  fireChange = () => {
    this.props.onChange({ ...this.state.realData });
  }

  componentWillReceiveProps(nextProps) {
    let state = this.getStateFromProps(nextProps);
    this.setState({ ...state });
  }

  componentDidMount() {
    let geoc = new BMap.Geocoder();
    let geolocation = new BMap.Geolocation();

    this.setState({ geoc, geolocation });
  }

  updateCacheData(data, callback) {
    let { cacheData } = this.state;
    this.setState({ cacheData: { ...cacheData, ...data } }, callback);
  }

  onRegionChange = (regionId) => {
    return getDataOfRegion(regionId).then(regionData => {
      regionId = '' + regionId;
      let newState = { regionId, ...regionData };
      this.updateCacheData(newState);
      return newState;
    });
  }

  onBlockChange = (blockId) => {
    blockId = '' + blockId;
    this.updateCacheData({ blockId });
  }

  parsePointByAddress = (callback) => {
    let city = '深圳市';
    let address = this.state.cacheData.address || '';
    let region = this.getTextFromValue('region', this.state.cacheData);
    let block = this.getTextFromValue('block', this.state.cacheData);

    // 将地址解析结果显示在地图上,并调整地图视野
    this.state.geoc.getPoint(
      city + ' ' + region + ' ' + block + ' ' + address,
      (point) => {
        if (callback) {
          callback(point);
        }
        this.focusMapByPoint(point);
        this.updateByPoint(point);
      },
      city
    );
  }

  getTextFromValue = (type, fromStore) => {
    let resource;
    let value;
    let text = '';
    let store = fromStore || this.state.realData;
    if (type === 'region') {
      resource = store.regions;
      value = store.regionId;
      text = store.regionName;

    }
    else if (type === 'block') {
      resource = store.blocks;
      value = store.blockId;
      text = store.blockName;
    }

    let item = null;

    if (resource !== undefined && resource.length > 0) {
      item = resource.find(({ id }) => id === value);
    }

    text = text || '';
    return item ? item.text : text;
  }

  // 根据获取到的地图point更新地址信息
  updateByPoint = (point) => {
    // 更新的是cacheData，避免没必要的重刷
    if (point) {
      this.state.geoc.getLocation(point, (rs) => {
        let state = {
          latitude: '' + point.lat,
          longitude: '' + point.lng,
        };
        this.updateCacheData(state);
      });
    }
  }

  onAddressChange = (e) => {
    let address = e.target.value;
    this.updateCacheData({ address }, () => {
      this.parsePointByAddress();
    });
  }

  search = () => {
    this.parsePointByAddress(point => {
      if (!point) {
        message.error('未搜到输入地址的坐标，请手动拖拽坐标点定位，或者重新输入有效地址！');
      }
    });
  }

  focusMapByPoint = (point) => {
    if (point) {
      let map = this.state.map;
      map.centerAndZoom(point, 21); // 初始化地图,设置中心点坐标和地图级别

      let pointMarker = new BMap.Marker(point);
      pointMarker.enableDragging()
      pointMarker.addEventListener('dragend', e => {//拖动标注结束
        var pointNew = e.point;
        this.updateCacheData({ longitude: pointNew.lng, latitude: pointNew.lat });
      });

      map.addOverlay(pointMarker);
      if (this.state.pointMarker) {
        map.removeOverlay(this.state.pointMarker);
      }
      this.setState({ pointMarker });
    }
  }

  showMap = () => {
    this.setState({ showMap: true }, this.initMap);
  }

  initMap = () => {
    let map = this.state.map;
    // 创建一个map
    if (!map) {
      map = new BMap.Map('axg-map');
      map.addControl(new BMap.NavigationControl());
      this.setState({ map });
    }
    getPCRBData(this.state.realData).then(result => {
      this.setState(
        {
          cacheData: {
            ...this.state.cacheData,
            ...result
          }
        }
      );
      // 先从真实数据中获取坐标
      let { latitude, longitude } = this.state.realData;
      // 不存在，就获取住建局自己的地址。。。
      if (!latitude || !longitude) {
        latitude = '22.554878';
        longitude = '114.093151';
      }

      let point = new BMap.Point(longitude, latitude);
      point && this.focusMapByPoint(point);
      this.setState({ mapLoading: false });
    });
  }

  validateBeforeSubmit() {
    let { cacheData } = this.state;

    let { provinceId, cityId, blockId, regionId, address, latitude, longitude } = cacheData;

    if (!provinceId || !cityId || !blockId || !regionId || !address) {
      message.error('请填写区域、版块及地址！');
      return false;
    }

    if (!longitude || !latitude) {
      message.error('坐标获取失败，请点击刷新定位点！');
      return false;
    }

    if (address.length > 200) {
      message.error('地址最多200个字符！');
      return false;
    }

    return true;
  }

  submitMap = () => {
    let { cacheData } = this.state;
    this.validateBeforeSubmit() && this.setState({ realData: { ...cacheData }, showMap: false }, this.fireChange);
  }

  closeMap = () => {
    this.setState({ showMap: false, cacheData: { ...this.state.realData } });
  }

  render() {
    let modalFormItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 18 },
    };

    let { showMap, cacheData, realData, mapLoading } = this.state;
    let { readonly } = this.props;

    let { address } = realData;

    let regionDetail = `
      ${this.getTextFromValue('province')} ${this.getTextFromValue('city')}
      ${this.getTextFromValue('region')} ${this.getTextFromValue('block')}
      ${ address || ''}`;

    return (
      <div className="axg-rich-region">
        <p>
          { !!!readonly && <Button type="primary" onClick={this.showMap}>{ address ? '修改地址' : '添加地址' }</Button> }
          { address && <Icon type="environment" /> }{ regionDetail }
        </p>
        { !!!readonly && <Modal title="楼栋地址" maskClosable={ false } className="axg-rich-region-modal" width={700} visible={showMap} onOk={ this.submitMap } onCancel={ this.closeMap }>
          <Spin tip="地图卖力加载中..." spinning={ mapLoading }/>
          <Row className="axg-rich-region-form-item">
            <Col className="ant-form-item-label" { ...modalFormItemLayout.labelCol }>
              <label className="ant-form-item-required" title="区域/版块">区域/版块</label>
            </Col>
            <Col className="ant-form-item-control-wrapper" { ...modalFormItemLayout.wrapperCol }>
              <div className="ant-form-item-control">
                <Select value={cacheData.regionId} placeholder="所在区域"
                  className="axg-rich-region-select-item"
                  onChange={this.onRegionChange}>
                  { transform.selectOptions(cacheData.regions) }
                </Select>
                <Select value={cacheData.blockId} placeholder="所在版块"
                  className="axg-rich-region-select-item"
                  onChange={this.onBlockChange}>
                  { transform.selectOptions(cacheData.blocks) }
                </Select>
              </div>
            </Col>
          </Row>
          { cacheData.cityId &&
          <Row className="axg-rich-region-form-item">
            <Col className="ant-form-item-label"  { ...modalFormItemLayout.labelCol }>
              <label className="ant-form-item-required" title="地址">地址</label>
            </Col>
            <Col className="ant-form-item-control-wrapper" { ...modalFormItemLayout.wrapperCol }>
              <div className="ant-form-item-control">
                <Input value={cacheData.address} placeholder="输入详细地址"
                  className="axg-rich-region-input-item"
                  onChange={this.onAddressChange}/>
                  <Button className="axg-rich-region-search-button" type="primary" onClick={this.search}>刷新定位点</Button>
                  <Tooltip placement="top" title="定位不准确？挪动图钉纠正下~">
                  <Icon type="info-circle" />
                  </Tooltip>
              </div>
            </Col>
          </Row>
          }
          <Row className="axg-rich-region-form-item">
            <Col className="ant-form-item-label"  { ...modalFormItemLayout.labelCol }>
            </Col>
            <Col className="ant-form-item-control-wrapper" { ...modalFormItemLayout.wrapperCol }>
              <div id="axg-map"></div>
            </Col>
          </Row>
        </Modal> }
      </div>
    );
  }
}

RichRegion.propTypes = {};
