/*
* @author:  lisijin025
* @createTime:  2017-06-11, 11:12:30 GMT+0800
* @description:  sidebar
*/

import { Menu } from 'antd';
import React from 'react';
import { Link } from 'dva/router';
import './sidebar.less';
import 'components/biz/resourceMenu.less';
import _ from 'underscore';

export default function Sidebar({ location, dataSource, mode }) {

  const items = dataSource.map(
    (item) => (
      <Menu.Item key={ mode === 'regex' ? item.key : item.path }>
        <Link to={ item.path }>
          <span className="nav-text">{ item.name }</span>
        </Link>
      </Menu.Item>
    )
  );

  function getKeyFromPath() {
    return _.find(
      dataSource,
      item => location.pathname.indexOf(item.key) >= 0
    ) || {};
  }

  return (
    <Menu
      className="sidebar"
      selectedKeys={ mode === 'regex' ? [getKeyFromPath()['key']] : [location.pathname] }
    >
      { items }
    </Menu>
  );
}