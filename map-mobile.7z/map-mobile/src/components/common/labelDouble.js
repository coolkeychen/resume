import { Col, Row } from 'antd';
import React, { PropTypes } from 'react';
import { Link } from 'dva/router';
import Image from 'components/common/image';

function LabelDouble({lbL,lbR}) {
  /*let element = value;
  if (type === 'arrayEnum') {
    let text = value.map(item => enumInstance.getTextFromValue(item));
    element = <span>{ text.join('、') }</span>
  }
  else if (type === 'image') {
    element = value.map((item, index) => <Image src={ item.picUrl }  width={ width } height={ height } isCover={ item.isCover } key={index + new Date().getTime()}/>);
  }*/

  return (
    <Row>
      <Col xs={12} sm={12} md={12} lg={12} xl={12}>
        { lbL }
      </Col>
      <Col xs={12} sm={12} md={12} lg={12} xl={12}>
        { lbR }
      </Col>
    </Row>
  );
}

LabelDouble.propTypes = {};

export default LabelDouble;
