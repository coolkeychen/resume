/**
 * Created by libenzhi957 on 2017/7/29.
 */
import React, { PropTypes } from 'react';
import { Select } from 'antd';

import { transform } from 'common/utils';
import { getRegions } from 'biz/services/frame';

async function getProvinceData() {
  let provinces = await getRegions();
  return { provinces };
}

async function getCityData(provinceId) {
  let cities = await getRegions(provinceId);
  return { cities };
}

export default class ProvinceCity extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      provinces: [],
      cities: [],
      provinceId: undefined,
      cityId: undefined,
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setStateFromProps(nextProps);
  }

  setStateFromProps(props) {
    let { value } = props;
    let { provinceId, cityId } = value;
    provinceId = provinceId ? ('' + provinceId) : undefined;
    cityId = cityId ? ('' + cityId) :  undefined;
    if(provinceId && provinceId != this.state.provinceId){
      getCityData(provinceId).then(result => {
        const { cities } = result;
        this.setState(
          {
            ...result,
            provinceId,
            cityId,
          }
        );
      });
    }
  }

  componentDidMount() {
    getProvinceData().then(result => {
      this.setState(
        {
          ...this.state,
          ...result,
        }
      )
    });
  }

  fireChange = () => {
    this.props.onChange({ ...this.state });
  }

  onProvinceChanges = (provinceId) => {
    getCityData(provinceId).then(result => {
      const { cities } = result;
      this.setState(
        {
          ...this.state,
          ...result,
          provinceId,
          cityId: cities[0].id ? cities[0].id : '',
        },
        this.fireChange
      );
    });
  }

  onCityChange = (e) => {
    this.setState({ cityId: e }, this.fireChange);
  }

  render() {
    const { provinceId, cityId, provinces, cities } = this.state;
    const { readonly } = this.props;

    return (
      <div className="ant-form-item-select-wrapper">
         <Select
          placeholder="请选择省份"
          value={provinceId}
          disabled={readonly}
          onChange={this.onProvinceChanges}
        >
          { transform.selectOptions(provinces) }
        </Select>
        <Select
          placeholder="请选择城市"
          value={cityId}
          disabled={readonly}
          onChange={this.onCityChange}
        >
          { transform.selectOptions(cities) }
        </Select>
      </div>
    );
  }
}

ProvinceCity.propTypes = {};
