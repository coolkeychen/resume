import React, { PropTypes } from 'react';
import { Select, Input, Icon, Tooltip, Row, Col, Modal, Button, Spin, message } from 'antd';
import _ from 'underscore';

import { transform } from 'common/utils';
import { getRegions } from 'biz/services/frame';

import './inlineRegion.less';

const Option = Select.Option;

async function getDataOfProvince(provinceId) {
  let cities;
  let cityId = undefined;
  if (!provinceId || provinceId == -1) {
    cities = [];
  }
  else {
    let citiesRes = await getRegions(provinceId);
    cities = citiesRes;
  }
  let cityData = await getDataOfCity(cityId);
  return { cities, cityId, ...cityData };
}

async function getDataOfCity(cityId) {
  let regions;
  let regionId = undefined;;
  if (!cityId || cityId == -1) {
    regions = [];
  }
  else {
    let regionsRes = await getRegions(cityId);
    regions = regionsRes;
  }
  let regionData = await getDataOfRegion(regionId);
  return { regions, regionId, ...regionData };
}

async function getDataOfRegion(regionId) {
  let blocks;
  let blockId = undefined;
  if (!regionId || regionId == -1) {
    blocks = [];
  }
  else {
    let blocksRes = await getRegions(regionId);
    blocks = blocksRes;
  }
  return { blocks, blockId };
}

async function getProvinceData() {

  function isHotCity(city) {
    if (city.indexOf('上海') !== -1 || city.indexOf('北京') !== -1 || city.indexOf('广东') !== -1) {
      return true;
    }
    return false;
  }

  let provinceRes = await getRegions();
  // 重新对province排序，北上广置顶
  let normalProvinces = provinceRes.filter(item => !isHotCity(item.text));
  let hotProvinces = provinceRes.filter(item => isHotCity(item.text));
  let provinces = [...hotProvinces, ...normalProvinces];
  return { provinces };
}

export default class InlineRegion extends React.Component {

  constructor(props) {
    super(props);
    let state = this.getStateFromProps(props);
    this.state = { ...state };
    this.store = {};
  }

  getStateFromProps(props) {
    let { value } = props;
    // 根据传入的省市区版块id配置对应的选择下拉数据
    return { ...this.parseDataFromInput(value) };
  }

  parseDataFromInput(data) {
    let { provinceId, cityId, regionId, blockId } = data;
    provinceId = provinceId ? ('' + provinceId) : undefined;
    cityId = cityId ? ('' + cityId) :  undefined;
    regionId = regionId ? ('' + regionId) : undefined;
    blockId = blockId ? ('' + blockId) : undefined;
    return { provinceId, cityId, regionId, blockId };
  }

  fireChange = () => {
    let { provinceId, cityId, regionId, blockId } = this.state;
    this.props.onChange({provinceId, cityId, regionId, blockId});
  }

  componentWillReceiveProps(nextProps) {
    let { value } = this.props;
    let state = this.getStateFromProps(nextProps);
    this.setState({ ...state });
  }

  componentDidMount = () => {
    this.initData();
  }

  onProvinceChange = (provinceId, noEvent) => {
    if (this.props.noCity) {
      let newState = { provinceId };
      this.setState({ ...newState }, noEvent || this.fireChange);
    }
    else {
      getDataOfProvince(provinceId).then(provinceData => {
        let newState = { provinceId, ...provinceData };
        this.setState({ ...newState }, this.fireChange);
      });
    }
  }

  onCityChange = (cityId, noEvent) => {
    if (this.props.noRegion) {
      let newState = { cityId };
      this.setState({ ...newState }, noEvent || this.fireChange);
    }
    else{
      getDataOfCity(cityId).then(cityData => {
        let newState = { cityId, ...cityData };
        this.setState({ ...newState }, noEvent || this.fireChange);
      });
    }
  }

  onRegionChange = (regionId, noEvent) => {
    if (this.props.noBlock) {
      let newState = { regionId };
      this.setState({ ...newState }, noEvent || this.fireChange);
    }
    else {
      getDataOfRegion(regionId).then(regionData => {
        regionId = '' + regionId;
        let newState = { regionId, ...regionData };
        this.setState({ ...newState }, noEvent || this.fireChange);
      });
    }
  }

  onBlockChange = (blockId, noEvent) => {
    blockId = '' + blockId;
    this.setState({ blockId }, noEvent || this.fireChange);
  }

  initData = () => {
    let { provinceId, cityId, regionId, blockId } = this.state;
    let { noProvince, noCity, noRegion, noBlock } = this.props;

    if (noProvince) {
      if (noCity) {
        if (noRegion) {
          this.onRegionChange(regionId, function() {});
        }
        else {
          this.onCityChange(cityId, function() {});
        }
      }
      else {
        this.onProvinceChange(provinceId, function() {});
      }
    }
    else {
      getProvinceData().then(result => {
        this.setState({ ...result });
      });
    }
  }

  render() {
    let {
      provinceId, cityId, blockId, regionId,
      provinces, cities, regions, blocks,
      hasProvince, hasCity, hasRegion, hasBlock
    } = this.state;


    let { noProvince, noCity, noRegion, noBlock } = this.props;

    return (
      <div className="axg-inline-region">
        { !noProvince &&
          <Select value={provinceId} placeholder="不限省份"
          className="axg-inline-region-select-item"
          onChange={this.onProvinceChange}>
          <Option key='all_province' value="-1">不限省份</Option>
          { transform.selectOptions(provinces) }
          </Select>
        }
        { !noCity &&
          <Select value={cityId} placeholder="不限城市"
            className="axg-inline-region-select-item"
            onChange={this.onCityChange}>
            <Option key='all_city' value="-1" >不限城市</Option>
            { transform.selectOptions(cities) }
          </Select>
        }
        { !noRegion &&
          <Select value={regionId} placeholder="不限区域"
            className="axg-inline-region-select-item"
            onChange={this.onRegionChange}>
            <Option key='all_region' value="-1" >不限区域</Option>
            { transform.selectOptions(regions) }
          </Select>
        }
        { !noBlock &&
          <Select value={blockId} placeholder="不限版块"
            className="axg-inline-region-select-item"
            onChange={this.onBlockChange}>
            <Option key='all_block' value="-1" >不限版块</Option>
            { transform.selectOptions(blocks) }
          </Select>
        }
      </div>
    );
  }
}

InlineRegion.propTypes = {};
