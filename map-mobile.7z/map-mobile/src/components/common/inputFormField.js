import React, { PropTypes } from 'react';
import { Button, Form, Select, Input, InputNumber, Checkbox, Radio } from 'antd';

import SubDate from 'components/common/subDate';
import CheckboxWithAll from 'components/common/checkboxWithAll';

import { transform } from 'common/utils';
import classnames from 'classnames';
import { TimeRangeMonth } from 'common/global/const';


const Option = Select.Option;
const FormItem = Form.Item;
const CheckboxGroup = Checkbox.Group;
const RadioGroup = Radio.Group;

import { DatePicker } from 'antd';
import moment from 'moment';
const { MonthPicker, RangePicker } = DatePicker;

const dateFormat = 'YYYY/MM/DD';
const monthFormat = 'YYYY/MM';

class InputFormField extends React.Component {

  render = () => {
    const entity = { ...this.props.entity };

    let {
      getFieldDecorator, label, field, options, required,
      placeholder, datasource, type, unit,
      max, min, onSwitch, readonly, style, operation, className,
      onSelectChange, step
    } = this.props;

    const itemProps = { label, required };
    const elemProps = { style };

    let fields = field.split('.');
    let value = fields.reduce(
      (value, fieldKey) => {
        return value ? value[fieldKey] : null;
      },
      { ...entity }
    );

    let inputEle = <Input
      placeholder={placeholder || ('输入' + label) } addonAfter={unit}  disabled={readonly}  { ... elemProps } className={className}/>;
    let defaultValue = '';

    if (type === 'select') {
      defaultValue = undefined;
      value =  value ? '' + value : undefined;
      let options;
      if (this.props.keyMapOptions) {
        options = transform.selectOptions(datasource, this.props.keyMapOptions);
      }
      else {
        options = transform.selectOptions(datasource);
      }
      inputEle = (<Select
        placeholder={ placeholder || ('选择' + label) } disabled={readonly}
        { ...elemProps } >{options}</Select>);
    }

    if (type === 'selectWithChange') {
      defaultValue = undefined;
      value =  value ? '' + value : undefined;
      const options = transform.selectOptions(datasource);
      inputEle = (<Select
        onChange={onSelectChange(field)}
        placeholder={ placeholder || ('选择' + label) } disabled={readonly}
        { ...elemProps } >{options}</Select>);
    }

    else if (type === 'checkbox') {
      defaultValue = [];
      inputEle = <CheckboxWithAll datasource={datasource}  disabled={readonly}  { ... elemProps }/>;
    }
    else if (type === 'radio') {
      defaultValue = datasource && datasource[0] && datasource[0].value || '';
      inputEle = <RadioGroup options={datasource} onChange={onSwitch} disabled={readonly} { ... elemProps }/>;
    }


    else if (type === 'textarea') {
      defaultValue = '';
      inputEle = <Input
        className="text-area"
        type="textarea" rows={4} placeholder={ placeholder || ('输入' + label)}
        disabled={readonly}  { ... elemProps }/>;
    }
    else if (type === 'inputNumber') {
      defaultValue = min || 1;
      inputEle = <InputNumber min={min || 0} max={max || 99999999} disabled={readonly} { ... elemProps } step={step || 1}/>;
    }
    else if (type === 'space') {
      unit = <span>m<sup>2</sup></span>;
      inputEle = <InputNumber min={min || 0} max={max || 99999999} precision={2} disabled={readonly} { ... elemProps }/>;
    }
    else if (type === 'houseSpace') {
      unit = <span>m<sup>2</sup></span>;
      inputEle = <InputNumber min={min || 0} max={max || 99999999} disabled={readonly} { ... elemProps }/>;
    }
    else if (type === 'houseMoney') {
      inputEle = <InputNumber min={min || 0} max={max || 99999999} disabled={readonly} { ... elemProps } step={100}/>;
    }
    else if (type === 'money') {
      inputEle = <InputNumber min={min || 0} max={max || 99999999} disabled={readonly} { ... elemProps } step={100}/>;
    }
    else if (type === 'datepicker') {
      defaultValue = moment( new Date());
      value = value ? moment( value ) : undefined;
      inputEle = <DatePicker allowClear={ false } format="YYYY-MM-DD" />;
    }
    else if (type === 'datepickerTime') {
      defaultValue = moment( new Date(), dateFormat);
      value = value ? moment( value ) : undefined;
      inputEle = <DatePicker  showTime format="YYYY-MM-DD HH:mm" />;
    }
    else if (type === 'subDate') {
      value = {
        startDate: options && options.noInit ? '' : this.props.startDate ? moment(this.props.startDate) : moment(),
        endDate: options && options.noInit ? '' :  this.props.endDate ? moment(this.props.endDate) : moment(),
      };
      inputEle = <SubDate operation={operation} {...options}/>;
    }
    else if (type === 'mobile') {
      options={
        ...options,
      };
    }

    if (value === undefined) {
      value = defaultValue;
    }
    else if (type === 'money' || type === 'space') {
      value = (value / 100).toFixed(2);
    }

    return (
      <FormItem {...itemProps} className={ classnames({ uns: !!this.props.hide}) }>
        { this.props.explain ? <div>{this.props.explain}</div> : ''}
        {
            getFieldDecorator(field, { ...options, initialValue: value, first: true })(inputEle)
        }
        {unit}
      </FormItem>
    );
  }
}

export default InputFormField;
