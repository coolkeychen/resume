import React, { PropTypes } from 'react';
import { Button, Table, Icon } from 'antd';
import EditableCell from 'components/common/editableCell';
import { rowClassName } from 'common/utils/tools';

import _ from 'underscore';

export default class TableFormField extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      datasource: [...props.datasource],
      editMode: false
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      datasource: [...nextProps.datasource],
    });
  }

  onCellChange = (index, key) => {
    return (val) => {
      const datasource = [...this.state.datasource];
      datasource[index][key] = val;
      this.setState({
        datasource: [...datasource],
      }, this.fireChange);
    };
  }

  fireChange = () => {
    this.props.onChange({ value: this.state.datasource, key: this.props.datasourceKey });
  }

  handleDelete = (record) => {
    let { datasource } = this.state;
    let newDatasource = _.filter(datasource, ({key}) => key !== record.key);
    this.setState({
      datasource: [...newDatasource],
    }, this.fireChange);
  }

  handleEdit = (record) => {
    let { datasource } = this.state;
    let targetDatasourceIndex = datasource.findIndex(({key}) => key === record.key);
    datasource[targetDatasourceIndex].editable = true;
    this.setState({ datasource: [...datasource] }, this.fireChange);
  }

  handleEditCancel = (record) => {
    let { datasource } = this.state;
    let targetDatasourceIndex = datasource.findIndex(({key}) => key === record.key);
    datasource[targetDatasourceIndex].editable = false;

    this.setState({ datasource: [...datasource] }, this.fireChange);
  }

  handleAdd = () => {
    let { datasource } = this.state;
    let { lazyEdit } = this.props;
    let index = datasource.length;
    let newLine = { ...this.props.defaultNewLine(index), editable: lazyEdit ? false: true };
    let state = {
      ...this.state,
      datasource: [...datasource, ...[newLine]]
    }
    this.setState(state, this.fireChange);
  }

  buildRows = ({columns, actionFixed, lazyEdit}) => {
    let rowColumns = columns.map((item, index) => {
      let { title, type, key, width, fixed, min, max, datasource, keyMapOptions, textType } = item;
      return {
        title,
        dataIndex: key,
        width,
        //fixed,
        render: (value, record, index) => {
          let editable;
          if (lazyEdit) {
            editable = record.editable === undefined ? false : record.editable;
          }
          else {
            editable = true;
          }

          let error = null;
          if (record.error && record.error[key]) {
            error = record.error[key];
          }

          return <EditableCell
            min = {min}
            max = {max}
            cellType = { type }
            textType = { textType }
            datasource = { datasource }
            keyMapOptions = { keyMapOptions }
            value = { value }
            cellKey = { key }
            onChange = {this.onCellChange(index, key)}
            style = {{ width }}
            editable = {editable}
            error = { error }
          />
        },
      };
    });

    let actionColumn = {
      title: '操作',
      width: 80,
      key: 'action',
      render: (text, record, index) => (
        <div>
          <Button className="axg-button-like-link" onClick={
            (e) => {
              this.handleDelete(record);
            }
          }>删除</Button>
        </div>
      ),
    };

    if (actionFixed) {
      actionColumn.fixed = 'right';
    }
    rowColumns.push(actionColumn);
    return { rowColumns };
  }

  switchEditMode = () => {
    let editMode = !this.state.editMode;
    let datasource = this.state.datasource.map(item => ({...item, editable: editMode}));
    this.setState({editMode, datasource});
  }

  render() {
    let { columns, actionTitle, scroll, actionFixed, lazyEdit } = this.props;
    let { datasource, editMode } = this.state;
    let { rowColumns } = this.buildRows({columns, actionFixed, lazyEdit});
    let specialAttribute = {};
    return (
      <div>
        <Button
          type="primary" className="axg-button-like-link" onClick={ this.handleAdd } style={{ marginBottom: 15 }}>
          <Icon type="plus-square-o" style={{fontSize: 14}}/>
          {actionTitle}
        </Button>

        {
          lazyEdit && <Button
          type="primary" className="axg-button-like-link" onClick={ this.switchEditMode } style={{ marginBottom: 15 }}>
          <Icon type={ editMode ? 'unlock' : 'lock' } style={{fontSize: 14}}/>
          { editMode ? '关闭编辑' : '编辑' }
          </Button>
        }
        { !!datasource && !!datasource.length &&
          <Table
            columns = { rowColumns }
            dataSource = {datasource}
            pagination = { false }
            rowKey = "key"
            bordered
            scroll = {scroll}
            className="axg-field-table"
            rowClassName={ rowClassName }
          />
        }
      </div>
    );
  }
}

TableFormField.propTypes = {};
