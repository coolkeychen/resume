import { Menu, Icon } from 'antd';
import React, { PropTypes } from 'react';
import { Link } from 'dva/router';
import './siderMenu.less';

const SubMenu = Menu.SubMenu;

function SiderMenu({ handleSelect, frame }) {
  const { menus, current, openKey } = frame.sider;

  function pMenu(menuItem, index, current) {
    let paddingPos = 24 * index;
    let menuClass = 'leaf-menu-' + paddingPos;

    let pathName = window.location.pathname;

    if(menuItem.children) {
       return <SubMenu key={menuItem.itemName} title={<span>{menuItem.itemName}</span>} key={menuItem.key}>
          {menuItem.children.map(item => pMenu(item, ++index))}
      </SubMenu>
    }
    
    if(!menuItem.children && menuItem.url) {
      return <Menu.Item key={menuItem.url}>
        <Link to={ menuItem.url } >{ menuItem.itemName }</Link>
      </Menu.Item>
    }
  }
  return (
    <div className="sider-menu">
      <div class="wel-back"></div>
      <Menu
        onSelect={handleSelect}
        selectedKeys={[current]}
        defaultOpenKeys={[openKey]}
        className="sider-menu"
        mode="inline"
        >
        {menus.map(menuItem => pMenu(menuItem, 1, current))}
      </Menu>
    </div>
  );
}

SiderMenu.propTypes = {
  frame: PropTypes.object.isRequired,
  handleSelect: PropTypes.func.isRequired,
};

export default SiderMenu;
