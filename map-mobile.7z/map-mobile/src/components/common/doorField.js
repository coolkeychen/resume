import React, { PropTypes } from 'react';
import { Input } from 'antd';

export default class DoorField extends React.Component {

  constructor(props) {
    super(props);
    let state = this.setStateFromProps(props);
    this.state = {
      ...state
    };
  }

  componentWillReceiveProps(nextProps) {
    let state = this.setStateFromProps(nextProps);
    this.setState({ ...state });
  }

  setStateFromProps(props) {
    return { ...props.value };
  }

  fireChange = () => {
    this.props.onChange({ ...this.state });
  }

  onBuildingNoChange = (e) => {
    this.setState({ buildingNo: e.target.value }, this.fireChange);
  }

  onRoomNoChange = (e) => {
    this.setState({ roomNo: e.target.value }, this.fireChange);
  }

  onUnitNoChange = (e) => {
    this.setState({ unitNo: e.target.value }, this.fireChange);
  }

  render() {
    const { buildingNo, unitNo, roomNo } = this.state;
    const { readonly } = this.props;
    const style = { marginRight: 10, width: 90 };

    let elem;
    if (readonly) {
      elem = <div>{buildingNo}栋{unitNo}单元{roomNo}室</div>;
    }
    else {
      elem = <div className="ant-input-group-wrapper">
         <Input value={buildingNo} style={style}  onChange={this.onBuildingNoChange}/>栋&nbsp;&nbsp;
         <Input value={unitNo} style={style} onChange={this.onUnitNoChange}/>单元&nbsp;&nbsp;
         <Input value={roomNo} style={style} onChange={this.onRoomNoChange}/>室
      </div>;
    }
    return elem;
  }
}

DoorField.propTypes = {};
