/*
* @author:  yangpeifen564
* @createTime:  2017-07-03
* @description: 租金范围选择
*/

import React, { Component } from 'react';
import { Form, Row, Col, Button,InputNumber } from 'antd';
import moment from 'moment';

export default class RangeInput extends Component {
  
  onChange = type => value => this.changeHandle(type, value);

  changeHandle = (type, value) => {
    this.props.onChange({
      ...this.props.value,
      [type]: value
    });
  }

  render() {
    const { timeFormat } = this.props;

    return (
      <div className="rental-range">
        <InputNumber 
          value={ this.props.value.rentalMin }
          min={0} max={100000} onChange={ this.onChange('rentalMin') }
        />
        <span style={{marginRight: "3px"}}>-</span>
        <InputNumber
          value={ this.props.value.rentalMax}
          min={0} max={100000} onChange={ this.onChange('rentalMax') } 
        />
        <span className="ant-form-text">元/月</span>
      </div>
    );
  } 
  
}