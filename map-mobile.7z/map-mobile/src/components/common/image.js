import React, { PropTypes, Component } from 'react';
import { Modal, Button, Icon } from 'antd';
import './image.less';

class Image extends Component {

  constructor(props) {
    super(props);
    this.state = { previewVisible: false };
  }

  handleCancel = () => this.setState({ previewVisible: false })

  handlePreview = () => {
    this.setState({
      previewImage: this.props.fullSrc,
      previewVisible: true
    });
  }

  render () {
    let { src, width, height, fullSrc } = this.props;
    let { previewVisible, previewImage } = this.state;
    return (
      <div className="axg-image full-mask" style={{width, height}}>
        <img className="axg-image-body" src={ src } width={ width } height={ height } />
        <span className="axg-image-actions-cover">
          <Icon className="axg-image-actions-cover-btn" title="查看大图" onClick={this.handlePreview} type="arrows-alt" />
        </span>
        <Modal className="axg-image-pop-previewer" width={900} visible={previewVisible} footer={null} onCancel={this.handleCancel}>
          <img alt="预览" src={previewImage} />
        </Modal>
      </div>
    );
  }
}

Image.propTypes = {};

export default Image;
