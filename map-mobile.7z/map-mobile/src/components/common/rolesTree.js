import React, { PropTypes } from 'react';
import { Checkbox, Card } from 'antd';
import _ from 'underscore';

import './rolesTree.less';

import Label from 'components/common/label';

const CheckboxGroup = Checkbox.Group;

function mixData(roles, value) {
  return roles.map(role => {
    let modules = role.modules.map(module => {
      let checkedRoles = _.intersection(_.pluck(module.roles, 'value'), value);
      return {
        ...module,
        checkedRoles
      }
    });

    return {
      title: role.title,
      key: role.key,
      modules
    };
  });
}

function checkIsAll(modules) {
  let notAllModule = modules.find(module => module.checkedRoles.length !== module.roles.length);
  if (notAllModule) {
    return false;
  }
  return true;
}

function checkIsPartial(modules) {
  let checkedModule = modules.find(module => module.checkedRoles.length);
  if (checkedModule) {
    return true;
  }
  return false;
}

function getModuleIndexByKey(key, datasource) {
  return datasource.findIndex(item => item.key === key);
}

function getValueFromMixedData(data) {
  return data.reduce(
    (roles, module) => {
      let currentRoles = module.modules.reduce(
        (roles, subModule) => {
          roles = [ ...roles, ...subModule.checkedRoles ];
          return roles;
        },
        []
      );

      roles = [ ...roles, ...currentRoles ];
      return roles;
    },
    []
  );
}

function buildDirectMap(topModules) {
  return topModules.reduce(
    (map, topModule) => {
      let newMap = topModule.modules.reduce(
        (map, { roles }) => {
          roles.forEach(role => {
            map[role.value] = role.label;
          });
          return map;
        },
        {}
      );
      return { ...map, ...newMap };
    },
    {}
  );
}

export default class RolesTree extends React.Component {

  roles = [
    {
      title: '账户模块',
      key: 'account',
      modules: [
        {
          title: '角色管理',
          key: 'role',
          roles: [
            {
              value: 'AXG_ACCOUNT_ROLE_ADD',
              label: '添加角色',
            },
            {
              value: 'AXG_ACCOUNT_ROLE_MODIFY',
              label: '编辑角色',
            },
            {
              value: 'AXG_ACCOUNT_ROLE_VIEW',
              label: '查看角色',
            },
            {
              value: 'AXG_ACCOUNT_ROLE_DELETE',
              label: '删除角色',
            }
          ]
        },
        {
          title: '员工管理',
          key: 'staff',
          roles: [
            {
              value: 'AXG_ACCOUNT_STAFF_ADD',
              label: '添加员工',
            },
            {
              value: 'AXG_ACCOUNT_STAFF_MODIFY',
              label: '编辑员工',
            },
            {
              value: 'AXG_ACCOUNT_STAFF_VIEW',
              label: '查看员工',
            },
            {
              value: 'AXG_ACCOUNT_STAFF_DELETE',
              label: '删除员工',
            },
            {
              value: 'AXG_ACCOUNT_STAFF_RESOURE_DISTRIBUTE',
              label: '分配房源',
            },
          ]
        }
      ]
    },
    {
      title: '房源管理模块',
      key: 'resource',
      modules: [
        {
          title: '房源管理',
          key: 'resource',
          roles: [
            {
              value: 'AXG_RESOURCE_ADD',
              label: '添加房源',
            },
            {
              value: 'AXG_RESOURCE_MODIFY',
              label: '编辑房源',
            },
            {
              value: 'AXG_RESOURCE_VIEW',
              label: '查看房源',
            },
            {
              value: 'AXG_RESOURCE_DELETE',
              label: '删除房源',
            },
            {
              value: 'AXG_RESOURCE_DISPATCH',
              label: '发房',
            },
          ]
        }
      ]
    },
    {
      title: '合同模块',
      key: 'contract',
      modules: [
        {
          title: '业主合同',
          key: 'owner',
          roles: [
            {
              value: 'AXG_CONTRACT_OWNER_VIEW',
              label: '查看业主合同',
            },
            {
              value: 'AXG_CONTRACT_OWNER_ADD',
              label: '添加业主合同',
            },
            {
              value: 'AXG_CONTRACT_OWNER_BASIC_MODIFY',
              label: '编辑业主信息',
            },
            {
              value: 'AXG_CONTRACT_OWNER_DELETE',
              label: '删除业主合同',
            },
            {
              value: 'AXG_CONTRACT_OWNER_CHECKOUT',
              label: '退租(业主合同)',
            }
          ]
        },
        {
          title: '业主账单',
          key: 'ownerbill',
          roles: [
            {
              value: 'AXG_CONTRACT_OWNER_BILL_VIEW',
              label: '查看业主账单',
            },
            {
              value: 'AXG_CONTRACT_OWNER_BILL_ADD',
              label: '添加业主账单',
            },
            {
              value: 'AXG_CONTRACT_OWNER_BILL_MODIFY',
              label: '编辑业主账单',
            },
            {
              value: 'AXG_CONTRACT_OWNER_BILL_DELETE',
              label: '删除业主账单',
            },
            {
              value: 'AXG_CONTRACT_OWNER_BILL_PAY',
              label: '付款',
            }
          ]
        },
        {
          title: '租客合同',
          key: 'tenant',
          roles: [
            {
              value: 'AXG_CONTRACT_TENANT_VIEW',
              label: '查看租客合同',
            },
            {
              value: 'AXG_CONTRACT_TENANT_ADD',
              label: '添加租客合同',
            },
            {
              value: 'AXG_CONTRACT_TENANT_BASIC_MODIFY',
              label: '编辑租客信息',
            },
            {
              value: 'AXG_CONTRACT_TENANT_DELETE',
              label: '删除租客合同',
            },
            {
              value: 'AXG_CONTRACT_TENANT_CHECKOUT',
              label: '退租(租客合同) ',
            }
          ]
        },
        {
          title: '租客账单',
          key: 'tenantbill',
          roles: [
            {
              value: 'AXG_CONTRACT_TENANT_BILL_VIEW',
              label: '查看租客账单',
            },
            {
              value: 'AXG_CONTRACT_TENANT_BILL_ADD',
              label: '添加租客账单',
            },
            {
              value: 'AXG_CONTRACT_TENANT_BILL_MODIFY',
              label: '编辑租客账单',
            },
            {
              value: 'AXG_CONTRACT_TENANT_BILL_DELETE',
              label: '删除租客账单',
            },
            {
              value: 'AXG_CONTRACT_RENTER_BILL_RECEIPT',
              label: '收款',
            },
            {
              value: 'AXG_CONTRACT_RENTER_BILL_REMIND',
              label: '催租',
            }
          ]
        },
      ]
    },
    {
      title: '财务模块',
      key: 'finance',
      modules: [
        {
          title: '流水管理',
          key: 'flow',
          roles: [
            {
              value: 'AXG_FINANCE_FLOW_ADD',
              label: '添加流水',
            },
            {
              value: 'AXG_FINANCE_FLOW_VIEW',
              label: '查看流水',
            },
            {
              value: 'AXG_FINANCE_FLOW_DELETE',
              label: '删除流水',
            },
          ]
        },
        {
          title: '账单管理',
          key: 'bill',
          roles: [
            {
              value: 'AXG_FINANCE_BILL_VIEW',
              label: '查看账单',
            },
            {
              value: 'AXG_FINANCE_BILL_MODIFY',
              label: '编辑账单',
            },
            {
              value: 'AXG_FINANCE_BILL_DELETE',
              label: '删除账单',
            },
          ]
        }
      ]
    },
    {
      title: '客源模块',
      key: 'tenant',
      modules: [
        {
          title: '客源管理',
          key: 'tenant',
          roles: [
            {
              value: 'AXG_TENANT_VIEW',
              label: '查看租客',
            },
            {
              value: 'AXG_TENANT_ADD',
              label: '添加租客',
            },
            {
              value: 'AXG_TENANT_MODIFY',
              label: '编辑租客',
            },
            {
              value: 'AXG_TENANT_DISTRIBUTE',
              label: '分配租客',
            },
            {
              value: 'AXG_TENANT_TRACK',
              label: '添加跟进',
            },
            {
              value: 'AXG_TENANT_INVALID',
              label: '设为无效',
            },
            {
              value: 'AXG_TENANT_DELETE',
              label: '删除租客',
            },
            {
              value: 'AXG_TENANT_CONTRACT',
              label: '租客签约',
            },
          ]
        }
      ]
    },
    {
      title: '服务模块',
      key: 'service',
      modules: [
        // {
        //   title: '收房管理',
        //   key: 'helper',
        //   roles: [
        //     {
        //       value: 'AXG_SERVICE_HELPER_VIEW',
        //       label: '收房助手查看',
        //     },
        //     {
        //       value: 'AXG_SERVICE_HELPER_FOLLOW',
        //       label: '收房助手关注',
        //     },
        //     {
        //       value: 'AXG_SERVICE_HELPER_CANCEL_FOLLOW',
        //       label: '收房助手取消关注',
        //     },
        //   ]
        // },
        // {
        //   title: '海报管理',
        //   key: 'poster',
        //   roles: [
        //     {
        //       value: 'AXG_SERVICE_POSTER_VIEW',
        //       label: '海报查看',
        //     },
        //     {
        //       value: 'AXG_SERVICE_POSTER_ADD',
        //       label: '海报添加',
        //     },
        //   ]
        // },
        {
          title: '推广管理',
          key: 'marketing',
          roles: [
            {
              value: 'AXG_SERVICE_MARKETING_VIEW',
              label: '房源推广查看',
            },
            {
              value: 'AXG_SERVICE_MARKETING_DISPATCH',
              label: '房源推广发房',
            },
            {
              value: 'AXG_SERVICE_MARKETING_ONLINE',
              label: '房源推广上架',
            },
            {
              value: 'AXG_SERVICE_MARKETING_OFFLINE',
              label: '房源推广下架',
            },
          ]
        },
        {
          title: '潜在客源',
          key: 'leads',
          roles: [
            {
              value: 'AXG_SERVICE_MARKETING_LEADS_VIEW',
              label: '潜在客源查看',
            // },
            // {
            //   value: 'AXG_SERVICE_MARKETING_LEADS_ADD',
            //   label: '潜在客源添加',
            }
          ]
        }
      ]
    },
  ]

  constructor(props) {
    super(props);
    let state = this.getStateFromProps(props);
    let directMap = buildDirectMap(this.roles);
    this.state = { ...state, directMap };
  }

  getStateFromProps(props) {
    let { value } = props;
    let mixedData = mixData(this.roles, value);
    return { mixedData };
  }

  componentWillReceiveProps(nextProps) {
    let state = this.getStateFromProps(nextProps);
    this.setState({ ...state });
  }

  fireChange = () => {
    this.props.onChange(getValueFromMixedData(this.state.mixedData));
  }

  buildSubRolesCheck = (modules, topKey) => {
    return modules.map(module => {
      return (
        <Card title={module.title} key={module.key + '_submodule'}>
          <CheckboxGroup
            options={module.roles} value={module.checkedRoles}
            onChange={this.changeHandler(module.key + '_' + topKey)} key={module.key + '_' + topKey} />
        </Card>
      );
    });
  }

  buildTopRolesCheck = (modules) => {
    return modules.map(({ key, title, modules }) => {
      return (
        <div className="axg-roles-tree-module-wrapper" key={key + '_module'}>
          <div className="axg-roles-tree-module-title">
            <Checkbox
              onChange={this.checkAllHandler(key)}
              checked={checkIsAll(modules)}
              indeterminate={checkIsPartial(modules)}
              key={key + '_module_roles'}
            >{title}</Checkbox>
          </div>
          {this.buildSubRolesCheck(modules, key)}
        </div>
      );
    });
  }


  buildTopRolesLabel = (modules) => {
    return modules.map(({ key, title, modules }) => {
      let isEmpty = !checkIsAll(modules) && !checkIsPartial(modules);
      return (
        isEmpty ? '' : <div className="axg-roles-tree-module-wrapper" key={key + '_module'}>
          <div className="axg-roles-tree-module-title">{title}</div>
          {this.buildSubRolesLabel(modules, key)}
        </div>
      );
    });
  }

  buildSubRolesLabel = (modules, topKey) => {
    return modules.map(module => {
      let labels = module.checkedRoles.map(role => this.state.directMap[role]);
      return (
        labels.length ? <Label title={ module.title } key={module.key + '_submodule'} value={ labels.join('、') } /> : ''
        /*labels.length ? <Card title={module.title + '：'} key={module.key + '_submodule'}>
          {labels.join('，')}
        </Card> : ''*/
      );
    });
  }

  changeHandler = (key) => {
    return (checkedRoles) => {
      let keys = key.split('_');
      let mixedData = [ ...this.state.mixedData ];
      let topModuleKey = getModuleIndexByKey(keys[1], mixedData);
      let subModuleKey = getModuleIndexByKey(keys[0], mixedData[topModuleKey].modules);
      mixedData[topModuleKey]['modules'][subModuleKey].checkedRoles = [ ...checkedRoles ];
      this.setState({ mixedData }, this.fireChange);
    }
  }

  checkAllHandler = (key) => {
    return (e) => {
      let mixedData = [ ...this.state.mixedData ];
      let topModuleKey = getModuleIndexByKey(key, mixedData);
      let modules = mixedData[topModuleKey].modules.map(module => {
        if(e.target.checked){
          return {
            ...module,
            checkedRoles: _.pluck(module.roles, 'value')
          }
        }
        else {
          return {
            ...module,
            checkedRoles: []
          }
        }
      });

      mixedData[topModuleKey].modules = [ ...modules ];

      this.setState({ mixedData }, this.fireChange);
    }
  }

  render() {
    let { mixedData } = this.state;
    let { readonly } = this.props;
    return (
      <div className="axg-roles-tree">
      { !readonly && this.buildTopRolesCheck(mixedData) }
      { readonly && this.buildTopRolesLabel(mixedData) }
      </div>
    );
  }
}

RolesTree.propTypes = {};
