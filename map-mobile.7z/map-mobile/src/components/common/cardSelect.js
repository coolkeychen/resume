import React, { PropTypes } from 'react';
import _ from 'underscore';

import './cardSelect.less';

export default class CardSelect extends React.Component {

  constructor(props) {
    super(props);
    let state = this.setStateFromProps(props);
    this.state = {
      ...state
    };
  }

  componentWillReceiveProps(nextProps) {
    let state = this.setStateFromProps(nextProps);
    this.setState({ ...state });
  }

  setStateFromProps({ value }) {
    value = value || [];
    return { value };
  }

  fireChange = () => {
    let { value } = this.state;
    this.props.onChange(value);
  }

  onToggleSelect = (id) => {
    return () => {
      let value = this.state.value;
      if (value.indexOf(id) === -1) {
        value.push(id);
      }
      else {
        value = _.without(value, id);
      }

      this.setState({ value }, this.fireChange);
    }
  }

  buildItems = () => {
    const { list } = this.props;
    const { value } = this.state;
    return list.map(({ id, name, src }) => {
      let itemClassName = value.includes(id) ? 'axg-card-select-item-selected' : '';
      return (
        <div className={'axg-card-select-item ' + itemClassName} key={ id } onClick={this.onToggleSelect(id)}>
          <img className="axg-card-select-item-thumbnail" src={ src } alt={ name } />
        </div>
      );
    });
  }

  render() {
    return (<div className="axg-card-select">{this.buildItems()}</div>);
  }
}

CardSelect.propTypes = {};
