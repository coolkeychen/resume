/*
* @author:  lisijin025
* @createTime:  2017-06-09, 12:00:44 GMT+0800
* @description: 日期区间选择
*/

import React, { PureComponent } from 'react';
import { DatePicker, Form, Row, Col, Button } from 'antd';
import moment from 'moment';
import { DateFormat } from 'common/global/enum';
import './subDate.less';
import { TimeRangeMonth } from 'common/global/const';
import classnames from 'classnames';

export default class Subdate extends PureComponent {

  state = {
    selectOption: -1
  }

  changeTimeRange = (type, range, key) => {
    return () => {
      const time = {
        year: 'y',
        month: 'months',
      }
      var start = this.props.value && this.props.value.startDate || moment();
      var end = moment(start).add(range, time[type]).subtract(1, 'day');

      this.changeHandle('endDate', end);
      this.setState({
        selectOption: key,
      });
    }
  }
  
  onChange = type => value => this.changeHandle(type, value);

  changeHandle = (type, value) => {
    this.setState({
      selectOption: -1,
      // [type]: value, 
    });
    this.props.onChange({
      ...this.props.value,
      [type]: value
    });
  }

  disabledStartDate = (startDate) => {
    const endDate = this.props.value && this.props.value.endDate;
    if (!startDate || !endDate) {
      return false;
    }
    return startDate.valueOf() > endDate.valueOf();
  }

  disabledEndDate = (endDate) => {
    const startDate = this.props.value && this.props.value.startDate;
    if (!endDate || !startDate) {
      return false;
    }
    return endDate.valueOf() <= startDate.valueOf();
  }

  render() {
    const { operation, noInit, disableDate } = this.props;

    let optionButton = [];

    if (operation) {
      optionButton = operation.map(
        (item, key) => (<Button key={key} type="primary"
          className={classnames('switch-button', {"switch-button-select": (this.state.selectOption != -1 && this.state.selectOption == key)})}
          size={'default'}
          onClick={ this.changeTimeRange(item.type, item.number, key) } >{ item.text }</Button>)
      );
    }

    const hasStartInit = this.props.value && this.props.value.startDate;
    const hasEndInit = this.props.value && this.props.value.endDate;

    return (
      <div className="subDate">
        <DatePicker
          disabledDate={ disableDate ? this.disabledStartDate : null }
          value={ !!hasStartInit ? moment(this.props.value.startDate, DateFormat.getValueFromAlias('DAY')) : ( noInit ? '' : moment(new Date(), DateFormat.getValueFromAlias('DAY'))) }
          allowClear={ false }
          onChange={ this.onChange('startDate') }
        />
        <span> - </span>
        <DatePicker
          disabledDate={ disableDate ? this.disabledEndDate : null }
          style={{ marginRight: '20px'}}
          value={ !!hasEndInit ? moment(this.props.value.endDate, DateFormat.getValueFromAlias('DAY')) : ( noInit ? '' : moment(new Date(), DateFormat.getValueFromAlias('DAY'))) }
          allowClear={ false }
          onChange={ this.onChange('endDate') }
        />
        { optionButton }
      </div>
    );
  } 
  
}