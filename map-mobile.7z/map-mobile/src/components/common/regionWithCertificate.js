import React, { PropTypes } from 'react';
import { Select, Input, Icon, Tooltip, Row, Col, Modal, Button, Spin, message } from 'antd';
import _ from 'underscore';

import { transform } from 'common/utils';
import { getRegions } from 'biz/services/frame';

import './richRegion.less';

const Option = Select.Option;

async function getProvinceData() {
  let provinces = await getRegions();
  return { provinces };
}

async function getCityData(provinceId) {
  let cities = await getRegions(provinceId);
  return { cities };
}

export default class RichRegion extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      provinces: [],
      cities: [],
      provinceId: undefined,
      cityId: undefined,
    };
  }

  getStateFromProps(props) {
    let { value } = props;
    let { provinceId, cityId } = value;
    provinceId = provinceId ? ('' + provinceId) : undefined;
    cityId = cityId ? ('' + cityId) :  undefined;
    return { ...value, provinceId, cityId };
  }

  componentWillReceiveProps(nextProps) {
    let state = this.getStateFromProps(nextProps);
    this.setState({ ...state });
  }

  componentDidMount = () => {
    getProvinceData().then(result => {
      this.setState(
        {
          ...this.state,
          ...result,
        }
      )
    })
  }

  onProvinceChange = (provinceId) => {
    getCityData(provinceId).then(result => {
      const { cities } = result;
      this.setState(
        {
          ...this.state,
          ...result,
          provinceId,
          cityId: cities[0].id ? cities[0].id : ''
        }
      )
      //this.setCity();
    })
  }

  onCityChange = (cityId) => {
    this.setState(
      {
        ...this.state,
        cityId
      }
    )
  }

  setCity = () => {
    const { form } = this.props;
    form.setFieldsValue({
      cityId: this.state.initCityId ? this.state.initCityId : ''
    })
  }

  render() {
    const { provinceId, cityId, provinces, cities } = this.state;
    return (
      <div className="axg-rich-region">
        <Select value={provinceId} placeholder="请选择省份"
          className="axg-rich-region-select-item"
          style={{ width: 150 }}
          onChange={this.onProvinceChange}>
          { transform.selectOptions(provinces) }
        </Select>
        <Select value={cityId} placeholder="请选择城市"
          className="axg-rich-region-select-item"
          style={{ width: 150 }}
          onChange={this.onCityChange}>
          { transform.selectOptions(cities) }
        </Select>
      </div>
    );
  }
}

RichRegion.propTypes = {};
