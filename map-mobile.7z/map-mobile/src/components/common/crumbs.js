import React, { PropTypes } from 'react';
import { Breadcrumb, Icon } from 'antd';
import { Link } from 'dva/router';

import './crumbs.less';

function Crumbs({ crumbList }) {
  console.log(crumbList)
  const breadcrumbItems = crumbList.map((item, index) => {
    if (item.path) {
      return (<Breadcrumb.Item key={item.key}><Link to={item.path}>{ item.name }</Link></Breadcrumb.Item>);
    }
    return (<Breadcrumb.Item key={item.key}>{ item.name }</Breadcrumb.Item>);
  });

  return (
    <Breadcrumb separator={<span class="crumbs-separator"></span>} className="map-crumbs-wrapper">
      { breadcrumbItems }
    </Breadcrumb>
  );
}

Crumbs.propTypes = {
  crumbList: PropTypes.array.isRequired,
};

export default Crumbs;
