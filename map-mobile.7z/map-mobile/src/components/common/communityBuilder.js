import React, { PropTypes } from 'react';
import { Select, Input, Icon, Row, Col, Modal, Button, Spin, Tooltip, message, Cascader } from 'antd';
import _ from 'underscore';

import { transform, tools } from 'common/utils';
import { getRegionsAndBlocks, addCommunity } from 'biz/services/frame';

import './richRegion.less';

const Option = Select.Option;

async function getRegions() {
  let { data, globalError } = await getRegionsAndBlocks();

  if (data) {
    let { district, block } = data;

    let regions = Object.keys(district).map(
      (districtId) => {
        let blocksOfDistrict = block[districtId];
        blocksOfDistrict = Object.keys(blocksOfDistrict).map(
          (key) => {
            return { label: blocksOfDistrict[key].name, value: blocksOfDistrict[key].id };
          }
        );
        return {
          label: district[districtId].name,
          value: district[districtId].id,
          children: blocksOfDistrict
        };
    });
    return regions;
  }

  return [];
}

function formatCommunities(communities) {
  if (!communities) {
    return [];
  }
  return communities.map(({ communityId, name }) => ({ id: communityId, text: name }));
}

export default class CommunityBuilder extends React.Component {

  constructor(props) {
    super(props);
    this.state = { show: false, regions: []};
  }

  componentWillReceiveProps = (nextProps) => {
    if (nextProps.show !== this.props.show && nextProps.show === true) {
      this.setState({ show: true }, this.initMap);
    }
  }

  initMap = () => {
    let geoc = new BMap.Geocoder();
    let geolocation = new BMap.Geolocation();

    let map = new BMap.Map('axg-map');
    map.addControl(new BMap.NavigationControl());

    this.setState({ geoc, geolocation, map }, () => {
      // latitude = '22.554878';
      // longitude = '114.093151';
      let point = new BMap.Point(this.props.defaultLatitude, this.props.defaultLongitude);
      point && this.focusMapByPoint(point);
    });

    getRegions().then(regions => {
      this.setState({ regions });
    });
  }

  updateData = (data, callback) => {
    this.setState({ ...data }, callback);
  }

  focusMapByPoint = (point) => {
    let map = this.state.map;
    map.centerAndZoom(point, 21); // 初始化地图,设置中心点坐标和地图级别

    let pointMarker = new BMap.Marker(point);
    pointMarker.enableDragging()
    pointMarker.addEventListener('dragend', e => {//拖动标注结束
      var pointNew = e.point;
      this.updateData({ longitude: pointNew.lng, latitude: pointNew.lat });
    });

    map.addOverlay(pointMarker);
    if (this.state.pointMarker) {
      map.removeOverlay(this.state.pointMarker);
    }
    this.setState({ pointMarker });
  }

  parsePointByAddress = () => {
    let city = '深圳市';
    let address = this.state.address || '';
    let name = this.state.name || '';

    // 将地址解析结果显示在地图上,并调整地图视野
    this.state.geoc.getPoint(
      city + ' ' + name + ' ' + address,
      (point) => {
        this.focusMapByPoint(point);
        this.updateByPoint(point);
      },
      city
    );
  }

  // 根据获取到的地图point更新地址信息
  updateByPoint = (point) => {
    if (point) {
      this.state.geoc.getLocation(point, (rs) => {
        let state = {
          latitude: '' + point.lat,
          longitude: '' + point.lng,
        };
        this.updateData(state);
      });
    }
  }

  onRegionChange = (selectedRegion) => {
    this.updateData({ selectedRegion });
  }

  onCommunityChange = (e) => {
    this.updateData({ name: e.target.value }, this.parsePointByAddress);
  }

  buildCommunity = async (param) => {
    let { data, globalError } = await addCommunity(param);
    if (data) {
      message.success('申请创建完成，请等待审核!');
      this.props.onSuccess();
    }
    else {
      message.error(globalError);
    }
  }

  submitMap = () => {
    let { selectedRegion, address, latitude, longitude, name } = this.state;
    if (tools.isEmpty(name)) {
      message.error('请填写小区名！');
      return false;
    }
    else if (name.length > 30) {
      message.error('小区名不能超过30个字符！');
      return false;
    }

    let blockId;
    let districtId;
    if (selectedRegion.length < 2) {
      message.error('请选择区域/版块');
      return false;
    }
    else {
      districtId = selectedRegion[0];
      blockId = selectedRegion[1];
    }

    if (tools.isEmpty(address)) {
      message.error('请填写详细地址！');
      return false;
    }
    else if (address.length > 100) {
      message.error('地址不能超过100个字符！');
      return false;
    }

    if (!longitude || !latitude) {
      message.error('坐标获取失败，请点击刷新定位点！');
      return false;
    }

    this.buildCommunity({ blockId, districtId, address, latitude, longitude, name});
  }

  onAddressChange = (e) => {
    let address = e.target.value;
    this.updateData({ address }, this.parsePointByAddress);
  }

  search = () => {
    this.parsePointByAddress(point => {
      if (!point) {
        message.error('未搜到输入地址的坐标，请手动拖拽坐标点定位，或者重新输入有效地址！');
      }
    });
  }

  render() {
    let modalFormItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 18 },
    };

    let { name, communities, mapLoading, regions, selectedRegion, address } = this.state;

    let { show } = this.props;
    let { readonly } = this.props;

    return (
      <div className="axg-rich-region">
        <Modal title="小区地址" maskClosable={ false } className="axg-rich-region-modal" width={700} visible={show} onOk={ this.submitMap } onCancel={ this.props.onClose }>
          <Spin tip="地图卖力加载中..." spinning={ false }/>
          <Row className="axg-rich-region-form-item">
            <Col className="ant-form-item-label"  { ...modalFormItemLayout.labelCol }>
              <label className="ant-form-item-required" title="小区名">小区名</label>
            </Col>
            <Col className="ant-form-item-control-wrapper" { ...modalFormItemLayout.wrapperCol }>
              <div className="ant-form-item-control">
                <Input value={name} placeholder="输入小区名"
                  className="axg-rich-region-input-item"
                  onChange={this.onCommunityChange}/>
              </div>
            </Col>
          </Row>
          <Row className="axg-rich-region-form-item">
            <Col className="ant-form-item-label"  { ...modalFormItemLayout.labelCol }>
              <label className="ant-form-item-required" title="地址">区域/版块</label>
            </Col>
            <Col className="ant-form-item-control-wrapper" { ...modalFormItemLayout.wrapperCol }>
              <div className="ant-form-item-control">
                <Cascader className="axg-rich-region-cascader-item" allowClear={false} options={regions} placeholder="区域版块" onChange={this.onRegionChange} value={selectedRegion}/>
              </div>
            </Col>
          </Row>
          <Row className="axg-rich-region-form-item">
            <Col className="ant-form-item-label"  { ...modalFormItemLayout.labelCol }>
              <label className="ant-form-item-required" title="地址">地址</label>
            </Col>
            <Col className="ant-form-item-control-wrapper" { ...modalFormItemLayout.wrapperCol }>
              <div className="ant-form-item-control">
                <Input value={address} placeholder="输入详细地址"
                  className="axg-rich-region-input-item"
                  onChange={this.onAddressChange}/>
                  <Button className="axg-rich-region-search-button" type="primary" onClick={this.search}>刷新定位点</Button>
                  <Tooltip placement="top" title="定位不准确？挪动图钉纠正下~">
                  <Icon type="info-circle" />
                  </Tooltip>
              </div>
            </Col>
          </Row>
          <Row className="axg-rich-region-form-item">
            <Col className="ant-form-item-label"  { ...modalFormItemLayout.labelCol }>
            </Col>
            <Col className="ant-form-item-control-wrapper" { ...modalFormItemLayout.wrapperCol }>
              <div id="axg-map" style={{ height: 300 }}></div>
            </Col>
          </Row>
        </Modal>
      </div>
    );
  }
}

CommunityBuilder.propTypes = {};
