import { Menu, Icon } from 'antd';
import React, { PropTypes } from 'react';
import ReactDOM from 'react-dom'
import { Link } from 'dva/router';

import permission from 'common/permission';

import _ from 'underscore';

import './resourceMenu.less';

const SubMenu = Menu.SubMenu;

function buildMenuItem({ key, name, path, total, id }) {
  return (
    <Menu.Item key={ key || id }>
      <Link to={ path }>
        <span className="axg-ellipsis-nav-text" title={name}>{ name }</span>
        { (total || total === 0) && <span className="axg-nav-text">({total})</span> }
      </Link>
    </Menu.Item>
  );
}

function formatResource({ centralized, federal }) {
  let viewData = {
      centralMenus: [],
      decentralMenus: []
  };

  if (centralized && centralized.length) {
    viewData.centralMenus = centralized.map(item => buildMenuItem(item));
  }

  if (federal && federal.length) {
    viewData.decentralMenus = federal.map(item => buildMenuItem(item));
  }

  return viewData;
}

// 参数：
// {
//   resource: {
//     centralized: [
//       { key: 'xxx', name: 'xxx', path: 'xxx' }
//     ],
//     federal: [
//       { key: 'xxx', name: 'xxx', path: 'xxx' }
//     ]
//   }
// }


function getScrollTop() {
  return window.scrollTop;
}

class ResourceMenu extends React.Component {

  state = {
    openKeys: [],
    current: []
  }

  componentWillMount() {
    this.componentWillReceiveProps(this.props);
  }


  fireOpenChange() {
    let openKeys = this.state.openKeys;
    if (this.props.onKeysOpen) {
      this.props.onKeysOpen(openKeys);
    }
  }

  componentWillReceiveProps(nextProps) {

    const current = (nextProps.resource && nextProps.resource.current) || [];
    const viewData = formatResource(nextProps.resource || {
      centralized: [], federal: [],
    });
    const openKeys = nextProps.noRender
      ? (this.state.openKeys && this.state.openKeys.lenght > 0 ?  this.state.openKeys : (this.props.openKeys || []))
      : (nextProps.resource && nextProps.resource.openKeys) || [];

    this.setState({ current, viewData, openKeys });
  }

  onOpenChange = (openKeys) => {
    const latestOpenKey = _.without(openKeys, this.state.openKeys[0]);
    this.setState({ openKeys: latestOpenKey }, this.fireOpenChange);
  }

  render() {

    return (
      <Menu
        openKeys={this.state.openKeys}
        selectedKeys={this.state.current}
        mode="inline"
        onOpenChange={this.onOpenChange}
        className="resource-menu"
        inlineIndent={15}
        onSelect={this.props.onSelect}
      >
        <SubMenu key="central" ref={(m) => { this.central = m; }}
          title={<span>
            <span>集中式</span>
            {
              this.props.hasAction &&
              permission.isAllow(['AXG_RESOURCE_ADD']) &&
              <Link to='/resources/central/buildings/create' className="axg-menu-action-link">+添加楼栋</Link>
            }
            </span>}>
          { this.state.viewData ? this.state.viewData.centralMenus : ''}
        </SubMenu>
        <SubMenu key="decentral" ref="decentral"
          title={<span>
            <span>分散式</span>
            {
              this.props.hasAction &&
              permission.isAllow(['AXG_RESOURCE_ADD']) &&
              <Link to='/resources/federal/rooms/edit' className="axg-menu-action-link">+添加房源</Link>
            }
            </span>}>
          { this.state.viewData ? this.state.viewData.decentralMenus : ''}
        </SubMenu>
      </Menu>
    );
  }
}

ResourceMenu.propTypes = {};

export default ResourceMenu;
