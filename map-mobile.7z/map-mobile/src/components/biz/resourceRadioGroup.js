/*
* @author:  lisijin025
* @createTime:  2017-06-16, 11:18:15 GMT+0800
* @description:  房源选择
*/

import React, { PureComponent } from 'react';
import { Radio } from 'antd';
import _ from 'underscore';
import './resourceRadioGroup.less';

const RadioGroup = Radio.Group;
const houseTypes = {
  centralized: 1,
  federal: 2,
};

export default class ResourceRadioGroup extends PureComponent {

  componentWillMount() {

    let list = this.props.resourceItemList;
    let value = this.props.selectedResourceId;
    let houseType;
    let text = '';

    function getId(data) {
      var child;
      _.every(data, (item, key) => {
        child = _.find(
          item.list,
          (one) => {
            return one.length;
          }
        );
        text = item.name || '';
        return child ? false : true;
      });
      return child ? child[0] : {};
    }

    if (!value) {
      if (list.centralized && list.centralized.length > 0) {
        value = getId(list.centralized);
        houseType = houseTypes['centralized'];
      }
      else if (list.federal && list.federal.length > 0) {
        value = getId(list.federal);
        houseType = houseTypes['federal'];
      }
      else {
        return false;
      }
      this.props.onChange(value.id, text + value.text, houseType);
    }
  }

  onChange = (e) => {
    this.props.onChange(e.target.value, e.target.text, e.target.houseType);
  }

  render() {

    const list = this.props.resourceItemList;
    const value = this.props.selectedResourceId;
    
    function genFloor(data, key, houseType) {

      const html = _.map(
        data.list,
        (item, key) => {
          const children = _.map(
            item,
            one => (<Radio key={one.id} value={one.id} text={data.name + one.text} houseType={houseType} >{one.text}</Radio>)
          );
          return (
            <div key={key} className="resource-floor">
              <div className="resource-floor-title" className="resource-title" >第{key}层</div>
              <div className="resource-floor-group">{children}</div>
            </div>
          );
        }
      );
      return (
        <div key={data.id} className="resource-radio-group resource-radio-group-level">{html}</div>
      );
    }

    function genOne(data, key, houseType) {
      const html = _.map(
        data.list,
        (item, key) => {
          return (
            <Radio key={item.id.replace('_', '')} value={item.id} text={data.name + item.text} houseType={houseType}>{item.text}</Radio>
          );
        }
      );
      return (
        <div key={data.id} className="resource-radio-group resource-radio-group-no-level">{html}</div>
      ); 
    }

    function genItem(item, key, houseType) {
      const html = item.isLevel ? genFloor(item, key, houseType) : genOne(item, key, houseType);
      return (
        <div key={item.id} id={"house-name-" + item.id}>
          <div className="resource-name">{item.name}</div>
          <div className="resource-item" >{html}</div>
        </div>
      );
    }

    const centralizedRadioGroup = _.map(
      list.centralized || [],
      (item, key) => genItem(item, key, houseTypes['centralized'])
    );

    const federalRadioGroup = _.map(
      list.federal || [],
      (item, key) => genItem(item, key, houseTypes['federal'])
    );

    return (
      <RadioGroup className="resource-radio-group-wrapper" onChange={this.onChange} value={value}>
        { centralizedRadioGroup }
        { federalRadioGroup }
      </RadioGroup>
    );
  }
}
