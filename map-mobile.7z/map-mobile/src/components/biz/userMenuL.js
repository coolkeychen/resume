/*
* @author:  libenzhi957
* @createTime:  2017-06-11, 11:12:30 GMT+0800
* @description:  UserMenu
*/
import { Menu, Icon } from 'antd';
import React, { PropTypes } from 'react';
import { Link } from 'dva/router';
import _ from 'underscore';

import '../common/sidebar.less';

class UserMenu extends React.Component {

  render() {
    const { current, userMenuSource, location } = this.props;
    
    const menuItem = [];
    userMenuSource.forEach((item,index) => {
      if(item.status&&item.status===1){
        menuItem.push(
          <Menu.Item key={item.key}>
            <Link to={item.path}>
            <span className="nav-text">
              {item.name}
              <em className="status">未认证</em>
              </span>
            </Link>
          </Menu.Item>
        );
      }else if(item.status&&item.status===3){
        menuItem.push(
          <Menu.Item key={item.key}>
            <Link to={item.path}>
            <span className="nav-text">
              {item.name}
              <em className="status ing">认证中</em>
              </span>
            </Link>
          </Menu.Item>
        );
      }else if(item.status&&item.status===4){
        menuItem.push(
          <Menu.Item key={item.key}>
            <Link to={item.path}>
            <span className="nav-text">
              {item.name}
              <em className="status">认证失败</em>
              </span>
            </Link>
          </Menu.Item>
        );
      }else {
        menuItem.push(
          <Menu.Item key={item.key}>
            <Link to={item.path}>
            <span className="nav-text">
              {item.name}
              </span>
            </Link>
          </Menu.Item>
        );
      }
    });
    
    function getKeyFromPath() {
      return _.find(
        userMenuSource,
        item => location.pathname.indexOf(item.key) >= 0
      ) || {};
    }

    return (
      <Menu
        selectedKeys={[getKeyFromPath()['key']]}
        className="sidebar user-menu"
      >
        { menuItem }
      </Menu>
    );
  }
}

UserMenu.propTypes = {};

export default UserMenu;
