import { Menu, Icon } from 'antd';
import React, { PropTypes } from 'react';
import { Link } from 'dva/router';

import '../common/sidebar.less';

const SubMenu = Menu.SubMenu;

const FORMAT_RESOURCE = Symbol('formatResource');
const BUILD_MENU_ITEM = Symbol('buildMenuItem');

class tenantMenu extends React.Component {

  state = {
    current: "wait",
  }
  handleClick = (e) => {
    this.setState({
      current: e.key,
    });
  }

  render() {
    return (
      <Menu
        onClick={this.handleClick}
        defaultSelectedKeys={['wait']}
        className="sidebar"
      >
        <Menu.Item key="wait">
          <Link to="/tenant/list?type=1">
            <span className="nav-text">待分配</span>
          </Link>
        </Menu.Item>
        <Menu.Item key="follow">
          <Link to="/tenant/list?type=2">
            <span className="nav-text">跟进中</span>
          </Link>
        </Menu.Item>
        <Menu.Item key="finish">
          <Link to="/tenant/list?type=3">
            <span className="nav-text">已完成</span>
          </Link>
        </Menu.Item>
      </Menu>
    );
  }
}

tenantMenu.propTypes = {};

export default tenantMenu;
