import React, { PropTypes } from 'react';
import ReactDOM from 'react-dom';

import Map from 'ol/map';
import View from 'ol/view';
import VectorLayer from 'ol/layer/vector';
import TileLayer from 'ol/layer/tile';
import OSM from 'ol/source/osm';
import Vector from 'ol/source/vector';
import XYZ from 'ol/source/xyz';
import Interaction from 'ol/interaction';
import Stroke from 'ol/style/stroke';
import Circle from 'ol/style/circle';
import Draw from 'ol/interaction/draw';
import Proj from 'ol/proj';
import Overlay from 'ol/overlay';
import Select from 'ol/interaction/select';
import DragBox from 'ol/interaction/dragbox';
import Feature from 'ol/feature';
import Geojson from 'ol/format/geojson';

import Control from 'ol/control';
import Style from 'ol/style/style';
import Fill from 'ol/style/fill';
import Text from 'ol/style/text';
import Polygon from 'ol/geom/polygon';
import Point from 'ol/geom/point';
import olIcon from 'ol/style/icon';
import PluggableMap from 'ol/pluggablemap';
import LineString from 'ol/geom/linestring';
import ScaleLine from 'ol/control/scaleline';

import DragRotateAndZoom from 'ol/interaction/dragrotateandzoom';
import Geolocation from 'ol/geolocation';

import Condition from 'ol/events/condition';
import Cluster from 'ol/source/cluster';

import { Icon } from 'antd'
import 'biz/../../node_modules/ol/ol.css';
import './selectMapLanlat.less'




const ol = {
	Map, View, VectorLayer, TileLayer, OSM, Vector, Interaction, Stroke, Circle, Cluster,
            Draw, Proj, Overlay, Select, DragBox, Feature, Geojson, Control, Style, Fill,
	Text, Polygon, Point, olIcon, Condition, PluggableMap, DragRotateAndZoom, Geolocation, XYZ, LineString, ScaleLine };

class SelectMapLanlat extends React.Component {   
	map = null;
    constructor() {
		super();
		Object.keys(ol).forEach( item => { this[item] = ol[item] })
	}
	
    
    componentDidMount = () => {
    	const layerTile = new TileLayer({
    		source: new OSM({
    			wrapX: false
    		})
		})

		
		let { layers, defaultControls, extendControls, view, target, drawAreaParam, overlayCoordinates, popup, vectorSource } = this.props;

		
	    layers = layers || [];
    	defaultControls = defaultControls || {};
    	extendControls = extendControls || [];
		view = view || {};
		vectorSource = vectorSource || null;

    	this.map = new Map({
    	   target: target,
		   layers: [ ...layers ],
    	   controls: new Control.defaults({ ...defaultControls}).extend(extendControls || []),
    	   view: view
		})
		
        drawAreaParam && this.interactionDrawArea(drawAreaParam);
		overlayCoordinates && overlayCoordinates.length && this.addOverlays(overlayCoordinates);
		vectorSource && this.addFeature(vectorSource);
	}

	
	addFeature = (vectorSourceArg) => {
		let map = this.map;

		let vectorSource = vectorSourceArg.vectorSource;

		let Svg = '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30px" height="30px" viewBox="0 0 30 30" enable-background="new 0 0 30 30" xml:space="preserve">' +
			'<path fill="#156BB1" d="M22.906,10.438c0,4.367-6.281,14.312-7.906,17.031c-1.719-2.75-7.906-12.665-7.906-17.031S10.634,2.531,15,2.531S22.906,6.071,22.906,10.438z"/>' +
			'<circle fill="#FFFFFF" cx="15" cy="10.677" r="3.291"/></svg>';
		let img = new Image();
		img.src = 'data:image/svg+xml,' + escape(Svg);

		let styles = {
			'Point': new Style({
				image: new olIcon({
					img: img,
					imgSize: [26, 26],
				})
			}),
		}

		let styleFunction = function (feature) {
			return styles[feature.getGeometry().getType()];
		};

		vectorSource.addFeature(new Feature());

		var vectorLayer = new VectorLayer({
			source: vectorSource,
			style: styleFunction
		});

		map.addLayer(vectorLayer);
	}


    interactionDrawArea = ({shape, selectCoordinate}) => {
    	let map = this.map;
    	let { isSource } = this.props.drawAreaParam
    	let vectorLayer = new VectorLayer({
    		source: new Vector(),
    	});
    	let draw = new Draw({
    		type: shape || 'Point',
            source: isSource && vectorLayer.getSource() || isSource,
    	})
        
    	map.addLayer(vectorLayer);
    	map.addInteraction(draw);
    	
        draw.addEventListener('drawend', function(event) {
        	selectCoordinate && selectCoordinate(event.feature.getGeometry().getCoordinates());
        })
    }

    getSlotLayers = (index) => {
    	let map = this.map;
		let layers = map.getLayers().array_;
		console.log(layers);
    	return layers[index];
	}
		
    addOverlays = ( overlayCoordinates ) => {
		let map = this.map;
    	overlayCoordinates.forEach((item, index) => {
    		let element = document.createElement('div');
    		// ReactDOM.render(item.element, element);
    		element.className = item.className;
    		document.body.appendChild(element);
            let overlay = new Overlay({
            	element
            })
            
            overlay.setPosition(item.coordinate);
            map.addOverlay(overlay);
    	})
	}
	
	back2loc = () => {
		this.props.callback2Location();
	}

	render() {
		return <div className="outdoor-container">
			<div id={this.props.target}></div>
			<div className="back-2-location" id="back-2-location" onClick={ this.back2loc }></div>
		</div>
	}


}

export default SelectMapLanlat;
