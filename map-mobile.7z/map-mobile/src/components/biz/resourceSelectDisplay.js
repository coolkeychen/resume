/*
* @author:  lisijin025
* @createTime:  2017-06-17, 15:28:53 GMT+0800
* @description:  房源选择 Checkbox Group
*/

// TODO 还没写完。
import React, { Component } from 'react';
import _ from 'underscore';
import './resourceSelectDisplay.less';


class DisplayItem extends Component {

  render() {

    const { value, data, key } = this.props;
    const html = value.map(
      (item, key) => {
        return (
          <span className="resource-display-item-list-one">{item.text}</span>
        );
      }
    );

    return (
      <div className="resource-display-item">
        <div className="resource-display-item-name">{data.name}</div>
        <div className="resource-display-item-list" >{html}</div>
      </div>
    );
  }

}

export default class ResourceSelectDisplay extends Component {

  genDisplayItems = (data, value) => {
    return data.reduce(
      (target, item) => {
        const checkedValues = item.list.filter(({ id }) => value.includes(id));
        if (checkedValues.length > 0) {
          target.push(<DisplayItem key={item.id} data={item} value={checkedValues}/>);
        }

        return target;
      },
      []
    );
  }

  render() {

    let list = this.props.resourceItemList;
    let value = this.props.selectedResourceId;

    let centralizedCheckboxGroup = this.genDisplayItems(list.centralized, value);
    let federalCheckboxGroup = this.genDisplayItems(list.federal, value);

    return (
      <div className="resource-display-group-wrapper">
        { centralizedCheckboxGroup }
        { federalCheckboxGroup }
      </div>
    );
  }
}
