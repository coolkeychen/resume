import React, { PropTypes } from 'react';

import Map from 'ol/map';
import View from 'ol/view';
import View from 'ol/view';


import 'biz/../../node_modules/ol/ol.css';





export default country;