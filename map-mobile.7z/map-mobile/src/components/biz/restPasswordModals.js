/**
 * Created by Shengchenling711 on 2017/6/24.
 */
import React from 'react'
import { connect } from 'dva'
import { Button, Row, Col, Form, Input, Modal, Steps } from 'antd';

const FormItem = Form.Item;
const Step = Steps.Step;

class RestPasswordModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      inputType1: 'text',
      inputType2: 'text',
      captchaImg: '/web/account/imgcode',
      captchaImg_temp: '/web/account/imgcode',
      count: 60,
      timerTitle: '获取验证码',
      form1: {}
    }
  }

  passwordInti = (index) => {
    if (index === 1) {
      this.setState({
        inputType1: 'password',
      })
    } else if (index === 2) {
      this.setState({
        inputType2: 'password',
      })
    }
  }

  handleConfirmPassword = (rule, value, callback) => {
    const { getFieldValue } = this.props.form;
    if (value && value !== getFieldValue('form2.newPassword')) {
      callback('两次输入的不一致！')
    }
    callback()
  };

  handleSubmit = () => {
    const { validateFieldsAndScroll } = this.props.form;
    validateFieldsAndScroll((errors, values) => {
      if (!errors) {
        const { form2 } = values;
        this.props.resetPassword(form2);
      }
    })
  }

  verifyPassword = (rule, value, callback) => {
    if (value === '') {
      callback('请输入密码');
    }
    if (value && (/[\u4E00-\u9FA5\uF900-\uFA2D]/.test(value) || /[\uFF00-\uFFEF]/.test(value) || !/^(?![A-Za-z]+$)(?!\d+$)(?![!"#$%&'()*+,-.\/:;<=>?@\[\]^_`{|}~]+$)\S{6,18}$/.test(value))) {
      callback('最短6位且包含6位字母和数字');
    } else {
      callback();
    }
  }

  render = () => {
    const { getFieldDecorator } = this.props.form;
    const formModalLayout = {
      labelCol: {
        xs: { span: 6 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 18 },
        sm: { span: 18 },
      },
    };

    return (
      <Modal maskClosable={ false }
             title="重置密码登录"
             visible={this.props.visible}
             wrapClassName="account-modal"
             onOk={this.handleSubmit}
             onCancel={this.props.closeResetPasswordStep2}
             key={this.props.modalKey}
      >
        <Steps size="small" current={1}>
          <Step title="身份认证" />
          <Step title="重置密码" />
        </Steps>
        <Form className="mt-15">
          <Row>
            <FormItem
              {...formModalLayout}
              label="新密码"
            >
              {getFieldDecorator('form2.newPassword', {
                rules: [{
                  validator: this.verifyPassword,
                }],
              })(<Input size="large" type={this.state.inputType1} onFocus={this.passwordInti.bind(this, 1)} />)}
            </FormItem>
          </Row>
          <Row>
            <FormItem
              {...formModalLayout}
              label="重复新密码"
            >
              {getFieldDecorator('form2.password', {
                rules: [{
                  message: '请再次输入以确认新密码',
                }, {
                  validator: this.handleConfirmPassword
                }],
              })(<Input size="large" type={this.state.inputType2} onFocus={this.passwordInti.bind(this, 2)} />)}
            </FormItem>
          </Row>
        </Form>
      </Modal>
    )
  }
}

export default Form.create()(RestPasswordModal);
