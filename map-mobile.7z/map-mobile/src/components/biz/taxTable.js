/*
* @author:  lisijin025
* @createTime:  2017-06-16, 18:11:42 GMT+0800
* @description:  杂费Form Table
*/

import React from 'react';
import EditableCell from 'components/common/editableCell';
import { EXPENSES } from 'common/global/enum';
import { Table, Button, Icon } from 'antd';
import { transform } from 'common/utils';
import dynamicConst from 'common/dynamicConst';
import { selectOptions } from 'common/utils/transform';
import _ from 'underscore';
import classnames from 'classnames';
import { rowClassName } from 'common/utils/tools';

export default class TaxTable extends React.Component {

  onCellChange = (index, key) => {
    return (val) => {
      const value = [...this.props.value];
      value[index][key] = val;
      this.onChange(value);
    };
  }

  onMoneyChange = (index, key) => {
    return (val) => {
      const value = [...this.props.value];
      value[index][key] = val * 100;
      this.onChange(value);
    };
  }

  onChange = (value) => {
    this.props.onChange(value);
  }

  handleAdd = () => {
    let { value } = this.props;
    const datasource = _.pairs(this.props.datasource || dynamicConst.getItem('expenseType')); // extrasExpense
    const newLine = {
      expenseType: datasource[0][0],
      expense: 0,
      transactionType: 1,
      key: +new Date() + value.length
    };
    value.push(newLine);
    this.onChange(value);
  }

  onDelete = (key) => {
    let { value } = this.props;
    value = value.filter(item => item.key !== key);
    this.onChange(value);
  }

  moneyBlur = (index, key) => {
    return (e) => {
      const value = [...this.props.value];
      value[index][key] = e.target.value * 100;
      this.onChange(value);
    };
  }

  render() {

    const transactionTypeColumn = [{
      title: '类别',
      dataIndex: 'transactionType',
      width: 80,
      render: (text, record, index) => (
        <EditableCell
          style={{width: '128px'}}
          cellType = "Select"
          datasource = { dynamicConst.getItem('transactionType') }
          onChange = { this.onCellChange(index, 'transactionType') }
          value = { record.transactionType }
        />
      ),
    }];

    const secondColumns = [
      
      {
        title: '类别',
        dataIndex: 'expenseType',
        width: 150,
        render: (text, record, index) => (
          <EditableCell
            style={{width: '128px'}}
            cellType = "Select"
            datasource = { this.props.datasource || dynamicConst.getItem('expenseType') }
            onChange = { this.onCellChange(index, 'expenseType') }
            value = { record.expenseType }
          />
        ),
      },
      {
        title: '金额(元)',
        dataIndex: 'expense',
        width: 200,
        render: (text, record, index) => (
          <span>
          <EditableCell
            cellType="Money"
            style={{width: '128px'}}
            min={0}
            max={99999999}
            value = { transform.formateMoney(text) }
            otherProps = {{
              onBlur: this.moneyBlur(index, 'expense')
            }}
          />
          { this.props.unit || '' }
          </span>
        ),
      },
      {
        title: '操作',
        width: 80,
        className: this.props.cannotDelete ? 'uns axg-table-action' : 'axg-table-action',
        key: 'action',
        render: (text, record, index) => {
          if (this.props.cannotDelete) {
            return null;
          }
          return (<Button
            className="axg-button-like-link"
            icon="1"
            type="primary" onClick={
                (e) => {
                  this.onDelete(record.key);
                }
              }
          >删除</Button>);
        }
      },
    ];

    const columns = this.props.hasType ? transactionTypeColumn.concat(secondColumns) : secondColumns;

    return (
      <div style={{width: this.props.width || 450}}>
        { this.props.cannotAdd ? ''
        : <Button
          type="primary" className="axg-button-like-link" onClick={ this.handleAdd }>
          <Icon type="plus-square-o" style={{fontSize: 14}}/>
          添加
        </Button>
        }
        <div style={{ marginTop: 15 }} className={ classnames({ uns: (!this.props.value || this.props.value.length == 0 )}) } >
        <Table
          rowClassName={rowClassName}
          bordered={true}
          key={ +new Date() }
          columns = { columns }
          dataSource = { this.props.value }
          pagination = { false }
          rowKey = "key"
        />
        </div>
      </div>
    );
  }
}
