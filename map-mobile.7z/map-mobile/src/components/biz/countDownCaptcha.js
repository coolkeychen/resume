/**
 * Created by Shengchenling711 on 2017/7/1.
 */
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'dva';

class CountDownCaptcha extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      count: this.props.count || 120,
      timerTitle: this.props.timerTitle || '获取验证码',
      counting: false,
      selfEnable: false,
      clickEnable: true,
      form1: {},
    };
  }

  componentWillUnmount() {
    clearInterval(this.interval)
  }

  componentWillReceiveProps(nextProps) {
    const { showCount } = nextProps;
    if (showCount && !(this.state.counting)) {
      this._countDownAction();
    }
  }

  _countDownAction = () => {
    const codeTime = this.state.count;
    this.setState({
      counting: true,
    })
    this.interval = setInterval(() => {
      const timer = this.state.count - 1;
      if (timer === 0) {
        this.props.resetCount();
        this.interval && clearInterval(this.interval);
        this.setState({
          count: codeTime,
          timerTitle: '获取验证码',
          counting: false,
          selfEnable: false,
        })
      } else {
        this.setState({
          count: timer,
          counting: true,
          timerTitle: `重新获取(${timer}s)`,
        })
      }
    }, 1000)
  }

  render = () => {
    const { counting } = this.state;
    const { showCount } = this.props; // true：需要显示倒计时，false:不现实倒计时
    let dom;
    // 判断是否正在倒计时
    if (!counting) {
      dom = <span className="captcha-code" onClick={this.props.onClick}>获取验证码</span>
    } else {
      dom = <span className="captcha-code disable">重新获取({this.state.count})</span>
    }

    return (
      <span>
      { dom }
      </span>
    )
  }
}

export default CountDownCaptcha;
