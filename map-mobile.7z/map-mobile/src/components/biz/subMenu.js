/*
* @author:  libenzhi957
* @createTime:  2017-06-11, 11:12:30 GMT+0800
* @description:  SubMenu，二级导航
*/
import { Menu, Icon } from 'antd';
import React, { PropTypes } from 'react';
import { Link } from 'dva/router';
import _ from 'underscore';

import '../common/sidebar.less';

class SubMenu extends React.Component {

  render() {
    const { current, menuSource, location } = this.props;
    const menuItem = menuSource.reduce((menuItem, item) => {
      let extraDom = item.extraStatus
         ? <span className="nav-text">{item.name}<em className="status-tag">{item.extraStatusText}</em></span>
         : <span className="nav-text">{item.name}</span>

      menuItem.push(
        <Menu.Item key={item.key}>
          <Link to={item.path}>
          {extraDom}
          </Link>
        </Menu.Item>
      );
      return menuItem;
    }, []);

    function getKeyFromPath() {
      return _.find(
        menuSource,
        item => location.pathname.indexOf(item.key) >= 0
      ) || {};
    }

    return (
      <Menu
        selectedKeys={[getKeyFromPath()['key']]}
        className="sidebar"
      >
        { menuItem }
      </Menu>
    );
  }
}

SubMenu.propTypes = {};

export default SubMenu;
