/*
* @author:  lisijin025
* @createTime:  2017-06-15, 10:13:29 GMT+0800
* @description:  房源选择
*/

import './resourceSelect.less';

import React from 'react';
import { Table, Row, Col, Radio } from 'antd';
import ResourceMenu from 'components/biz/ResourceMenu';
import ResourceRadioGroup from 'components/biz/resourceRadioGroup';
import ResourceCheckboxGroup from 'components/biz/resourceCheckboxGroup';
import ResourceSelectDisplay from 'components/biz/resourceSelectDisplay';

const RadioGroup = Radio.Group;


function getHeightByWindow() {
  return window.innerHeight - 80;
}

export default class ResourceSelect extends React.Component {

  onSelect = (e) => {
    const houseId = e.key;
    if (houseId) {
      const dom = document.getElementById('house-name-' + houseId);
      const scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
      if (dom) {
        dom.scrollIntoView(true);
        document.body.scrollTop = scrollTop;
        document.documentElement.scrollTop = scrollTop;
      }
    }
  }


  state = {
    windowHeight: getHeightByWindow()
  }

  componentDidMount = () => {
    window.addEventListener('resize', this.handleResize);
    // window.addEventListener('scroll', this.handleScroll);
  }

  componentWillUnmount = () => {
    window.removeEventListener('resize', this.handleResize);
    // window.removeEventListener('scroll', this.handleScroll);
  }

  handleResize = (e) => {
    this.setState({ windowHeight: getHeightByWindow() });
  }

  handleScroll = (e) => {
    this.setState({ top: getScrollTop() });
  }

  render() {
    let { windowHeight } = this.state;
    let { outterScroll, gapHeight } = this.props;
    let themeClassName = outterScroll ? 'resource-select resource-select-outter-scroll' : 'resource-select resource-select-inner-scroll';
    let realHeightStyle = outterScroll ? { height: windowHeight - gapHeight } : {};

    let selectDOM = <Row className={themeClassName}>
      <Col className="resource-menu" span={5} sm={5} md={5} lg={5} xl={5} style={realHeightStyle}>
        <ResourceMenu openKeys={['central']} resource={this.props.resource} onSelect={this.onSelect} noRender={true} 
        />
      </Col>
      <Col xs={2} sm={2} md={2} lg={1} xl={1} style={realHeightStyle}></Col>
      <Col className="resource-content" xs={17} sm={17} md={17} lg={18} xl={18} style={realHeightStyle}>
        {
          this.props.isCheckbox ?
            <ResourceCheckboxGroup
              { ...this.props }
              selectedResourceId={this.props.selectedResourceId}
            />
          :
            <ResourceRadioGroup
              { ...this.props }
              selectedResourceId={this.props.selectedResourceId}
            />
        }
      </Col>
    </Row>;

    let displayDOM = <Row className={themeClassName}>
      <Col className="resource-content" span={24} style={realHeightStyle}>
        <ResourceSelectDisplay { ...this.props } selectedResourceId={this.props.selectedResourceId}  />
      </Col></Row>
      
    let element = this.props.readonly ? displayDOM : selectDOM;
    return (element);
  }
}
