import React, { PropTypes } from 'react';
import { Modal } from 'antd';

const confirm = Modal.confirm;

class AuthPage extends React.Component {

  componentWillMount = () => {
    this.props.dispatch({
      type: `${this.module}/getData`,
    });
  }

  onDelete = (title, content) => {
    return () => {
      confirm({
        title: `确认要删除${title}么?`,
        content,
        onOk: () => {
          this.props.dispatch({
            type: `${this.module}/delete`,
          });
        },
        onCancel() {},
      });
    }
  }

  render = () => {
    return (<div></div>);
  }
}

export default AuthPage;
