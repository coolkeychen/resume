/*
* @author:  lisijin025
* @createTime:  2017-06-17, 15:28:53 GMT+0800
* @description:  房源选择 Checkbox Group
*/

// TODO 还没写完。
import React, { Component } from 'react';
import { Checkbox } from 'antd';
import _ from 'underscore';
import './resourceCheckboxGroup.less';

const CheckboxGroup = Checkbox.Group;

class CheckboxItem extends Component {

  state = {
    isCheckAll: false,
    isCheckPartial: false,
    checkList: {},
    isCheckList: {},
    isCheckPartialList: {},
  };

  componentWillMount() {
    this.componentWillReceiveProps(this.props);
  }

  componentWillReceiveProps(nextProps) {
    var values = nextProps.value;
    var checkList = this.getCheckList();
    var isCheckList = {};
    var isCheckPartialList = {};
    var isCheckAll = true;
    var isCheckPartial = false;
    _.each(
      checkList,
      (item, key) => {

        var len = _.intersection(item, values).length;
        if( len ){
          isCheckPartialList[key] = true;
          isCheckPartial = true;
        }
        if ( len && len === item.length) {
          isCheckList[key] = true;
          //isCheckAll = true;
          // 分散
          if (key == 0) {
            isCheckAll = true;
          }
        }
        else {
          isCheckList[key] = false;
          isCheckAll = false;
        }
      }
    );

    this.setState({
      isCheckAll: isCheckAll,
      isCheckPartial: isCheckPartial,
      checkList: checkList,
      isCheckList: isCheckList,
      isCheckPartialList: isCheckPartialList,
    });
  }

  getCheckList = () => {
    let list = {};
    if (this.props.data.isLevel) {
      _.each(
        this.props.data.list,
        (item, key) => {
          list[key] = _.map(item, one => one.id);
        }
      );
    }
    else {
      list[0] = _.map(
        this.props.data.list,
        item => item.id
      );
    }

    return list;
  }

  monitor = (newValue) => {
    this.props.onChange(newValue);
  }

  allCheck = (e) => {
    const checked = e.target.checked;
    let values = this.props.value || [];
    let floorValue = this.state.checkList;
    let newValue = values;

    _.each(
      this.state.checkList,
      item => {
        if (checked) {
          newValue = _.union(newValue, item);
        }
        else {
          newValue = _.difference(newValue, item);
        }
      }
    );

    this.monitor(newValue);

  }

  changeFloor = (floor) => {
    var me = this;
    return function (e) {
      const checked = e.target.checked;
      let values = me.props.value;
      let floorValue = me.state.checkList[floor];
      let newValue = [];
      if (checked) {
        newValue = _.union(values, floorValue);
      }
      else {
        newValue = _.difference(values, floorValue);
      }
      me.monitor(newValue);
    }
  }

  floorOneChange = (floor, id) => {
    var me = this;
    return function (e) {
      const checked = e.target.checked;

      let values = me.props.value;
      let newValue = [];
      let isCheckAll = false;

      if (checked) {
        newValue = _.union(values, [id]);
      }
      else {
        newValue = _.without(values, id);
      }
      me.monitor(newValue);
    }
  }

  genFloor = (data, key) => {
    const values = this.props.value;
    const html = _.map(
      data.list,
      (item, key) => {
        const children = _.map(
          item,
          one => {
            const checked = !!_.find(values, item => item === one.id);
            return (<Checkbox checked={checked} floor={key} key={one.id} onChange={this.floorOneChange(key, one.id)}>{one.text}</Checkbox>);
          }
        );
        return (
          <div className="resource-floor" key={key}>
            <div className="resource-floor-title resource-title">
              <Checkbox indeterminate={!!this.state.isCheckPartialList[key]} checked={!!this.state.isCheckList[key]} onChange={this.changeFloor(key)} >第{key}层</Checkbox>
            </div>
            <div className="resource-floor-group">{children}</div>
          </div>
        );
      }
    );


    return (
      <div className="resource-checkbox-group resource-checkbox-group-level">{html}</div>
    );
  }

  // 分散式
  changeOne = (key, id) => {
    var me = this;
    return function (e) {
      var checked = e.target.checked;
      var values = me.props.value;
      var newValue = [];

      if (checked) {
        newValue = _.union(values, [id]);
      }
      else {
        newValue = _.without(values, id);
      }
      me.monitor(newValue);
    }
  }

  genOne = (data, key) => {
    const values = this.props.value;
    const html = _.map(
      data.list,
      (item, key) => {
        const checked = _.contains(values, item.id);
        return (
          <Checkbox key={item.id} checked={checked} onChange={this.changeOne(key, item.id)} >{item.text}</Checkbox>
        );
      }
    );
    return (
      <div className="resource-checkbox-group resource-checkbox-group-no-level">{html}</div>
    );

  }

  genItem = (item, key) => {
    const html = item.isLevel ? this.genFloor(item, key) : this.genOne(item, key);
    return (
      <div id={"house-name-" + item.id}>
        <Checkbox
          className="resource-name"
          indeterminate={ this.state.isCheckPartial }
          checked={ this.state.isCheckAll }
          onChange={ this.allCheck }
        >{item.name}</Checkbox>
        <div className="resource-item" >{html}</div>
      </div>
    );
  }

  render() {
    return this.genItem(this.props.data);
  }

}

export default class ResourceCheckboxGroup extends Component {

  onChange = (value) => {
    this.props.onChange(value);
  }

  render() {

    let list = this.props.resourceItemList;
    let value = this.props.selectedResourceId;

    let centralizedCheckboxGroup = _.map(
      list.centralized || [],
      (item, key) => (<CheckboxItem key={item.id} data={item} value={value} onChange={this.onChange}/>)
    );

    let federalCheckboxGroup = _.map(
      list.federal || [],
      (item, key) => (<CheckboxItem key={item.id} data={item} value={value} onChange={this.onChange}/>)
    );

    if (centralizedCheckboxGroup.length === 0 && federalCheckboxGroup.length === 0 ) {
      return (
        <div className="resource-checkbox-group-wrapper">
          <div className="warn-label">没有可选择的房源！</div>
        </div>
      );
    }

    return (
      <div className="resource-checkbox-group-wrapper">
        { centralizedCheckboxGroup }
        { federalCheckboxGroup }
      </div>
    );
  }
}
