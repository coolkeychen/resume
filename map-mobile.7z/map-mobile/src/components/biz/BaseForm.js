import React, { PropTypes } from 'react';

class BaseForm extends React.Component {

  componentWillMount = () => {
  }

  render = () => {
    return (<div></div>);
  }
}

export default BaseForm;
