import React, { PropTypes } from 'react';
import { getCrumbsData } from 'common/utils/tools';


class BaseFilteredList extends React.Component {

  componentWillMount = () => {
    this.initCrumbsData && this.initCrumbsData();
    this.list({});
  }

  search = (fields) => {
    // 修改搜索状态
    let module = this.module;
    this.props.dispatch({
      type: `${module}/setToSearch`,
    });
    fields.pageNo = 1;
    this.list({ ...fields, });
  }

  searchByPage = (fields) => {
    this.list({ ...fields, });
  }

  clear = (fields) => {
    // 修改搜索状态
    let module = this.module;
    this.props.dispatch({
      type: `${module}/clearSearch`,
    });
    // 清空数据
    let emptyFields = Object.keys(fields).reduce(
      (emptyFields, key) => {
        emptyFields[key] = null;
        return emptyFields;
      },
      {}
    );
    this.list({ ...emptyFields, });
  }

  list = (searchParams) => {
    let module = this.module;
    this.props.dispatch({
      type: `${module}/paramsChange`,
      payload: searchParams,
    });

    this.props.dispatch({
      type: `${module}/list`
    });
  }

  toCreate = () => {
    let module = this.module;
    this.props.dispatch({
      type: `${module}/toCreate`
    });
  }

  onSearchChange = (fieldValues, autoSubmit) => {
    let module = this.module;
    console.log(module)
    if (autoSubmit) {
      this.search(fieldValues);
    }
    else {
      this.props.dispatch({
        type: `${module}/paramsChange`,
        payload: fieldValues,
      });
    }
  }

  render = () => {
    return (<div></div>);
  }
}

export default BaseFilteredList;
