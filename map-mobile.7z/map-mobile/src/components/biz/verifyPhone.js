/**
 * Created by Shengchenling711 on 2017/6/24.
 */
import React from 'react';
import { connect } from 'dva';
import { Button, Row, Col, Form, Input, Modal, Checkbox, Steps } from 'antd';
import CountDownCaptcha from 'components/biz/countDownCaptcha'
const FormItem = Form.Item;
const Step = Steps.Step;

class VerifyPhone extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      captchaImg: '/web/account/imgcode',
      captchaImg_temp: '/web/account/imgcode',
      count: this.props.count || 10,
      timerTitle: this.props.timerTitle || '获取验证码',
      counting: false,
      selfEnable: false,
      clickEnable: true,
      form1: {},
      key: 1,
      temp_v: false,
    };
  }

  componentWillReceiveProps = (nextProps) => {
    const { resetPasswordStep1 } = nextProps;
    if (resetPasswordStep1 && !this.state.temp_v) {
      //这是新开的modal
      this.setState({
        temp_v: true
      })
      this.changeCaptcha();
    } else if (resetPasswordStep1 && this.state.temp_v) {
      return false
    } else if (!resetPasswordStep1) {
      this.setState({
        temp_v: false
      })
    }
  }


  // 校验手机号码
  verifyphone = (rule, value, callback) => {
    if (value === '') {
      callback('请输入手机号码');
    }
    if (!/^1[34578]\d{9}$/.test(value)) {
      callback('手机号码格式不正确');
    } else {
      callback();
    }
  }

  // 校验验证码6位
  verifyMsgAuthCode = (rule, value, callback) => {
    if (value === '') {
      callback('请输入短信验证码');
    }
    if (!/^\d{6}$/.test(value)) {
      callback('短信验证码为6位数字');
    } else {
      callback();
    }
  }

  verifyImgCode = (rule, value, callback) => {
    if (value === '') {
      callback('请输入图形验证码');
    }
    if (!/^[a-zA-Z0-9]{4}$/.test(value)) {
      callback('图形验证码格式不正确');
    } else {
      callback();
    }
  }

  submitCode = () => {
    const { form } = this.props;
    form.validateFieldsAndScroll((errors, values) => {
      if (!errors) {
        const { form1 } = values;
        this.props.submitCode(form1);
      }
    });
  }


  getCode = (e) => {
    const { form } = this.props;
    form.validateFieldsAndScroll(['form1.mobile', 'form1.imgAuthCode'], (errors, values) => {
      if (errors) {
        return false;
      }
      const { form1 } = values;
      this.props.getCode(form1);
    });
  }
  changeCaptcha = () => {
    const temp = `${this.state.captchaImg}?${(new Date()).valueOf()}`;
    this.setState({
      captchaImg_temp: temp,
    });
  }

  render = () => {
    const { verifyPhone, showCount } = this.props;
    const { getFieldDecorator } = this.props.form;
    const { captchaImg_temp } = verifyPhone;
    const formModalLayout = {
      labelCol: {
        xs: { span: 6 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 18 },
        sm: { span: 18 },
      },
    };

    return (
      <Modal maskClosable={ false }
             title="重置登录密码"
             visible={this.props.visible}
             onCancel={this.props.closeResetPasswordStep1}
             onOk={this.submitCode}
             wrapClassName="account-modal"
             okText="下一步"
             key={this.props.modalKey}
      >
        <Steps size="small" current={0}>
          <Step title="身份认证" />
          <Step title="重置密码" />
        </Steps>
        <Form className="mt-15">
          <Row>
            <FormItem
              {...formModalLayout}
              label="手机号"
            >
              {getFieldDecorator('form1.mobile', {
                validateTrigger: ['onSubmit', 'onBlur'],
                rules: [{
                  validator: this.verifyphone,
                }],
              })(<Input size="large" placeholder="手机号" />)}
            </FormItem>
          </Row>
          <Row>
            <FormItem
              {...formModalLayout}
              label="图形验证码"
            >
              {getFieldDecorator('form1.imgAuthCode', {
                validateTrigger: ['onSubmit', 'onBlur'],
                rules: [{
                  validator: this.verifyImgCode,
                }],
              })(<Input size="large" placeholder="图形验证码" />)}
            </FormItem>
            <img className="captcha-img" onClick={this.changeCaptcha} src={this.state.captchaImg_temp} />
          </Row>
          <Row>
            <FormItem
              {...formModalLayout}
              label="手机验证码"
            >
              {getFieldDecorator('form1.msgAuthCode', {
                validateTrigger: ['onSubmit', 'onBlur'],
                rules: [
                  {
                    validator: this.verifyMsgAuthCode,
                  },
                ],
              })(<Input size="large" placeholder="手机验证码" />)}
            </FormItem>
            <CountDownCaptcha
              ref="countDownCaptcha"
              showCount={showCount}
              onClick={this.getCode}
              resetCount={this.props.resetCount}
            />
          </Row>
        </Form>
      </Modal>
    )
  }
}

export default Form.create()(VerifyPhone);
