import dva from 'dva';
import { browserHistory } from 'dva/router';
import createLoading from 'dva-loading';
import moment from 'moment';
import 'moment/locale/zh-cn';
import './common/global/appBridge';

moment.locale('zh-cn');
// 1. Initialize
const app = dva({
  history: browserHistory,
});

window.apps = app;
app.use(createLoading());


// 室外地图
app.model(require('./biz/models/map/outdoor.js'));
// 室内地图
app.model(require('./biz/models/map/indoor.js'));


//注册router
app.router(require('./router'));
// 4. Start
app.start('#app');
