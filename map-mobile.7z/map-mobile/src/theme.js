
module.exports = Object.assign(
  {},
  {
    '@border-radius-base': '2px',
    '@border-radius-sm': '2px',
    '@shadow-color': 'rgba(0,0,0,0.12)',
    '@shadow-1-down': '4px 4px 40px @shadow-color',
    '@border-color-split': '#E1E1E1',
    '@border-color-base': '#e5e5e5',
    '@error-color': '#D05538',
    '@layout-sider-background': '#fff',
    '@menu-dark-bg': '#3e3e3e',
    '@text-color': '#333333',
    '@primary-color': '#008beC',
    // '@link-hover-color': hoverColor,
    // '@primary-5': hoverColor,
    '@primary-1': '#008beC',
    '@border-color-base': '#999999',
    '@btn-padding-base': '4px 18px',
    '@font-family': '-apple-system-font, Helvetica Neue, PingFang SC, Hiragino Sans GB, Microsoft YaHei, sans-serif',

    '@icon-url': '"../../../../../src/static/font/iconfont"',

    '@btn-height-base': '28px',
    '@input-hover-border-color': '#008beC',

    //table
    '@table-header-bg': '#FFFFFF',
    '@table-padding-horizontal': '16px',
    '@table-padding-vertical': '8px',
    '@label-color': '#666666',

    //font
    '@btn-font-weight': 400,

  } // eslint-disable-line
);
